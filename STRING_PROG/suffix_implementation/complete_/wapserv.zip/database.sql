# MySQL dump 5.13
#
# Host: localhost    Database: wap
#--------------------------------------------------------
# Server version	3.22.19a

#
# Table structure for table 'playlist'
#
CREATE TABLE playlist (
  pl_id int(11) DEFAULT '0' NOT NULL auto_increment,
  song_id int(11),
  title varchar(30),
  artist varchar(30),
  message varchar(50),
  PRIMARY KEY (pl_id)
);

#
# Dumping data for table 'playlist'
#

INSERT INTO playlist VALUES (1,110,'Sometimes','Britney Spears','love');

#
# Table structure for table 'songs'
#
CREATE TABLE songs (
  song_id int(11) DEFAULT '0' NOT NULL auto_increment,
  title varchar(30),
  artist varchar(30),
  PRIMARY KEY (song_id)
);

#
# Dumping data for table 'songs'
#

INSERT INTO songs VALUES (1,'that doesn\'t impress me much','Shania Twain');
INSERT INTO songs VALUES (2,'(You Drive Me) Crazy','Britney Spears');
INSERT INTO songs VALUES (3,'Larger Than Life','Backstreet Boys');
INSERT INTO songs VALUES (4,'Glorious','Andreas Johnson');
INSERT INTO songs VALUES (5,'Bring Me Closer','Voodoobeats');
INSERT INTO songs VALUES (6,'New York City Boy (The Almight','Pet Shop Boys');
INSERT INTO songs VALUES (7,'Dinata Dinata','Antique');
INSERT INTO songs VALUES (8,'Better Off Alone','Alice Deejay');
INSERT INTO songs VALUES (9,'Northern Star','Melanie C');
INSERT INTO songs VALUES (10,'She\'s The One','Robbie Williams');
INSERT INTO songs VALUES (11,'Caught Out There (Plen Radio E','Kelis');
INSERT INTO songs VALUES (12,'Not Over You Yet (Metro Radio','Diana Ross');
INSERT INTO songs VALUES (13,'Stars (The Almighty 7\" Mix)','Roxette');
INSERT INTO songs VALUES (14,'When The Heartache Is Over','Tina Turner');
INSERT INTO songs VALUES (15,'Doberman','Morten Abel');
INSERT INTO songs VALUES (16,'Grind You Down','Savoy');
INSERT INTO songs VALUES (17,'Keep On Movin\'','Five');
INSERT INTO songs VALUES (18,'I Saved The World Today','Eurythmics');
INSERT INTO songs VALUES (19,'Cognoscenti Vs Intelligentsia','Cuban Boys');
INSERT INTO songs VALUES (20,'Christmas Time','Backstreet Boys');
INSERT INTO songs VALUES (21,'I Met An Angel (On Christmas D','Celine Dion');
INSERT INTO songs VALUES (22,'Ay, Ay, Ay It\'s Christmas','Ricky Martin');
INSERT INTO songs VALUES (23,'Christmas Through Your Eyes','Gloria Estefan');
INSERT INTO songs VALUES (24,'Till Christmas','Popenglene \'99');
INSERT INTO songs VALUES (25,'Do They Know It\'s Christmas','Band Aid');
INSERT INTO songs VALUES (26,'Have Yourself A Merry Little C','Babyface');
INSERT INTO songs VALUES (27,'Let Love Be Love','Juice/S.O.A.P./Christina feat.');
INSERT INTO songs VALUES (28,'Steo Into Christmas','Elton John');
INSERT INTO songs VALUES (29,'When A Child Is Born','Lutricia McNeal');
INSERT INTO songs VALUES (30,'White Christmas','Bing Crosby');
INSERT INTO songs VALUES (31,'O Come All Ye Faithful','Art Garfunkel');
INSERT INTO songs VALUES (32,'Last Christmas','Wham');
INSERT INTO songs VALUES (33,'This Gift','98');
INSERT INTO songs VALUES (34,'Winter Wonderland','Aretha Franklin');
INSERT INTO songs VALUES (35,'Silent Night, Holy Night','Mahalia Jackson');
INSERT INTO songs VALUES (36,'Please Come Home For Christmas','Jon Bon Jovi');
INSERT INTO songs VALUES (37,'Run Rudolph Run','Bryan Adams');
INSERT INTO songs VALUES (38,'Early Christmas Morning','Cyndi Lauper');
INSERT INTO songs VALUES (39,'Happy New Year','Abba');
INSERT INTO songs VALUES (40,'The Bad Touch','Bloodhound Gang');
INSERT INTO songs VALUES (41,'(You Drive Me)Crazy','Britney Spears');
INSERT INTO songs VALUES (42,'Don\'t Call Me Baby','Madison Avenue');
INSERT INTO songs VALUES (43,'Waiting For Tonight','Jennifer Lopez');
INSERT INTO songs VALUES (45,'A Rocket Ride','Mette Iversen');
INSERT INTO songs VALUES (46,'Bailamos','Enrique Iglesias');
INSERT INTO songs VALUES (47,'Larger Than Life','Backstreet Boys');
INSERT INTO songs VALUES (48,'Life\'s a Bitch','Shooter');
INSERT INTO songs VALUES (49,'When You Say Nothing At All','Ronan Keating');
INSERT INTO songs VALUES (50,'H�lla Dig N�ra','Dr�mhus');
INSERT INTO songs VALUES (51,'Happy New Year','A Teens');
INSERT INTO songs VALUES (52,'Jesse Hold On','B Witched');
INSERT INTO songs VALUES (53,'(Mucho Mambo)Sway','Shaft');
INSERT INTO songs VALUES (54,'She\'s All I Ever Had','Ricky Martin');
INSERT INTO songs VALUES (55,'This Is My Reality','Farell');
INSERT INTO songs VALUES (56,'365 Days','Lutricia McNeal');
INSERT INTO songs VALUES (57,'Why Go ?','Faithless & Boy George');
INSERT INTO songs VALUES (58,'Sv�rt Att S�ga Nej','Bo Kaspers Orkester & Lisa Ekd');
INSERT INTO songs VALUES (59,'Heut\' Ist Mein Tag','Bl�mchen');
INSERT INTO songs VALUES (60,'Sun Is Shining','Bob Marley Vs. Funkstar De Lux');
INSERT INTO songs VALUES (61,'Get Me','Reset');
INSERT INTO songs VALUES (62,'The Remededy','Remedeeh');
INSERT INTO songs VALUES (63,'Feel Good','Phats & Small');
INSERT INTO songs VALUES (64,'Sing It Back','Moloko');
INSERT INTO songs VALUES (65,'Burning Down The House','Tom Jones & The Cardigans');
INSERT INTO songs VALUES (66,'C\'est La Vie (Always 21)','Ace Of Base');
INSERT INTO songs VALUES (67,'Till Christmas','Pop-Englene 99');
INSERT INTO songs VALUES (68,'Fuck The Millennium','Scooter');
INSERT INTO songs VALUES (69,'Opa Opa','Antique');
INSERT INTO songs VALUES (70,'Ocean','Pacific Blue');
INSERT INTO songs VALUES (71,'After Love','Blank & Jones');
INSERT INTO songs VALUES (72,'Comin\' On Strong','Signum feat. Scott Mac');
INSERT INTO songs VALUES (73,'Destination Sunshine','Balearic Bill');
INSERT INTO songs VALUES (74,'Wrong = Right','Dj Jos� Vs. G-Spott');
INSERT INTO songs VALUES (75,'Keep It Up','J&R Project');
INSERT INTO songs VALUES (76,'Welcome To The Dance','Des Mitchell');
INSERT INTO songs VALUES (77,'It must have been love','Roxette');
INSERT INTO songs VALUES (78,'Crying in the rain','A-ha');
INSERT INTO songs VALUES (79,'Nothing compares 2 u','Sin�ad O\'Connor');
INSERT INTO songs VALUES (80,'Sadness part 1','Enigma');
INSERT INTO songs VALUES (81,'Get off','Prince');
INSERT INTO songs VALUES (82,'Bad boys','Inner Circle');
INSERT INTO songs VALUES (83,'Every time we touch','Maggie Reilly');
INSERT INTO songs VALUES (84,'To be with you','Mr. Big');
INSERT INTO songs VALUES (85,'The actor','Michael learns to rock');
INSERT INTO songs VALUES (86,'Drive','R.E.M.');
INSERT INTO songs VALUES (87,'That\'s the way love goes','Janet Jackson');
INSERT INTO songs VALUES (88,'What is love','Haddaway');
INSERT INTO songs VALUES (89,'Informer','Snow');
INSERT INTO songs VALUES (90,'Cotton eye Joe','Rednex');
INSERT INTO songs VALUES (91,'Saturday night','Whigfield');
INSERT INTO songs VALUES (92,'Mmm mmm mmm mmm','Crash test dummies');
INSERT INTO songs VALUES (93,'Vem vet','Lisa Ekdahl');
INSERT INTO songs VALUES (94,'\'74-\'75','The Connells');
INSERT INTO songs VALUES (95,'Waterfalls','TLC');
INSERT INTO songs VALUES (96,'Boombastic','Shaggy');
INSERT INTO songs VALUES (97,'A kind of christmas card','Morten Harket');
INSERT INTO songs VALUES (98,'Lemon tree','Fool\'s garden');
INSERT INTO songs VALUES (99,'Wannabe','Spice girls');
INSERT INTO songs VALUES (100,'Macarena','Los del rio');
INSERT INTO songs VALUES (101,'Insomnia','Faithless');
INSERT INTO songs VALUES (102,'Bohemian rhapsody','The Braids');
INSERT INTO songs VALUES (103,'Un-break my heart','Toni Braxton');
INSERT INTO songs VALUES (104,'As long as you love me','Backstreet boys');
INSERT INTO songs VALUES (105,'I\'ll be there for you','The Rembrandts');
INSERT INTO songs VALUES (106,'Tubthumping','Chumbawamba');
INSERT INTO songs VALUES (107,'Calcutta','Dr. Bombay');
INSERT INTO songs VALUES (108,'Nobody\'s wife','Anouk');
INSERT INTO songs VALUES (109,'Unforgivable sinner','Lene Marlin');
INSERT INTO songs VALUES (110,'Sometimes','Britney Spears');
INSERT INTO songs VALUES (111,'Not for the dough','Multicyde feat. An�a');
INSERT INTO songs VALUES (112,'Boom, boom, boom, boom !','Vengaboys');
INSERT INTO songs VALUES (113,'Mambo no. 5','Lou Bega');

