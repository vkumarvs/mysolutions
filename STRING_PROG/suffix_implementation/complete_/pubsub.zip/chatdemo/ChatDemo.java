/*
 * ChatDemo.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */
 
package chatdemo;

import java.util.Vector;
import java.util.StringTokenizer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.JMSException;

import chatdemo.chatroom.ChatRoom;
import chatdemo.chatroom.ChatRoomListener;
import chatdemo.chatroom.ChatRoomMessage;
import chatdemo.chatroom.ChatRoomUser;

/*****************************************************************************
 *
 * Main class for the chat demo which creates the GUI and makes use of the api
 * defined by the package chatdemo.chatroom.  The class JMSProvder is used to
 * create a provider specific implementation of TopicConnectionFactory and
 * for dynamic Topic creation.  Everything else in this demo uses pure JMS.  
 * The code can be used as either and applet or an application.  See 
 * printUsage() for how to use the class as an application.  The html file 
 * contained in this package demonstrates how to set use the class as an 
 * applet.
 *
 ****************************************************************************/
public class ChatDemo extends JApplet 
	implements ActionListener, ChatRoomListener 
{
    
    // Default list of chat topics if none are specified by the user.
    public static final String DEFAULT_TOPICS = "Computers,Travel,Football";
    
	private Vector				_chatTopicStrings;
	private Vector				_chatTopics;
    private TopicConnection		_jmsConnection;	
    private ChatRoomUser		_currentUser; 
	private ChatRoom			_currentChatRoom;
    
	public String				_providerName;
	public Vector				_providerParams;
	
	// Define the gui elements that will be needed throughout
	// the class.  
    private JComboBox			_chatRooms;
    private JList				_chattersList;
    private DefaultListModel    _chattersListData;
    
    private JButton				_sendMessageButton;
    private JTextPane			_messageDisplay; 
    private JTextPane			_messageTextPane;  
    private JPopupMenu			_chatterOptions;
    private JCheckBoxMenuItem	_ignoreCheckBox;
    
	// Used to make sure that jms is only initialized once.
	private boolean				_initialized = false;
	
	// Several text styles are created for _messageDisplay.  These constants
	// are used to label those styles when they are created so that they
	// can be accessed when messages need to be formated correctly.
	private static final String	CHAT_STYLE		= "chat_style";
	private static final String BOLD_STYLE		= "bold_style";
	private static final String SYSTEM_STYLE	= "system_style";
	
    /**
     * Entry point for the program when it is loaded as an applet.
     */
    public void init() 
	{
    
        // Fetch parameters from the applet tags.
        //
        _providerName = this.getParameter("provider");
		String temp = this.getParameter("params");
		_providerParams = parseParams(temp, ":");
		
        String rooms = this.getParameter("rooms");
        if (rooms != null )
			_chatTopicStrings = parseParams(rooms, ",");
		else
			_chatTopicStrings = parseParams(DEFAULT_TOPICS, ",");
		
		initGUI();
    }
    
	/**
	 * Called by the browser when the applet first loads after it calls 
	 * init().  It is also called everytime the applet returns to the screen 
	 * after not being visible.  As a result we need to make sure that the 
	 * jms stuff is only initialized once.
	 */
	public void start() 
	{
		if (_initialized == false) {
		   initJMS();
		   _initialized = true;
		}
	}

	/**
	 * Called by the browser when the applet's resources are about to be
	 * reclaimed.  The user will leave the chat room, and the TopicConnection
	 * will be closed (if necessary).
	 */
    public void destroy() 
	{
        try {
            if (_currentChatRoom != null)
                _currentChatRoom.leave();
                
            if (_jmsConnection != null)
                _jmsConnection.close();
        } catch (JMSException e) {}
    }
	
	/**
	 * Convienance method to parse a string int a vector of strings which
	 * were delimented by <code>token</code>.
	 */
	private static Vector parseParams(String params, String token) 
	{
		java.util.StringTokenizer tokens =
			new java.util.StringTokenizer(params, token, false);
		
		Vector retValue = new Vector(tokens.countTokens());
		
		while (tokens.hasMoreTokens())
			retValue.addElement(tokens.nextToken().trim());
			
		return retValue;
	}
	
	/**
	 * Intializes JMS and sets up an instance of ChatRoom.  
	 */
	public void initJMS() 
	{
		
		try {
			
			// Obtain the JMS provider's TopicConnectionFactory implementation
			TopicConnectionFactory factory = 
				JMSProvider.createTopicConnectionFactory
				    (_providerName, _providerParams);
			
			_chatTopics = 
				JMSProvider.createTopics(_providerName, _chatTopicStrings);
			
			// Create the TopicConnection to be used during the ChatDemo
			_jmsConnection = factory.createTopicConnection();
			
			// JMS allows you to set up all of your MessageProducers and 
			// MessageConsuers (i.e. TopicPublisher/TopicSubscriber)
			// without having to worry about incoming messages if you do it
			// before calling start() on the Connection.  However, the 
			// ChatRoom is designed in a way that it can handle incoming 
			// messages properly while setting itself up...so we can 
			// start the TopicConnection here.
			_jmsConnection.start();
			
			
			// Set the user for the duration of this demo.
			String userID = promptForUserAlias();
			_currentUser = new ChatRoomUser(userID);
			
			// Set up the one and only ChatRoom instance for this demo.
			// The class is designed so that it can be used to join and leave
			// different rooms.
			_currentChatRoom = new ChatRoom(_currentUser, _jmsConnection);
			_currentChatRoom.addChatRoomListener(this);
			
			// Join the default room
			_currentChatRoom.join((Topic) _chatTopics.elementAt(0));
			
			// Enable the gui.
			_chattersList.addMouseListener(new MyListListener());
			_chatRooms.addActionListener(this);
			_sendMessageButton.addActionListener(this);
			_ignoreCheckBox.addActionListener(this);   
			
			_chatRooms.setEnabled(true);
			_sendMessageButton.setEnabled(true);   
			
		
		} catch (Exception e) {
			
			JOptionPane.showMessageDialog(ChatDemo.this, 
				"General error while trying to initialize.\n"+e,
				"Initialization Error", JOptionPane.ERROR_MESSAGE);
			
		}            
		
	}
	
	/**
	 * Prompts the user for an alias to be used in the chat rooms, and
	 * returns their choice.  The alias "Guest" will be assigned if no
	 * suitable alias is selected by the user.
	 */
	private String promptForUserAlias() 
	{
		// Open a dialog that will prompt the user for their ID
		final UserInfoDialog input = new UserInfoDialog(null);
		
		input.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
				input.setVisible(false);
			}
        });
		
		input.show();
		String userID = input.getUserID();

		if (userID == null || userID.equals("")) {
			// User must of canceled the dialog without giving a name.
			// Lets name them Guest.
			userID = "Guest";
		}
		
		return userID;
	}
	
    /**
     * This is the event handler for the GUI.  All actions related to 
     * chatting will processed through this action listener.
     */
    public void actionPerformed(ActionEvent e) 
	{
        Object obj = (Object) e.getSource();
        
		// Check to see if the user is sending a new message.
        if (obj == _sendMessageButton) {
            
            // Send whatever is in the _messageTextPane to the
            // currentChatRoom.
            //
            ChatRoomMessage message = new ChatRoomMessage();
            message.setMessage(_messageTextPane.getText());
            message.setSender(_currentUser);
            _messageTextPane.setText("");
            try {
                _currentChatRoom.broadcastMessage(message);
            } catch (JMSException ex) {
                System.err.println("Unable to send message because.\n"+ex);
            }
        }
        
		// Check to see if the user is changing chat rooms.
        else if (obj == _chatRooms) {
            try {
               
                // Leave the current chat room if necesssary.
                if (_currentChatRoom != null) 
                    _currentChatRoom.leave();
                
				// Clear the message display
                try {
                    Document doc = _messageDisplay.getDocument();
                    doc.remove(0, doc.getLength());
                } catch (BadLocationException ble) {}
                
                // Clear everyone from my list.
                _chattersListData.clear();
                
                // And join the new chat room with the new instance.
                _currentChatRoom.join((Topic) 
					_chatTopics.elementAt(_chatRooms.getSelectedIndex()));
                
            } catch (Exception ex2) {
                System.err.println("At change chat room: "+ex2); 
            }
        }
		
		// Check to see if the user has toggled a another users ignore value.
        else if (obj == _ignoreCheckBox) {
            
            ChatRoomUser user = 
                (ChatRoomUser) _chattersList.getSelectedValue();
            
            if (_ignoreCheckBox.getState()) {
                try {
                    _currentChatRoom.ignoreUser(user);
                } catch (Exception jmse) {}    
            }
            else {
                try {
                    _currentChatRoom.listenToUser(user);
                } catch (Exception jmse) {}
            }
            
                
        }
    }
    
	/**
	 * This method will be called by <code>_currentChatRoom</code> every
	 * time a user message comes into the chat room.  The message will 
	 * be formated and displayed to <code>_messageDisplay</code>
	 * 
	 * @see chatdemo.chatroom.ChatRoomListener#incomingMessage
	 **/
	public void incomingMessage(ChatRoomMessage message) 
	{	
		StyledDocument doc = (StyledDocument) _messageDisplay.getDocument();
		try {
			doc.setLogicalStyle(doc.getLength(), 
			    _messageDisplay.getStyle(CHAT_STYLE));
			
			doc.insertString(doc.getLength(),
				message.getSender().toString() + ": ", 
				_messageDisplay.getStyle(BOLD_STYLE));
			doc.insertString(doc.getLength(),
				message.getMessage() + '\n', 
				_messageDisplay.getStyle(CHAT_STYLE));

			
		} catch (BadLocationException e) {
			System.err.println("Error inserting text");
		}
		
		_messageDisplay.setCaretPosition(doc.getLength()-1);            
	}
	
	
	/**
	 * Adds the user to the chattersList and posts a message to
	 * the main message display (if the user is not being ignored)
	 * 
	 * @see chatdemo.chatroom.ChatRoomListener#userAdded
	 */
	public void userAdded(ChatRoomUser theUser) 
	{	
		_chattersListData.addElement(theUser);        
		
		if (! theUser.isIgnored()) {
			StyledDocument doc = 
				(StyledDocument)_messageDisplay.getDocument();
			
			String message = "---- User "+ theUser.getAlias() 
				+" has entered the chat room. --- \n";
			
			try {
				doc.insertString(doc.getLength(),message, 
					_messageDisplay.getStyle(SYSTEM_STYLE));
			} catch (BadLocationException e) {
				System.err.println("Error inserting text");
			}
			
			_messageDisplay.setCaretPosition(doc.getLength()-1);      
		} 
	}
	
	/**
	 * Removes the user from the _chattersList and posts a message to
	 * the main message display (if the user is not being ignored).
	 * 
	 * @see chatdemo.chatroom.ChatRoomListener#userRemoved
	 */
	public void userRemoved(ChatRoomUser theUser) 
	{	
		if (_chattersListData.removeElement(theUser)) {
			
			if (! theUser.isIgnored()) {
				StyledDocument doc = 
				    (StyledDocument)_messageDisplay.getDocument();
				
				String message = "---- User "+ theUser.getAlias() 
					+" has left the chat room. ---\n";
				try {
					
					doc.insertString(doc.getLength(),message, 
						_messageDisplay.getStyle(SYSTEM_STYLE));
				} catch (BadLocationException e) {
					System.err.println("Error inserting text");
				}
				
				_messageDisplay.setCaretPosition(doc.getLength()-1);
			}
		}
	}
	
	
	//////////////////////////////////////////////////////////////////////////
	// Start InnerClass MyListListener
	//
	//
	
    /*************************************************************************
     * Listener that is attached to the _chattersList.  It simply listens 
     * for the appropriate mouse events on a list item that should bring up
     * the ignore User option box.
     ************************************************************************/
    private class MyListListener extends MouseAdapter 
	{
        
        /** 
         * Displays popup menu when the user double clicks on a connected
         * user.
         */
        public void mouseClicked(MouseEvent e) {
            
            if (e.getClickCount() == 2) {
                int index = _chattersList.locationToIndex(e.getPoint());
                if ( (index != -1) && (_chattersList.isSelectedIndex(index)) ) {
                    ChatRoomUser user = 
                        (ChatRoomUser)_chattersList.getSelectedValue();
                    _ignoreCheckBox.setState(user.isIgnored());
                    _chatterOptions.show(e.getComponent(), e.getX(), e.getY());
                
                }
            }
        }
        
        /** Displays popup menu if the mouse event was a popupTrigger */
        public void mousePressed(MouseEvent e)  { maybeShowPopup(e); }
        
        /** Displays popup menu if the mouse event was a popupTrigger */
        public void mouseReleased(MouseEvent e) { maybeShowPopup(e); }
        
        
        private void maybeShowPopup(MouseEvent e) {
            if (e.isPopupTrigger()) {
                int index = _chattersList.locationToIndex(e.getPoint());
                if ( index != -1) {
                    _chattersList.setSelectedIndex(index);
                    
                    ChatRoomUser user = 
                        (ChatRoomUser)_chattersList.getSelectedValue();
                        
                    _ignoreCheckBox.setState(user.isIgnored());
                    _chatterOptions.show(e.getComponent(), e.getX(), e.getY());
                    
                }    
                
            }
        }
    
    }
    //
    //
    // End Inner class MyListListener
    //////////////////////////////////////////////////////////////////////////


    /**
     * All of the relevant code for setting up the GUI.
     */
    protected void initGUI() 
	{
        
        Container contentPane = null;
        JPanel titlePanel, mainPanel, messageSendPanel, chattersPanel;
        JLabel chatRoomsLabel1, chatRoomsLabel2;      
        
        contentPane = this.getContentPane();

        
        // Setup the title bar for the GUI.  This will contain the pulldown
        // list that is used to select between chat rooms.
        // 
        titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.X_AXIS));
        chatRoomsLabel1 = new JLabel("Chat Room: ");
        chatRoomsLabel1.setLabelFor(_chatRooms);
        _chatRooms = new JComboBox(_chatTopicStrings);
        titlePanel.add(chatRoomsLabel1);
        titlePanel.add(_chatRooms);
        titlePanel.add(Box.createHorizontalGlue());
        contentPane.add(titlePanel, BorderLayout.NORTH);
        
        
        // Setup the main panel which contains everything but the title bar.
        //
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        contentPane.add(mainPanel, BorderLayout.CENTER);
         
        // 1. Main Message Text Pane
        _messageDisplay = new JTextPane();
        _messageDisplay.setEditable(false);
        JScrollPane jsp = new JScrollPane();
        jsp.getViewport().add(_messageDisplay);
        mainPanel.add(jsp, BorderLayout.CENTER);
         
        // Initalize the text styles that will be used to display
        // the chat messages.
        Style defaultStyle = StyleContext.getDefaultStyleContext().
            getStyle(StyleContext.DEFAULT_STYLE);
         
        // Style use to create the correct indentation for a chat message.
        Style s = _messageDisplay.addStyle(CHAT_STYLE, defaultStyle);
        StyleConstants.setLeftIndent(s,20);
        StyleConstants.setFirstLineIndent(s, -20);
         
        // Style used to display the user who sent a message.
        s = _messageDisplay.addStyle(BOLD_STYLE, defaultStyle);
        StyleConstants.setBold(s, true);
        StyleConstants.setForeground(s, Color.red);
         
        // Style used to display system messages, like when a user joins
        // the chat room.
        s = _messageDisplay.addStyle(SYSTEM_STYLE, defaultStyle);
        StyleConstants.setItalic(s, true);
        StyleConstants.setForeground(s, Color.red);
         
         
        // 3. Chatters Column
        chattersPanel = new JPanel();
        chattersPanel.setLayout(new BorderLayout());
        chattersPanel.setPreferredSize(new Dimension(125, 1000));
        JScrollPane jsp3 = new JScrollPane();
        JLabel chatLabel1 = new JLabel("Chatters");
        chatLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        chatLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        chatLabel1.setLabelFor(_chattersList);
        chattersPanel.add(chatLabel1, BorderLayout.NORTH);
        _chattersListData = new DefaultListModel();
        _chattersList = new JList(_chattersListData);
        
        jsp3.getViewport().add(_chattersList);
        chattersPanel.add(jsp3, BorderLayout.CENTER);
        mainPanel.add(chattersPanel, BorderLayout.EAST);
            
         
        // 2. Message Sending Panel
        messageSendPanel = new JPanel();
        messageSendPanel.setPreferredSize(new Dimension(125, 25));
        messageSendPanel.setLayout(
            new BoxLayout(messageSendPanel, BoxLayout.X_AXIS));
        JScrollPane jsp2 = new JScrollPane();
        JLabel messageLabel1 = new JLabel("Chat: ");
        messageLabel1.setLabelFor(jsp);
        _messageTextPane = new JTextPane();
        jsp2.getViewport().add(_messageTextPane);
        _sendMessageButton = new JButton("Send");
        messageSendPanel.add(messageLabel1);
        messageSendPanel.add(jsp2);
        messageSendPanel.add(_sendMessageButton);
        contentPane.add(messageSendPanel, BorderLayout.SOUTH);
         
        // 4. Chatter Options
        _chatterOptions = new JPopupMenu();
        _ignoreCheckBox = new JCheckBoxMenuItem("Ignore");
        _chatterOptions.add(_ignoreCheckBox);
        
        // Disable the functionality of the GUI.
        _chatRooms.setEnabled(false);
        _sendMessageButton.setEnabled(false);   
    }
    
    //////////////////////////////////////////////////////////////////////////
    // Everything from here on out is used to make the class run as an
    // application and is never called when run as an applet.
    //////////////////////////////////////////////////////////////////////////
    
    /**
     * Simple constructor that takes arguments that were passed in via
     * the command line.
     */
	ChatDemo(String providerName, Vector providerParams, Vector chatTopics) 
	{
	    _providerName = providerName;
	    _providerParams = providerParams;
	    _chatTopicStrings = chatTopics; 
	}


   /**
    * Entry point for the program when it is run as an application.
    */
    public static void main(String [] args) 
	{
        
        if (args.length != 2 && args.length != 3) {
            printUsage();
            System.exit(1);
        }
		
		String providerName = args[0];						
		Vector providerParams = parseParams(args[1], ":");	
		
		// If chat rooms were specified at the command line...set
		// them as the chat rooms.
		Vector chatTopics;
		if (args.length == 3)
			chatTopics = parseParams(args[2], ",");
		else
			chatTopics = parseParams(ChatDemo.DEFAULT_TOPICS, ",");
		
	    // Initialize an instance of ChatDemo
		final ChatDemo chat = 
		    new ChatDemo(providerName, providerParams, chatTopics);   
		
		// Initialize the GUI
		chat.initGUI();								
		
		
		// Create a frame and put the chat instance in it.  The GUI will
		// be disabled until the JMS stuff initializes.
        final JFrame f = new JFrame("JMS Chat Demo");
        f.getContentPane().add(chat);
        
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.setVisible(false);
				chat.destroy();
                System.exit(0);
            }
        });
        
        f.setSize(640, 480);
        f.setVisible(true);
		
		chat.start();
    }

	/**
	 * Prints out an usage statement.
	 */
	private static void printUsage() 
	{
		System.err.println(
			"Usage: java ChatDemo <JMS Provider> <parameters> [chatroom1,chatroom2,chatroom3,...]\n"
			+"\t-----------------------MQ Series -------------------------------\n"
			+"\t JMS Provider = MQSERIES\n"
			+"\t parameters format:\n"
			+"\t\t<server name>:<port>:<queue manager name>[:<channel>]\n"
			+"\t---------------------------------------------------------------");
	}
	
}