/*
 * JMSProviderImpl.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */

package chatdemo.mqseries;

import java.util.Vector;
import com.ibm.mq.jms.MQTopicConnectionFactory;

import javax.jms.*;

/*****************************************************************************
 * Extension of MQTopicConnectionFactory, whose instance
 * initializes the factory with mq specific arguments.
 ****************************************************************************/
public class JMSProviderImpl extends MQTopicConnectionFactory
{

    private static MQTopicConnectionFactory onlyFactory = null;
    
	/**
	 * Creates a fully initialized instance which implements 
	 * TopicConnectionFactory.
	 */
    public static TopicConnectionFactory
        createTopicConnectionFactory(Vector args) 
            throws IllegalArgumentException, Exception
    {
        
        if (onlyFactory != null)
            return (TopicConnectionFactory) onlyFactory;
            
        onlyFactory = new MQTopicConnectionFactory();
        
        if (args == null || 3 > args.size() || args.size() > 4 ) {
            throw new 
                IllegalArgumentException("Invalid number of arguments");
        }
        
        try {
            onlyFactory.setTransportType(
                com.ibm.mq.jms.JMSC.MQJMS_TP_CLIENT_MQ_TCPIP);
            
			// Set the host name which is running the Queue Manager
			onlyFactory.setHostName((String)args.elementAt(0));
			
			// Set the port which the Queue Manager is listening on
            onlyFactory.setPort(new Integer((String)args.elementAt(1)).intValue());
			
			// Specify the Queue Manager to connect to.
            onlyFactory.setQueueManager((String)args.elementAt(2));
           
			// Specify the correct channel to use in the Queue Manager
            if (args.size() == 4)
                onlyFactory.setChannel((String)args.elementAt(3));
            else
                onlyFactory.setChannel("SYSTEM.DEF.SVRCONN");
            
            return (TopicConnectionFactory) onlyFactory;
        } catch (JMSException e) {
            throw e;
        }
    }
    
    	
	/**
	 * Used to create a Vector of javax.jms.Topic(s) from a Vector
	 * of Strings which represent the Topic names.
	 */
	public static Vector createTopics(Vector identifiers)
		throws JMSException
	{
        if (identifiers == null)
            return null;
        
        if (onlyFactory == null)
          throw new java.lang.IllegalStateException(
          "createTopicConnectionFactory() must be called before createTopics");
                

        Vector retVal = new Vector(identifiers.size());
        
        TopicSession session = onlyFactory.createTopicConnection().
            createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
            
	    for (int i = 0; i < identifiers.size(); i++) {
	        String topicName = (String) identifiers.elementAt(i);
	        topicName = topicName.replace(' ', '-');
	        Topic newTopic = session.createTopic(topicName);
	        retVal.addElement(newTopic);
	    }
	    
	    return retVal;
	}
	    
    
}