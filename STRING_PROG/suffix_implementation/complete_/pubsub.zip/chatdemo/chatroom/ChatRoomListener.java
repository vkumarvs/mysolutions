/*
 * ChatRoomListener.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */
package chatdemo.chatroom;

/*****************************************************************************
 * The listener interface for receiving information about the chat room.
 ****************************************************************************/
public interface ChatRoomListener {
    
    /**
     * Called whenever a new message arrives.
     */
    public void incomingMessage(ChatRoomMessage message);
    
    /**
     * Called whenever a user joins the chat room.  The method
     * is called even if the user is ignored.
     */
    public void userAdded(ChatRoomUser theUser);
    
    /**
     * Called whenever a user leaves the chat room.  The method
     * is called even if the user is being ignored.
     */
    public void userRemoved(ChatRoomUser theUser);

    
}