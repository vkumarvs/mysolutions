/*
 * ChatRoomUser.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */
package chatdemo.chatroom;


/*****************************************************************************
 * Simple class used to represent any user in a chat room.
 ****************************************************************************/
public class ChatRoomUser implements java.io.Serializable {
    
	protected String alias;
    protected String email;
    protected String uniqueID;

    protected boolean ignored;
    
    public ChatRoomUser(String alias) {
        this(alias, "");
    }
    
    public ChatRoomUser(String alias, String uniqueID) {
        this.alias    = alias;
        this.uniqueID = uniqueID;
        this.ignored  = false;
    }

      
    public String getAlias() {
        return alias;
    }    
    
    public String getUniqueID() {
        return uniqueID;    
    }    
    
    public void setAlias(String newValue) {
        alias = newValue;
    }
    
    public void setUniqueID(String newValue) {
        uniqueID = newValue;    
    }


    public boolean isIgnored() {
        return ignored;
    }
    
    public void ignore() {
        ignored = true;
    }
    
    public void listenTo() {
        ignored = false;
    }
    
	/**
	 * Overides <code>Object.equals()</code> to do a comparison of the users'
	 * uniqueIDs
	 */
    public boolean equals(Object obj) {
	    if (this == obj) {
	        return true;
	    }
	    if ((obj != null) && (obj instanceof ChatRoomUser)) {
	        return uniqueID.equals(((ChatRoomUser)obj).getUniqueID());
	    }
	    else
	        return false;
	}
	
	public String toString() {
	    return alias + ((ignored) ? " (ignored)" : "");
	}
}
