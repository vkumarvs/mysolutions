/*
 * ChatRoom.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 *
 */
 
package chatdemo.chatroom;

import java.util.Vector;
import java.io.Serializable;
						   
import javax.jms.*;

/*****************************************************************************
 *
 * Implementation of all ChatRoom logic using JMS publish/subscribe
 * mechanisms.
 *
 ****************************************************************************/
public class ChatRoom implements javax.jms.MessageListener
{
    private static final boolean DEBUG = true;
    
    private Vector          _listeners;
    private ChatRoomUser    _currentUser;
    private Vector			_connectedUsers;
    private TopicSession    _session;
    private Topic           _topic;
    private String          _topicName;
    private String 			_filter;
    private TopicPublisher  _publisher;
	private TopicSubscriber _subscriber;

    private boolean			_connected;
    
	// The following static final variables define properties that will
	// be set in every message header.
    private static final String TARGET_USER_PROPERTY  = "targetUser";
    private static final String TARGET_USER_ALL       = "all";	
    
    private static final String SENDER_USER_PROPERTY  = "sender";
    
    private static final String MESSAGE_TYPE_PROPERTY = "messageType";
    private static final short  REGULAR_MESSAGE       = 0;
    private static final short  JOIN_MESSAGE          = 1;
    private static final short  JOIN_REPLY_MESSAGE    = 2;
    private static final short  LEAVE_MESSAGE         = 3;
  
    /**
     * Main constructor for the chat room.  Once constructed, the instance
     * can be used multiple times to join() different chat rooms.
     */
    public ChatRoom(ChatRoomUser user, TopicConnection connection)
        throws JMSException
    {
        
        // Initialize all information.
        this._currentUser = user;
        
        // Create a pseudo unique ID for the user. 
        java.util.Random r = new java.util.Random();
        String r1 = new Long(r.nextLong()).toString();
		String r2 = new Long(r.nextLong()).toString();
        _currentUser.setUniqueID(user.getAlias() + r1 + 'x' + r2); 
		_currentUser.listenTo();
		
        _listeners = new Vector();
        _connectedUsers = new Vector();
        _filter = generateFilter();
        
        
        // Create the _session for this particular chat room connection.
        _session = 
		  connection.createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
 
        _connected = false;
    }

    /**
     * Joins the current user to the chat room specified by newTopic.
     */
    public void join(Topic newTopic) throws JMSException 
	{
        
		// If we are currently connected to a chat room we must leave it
		// first so the appropriate jms resources are released.  
        if (_connected == true)
            leave();
        
		_connected = true;
		_topic = newTopic;
		
        // Creates the subscriber, and sets the asynchronous message listener
        // which will be called ever there is a message published on the topic
        // that passes the filter.  The last boolean parameter tells the
        // subscriber not to ignore messages published from the same session.
        _subscriber = _session.createSubscriber(_topic, _filter, false);
        _subscriber.setMessageListener(this);
        
        // Finally create publisher that will be used to push all messages
        // to the chat room.
        _publisher = _session.createPublisher(_topic);
        
        // Add myself to the list of chatters in the room then send a message 
		// to everybody so that they know that I am here.
		addUser(_currentUser);
        sendMessage(_currentUser, TARGET_USER_ALL, JOIN_MESSAGE);
    }
    
    
    /**
     * Causes the current user to leave the current chat room if they
     * are connected to one.  Nothing happens if the user is not connected
     * to a chat room.
     */
    public void leave() throws JMSException 
	{
        if (_connected) {
            sendMessage(_currentUser, TARGET_USER_ALL, LEAVE_MESSAGE);
            _subscriber.close();
            _publisher.close();
            _connectedUsers = new java.util.Vector();
            _connected = false;
        }
    }
    
	/**
	 * Sends a private message to the specified <code>user</code>.
	 */
	public void privateMessage(ChatRoomUser user, ChatRoomMessage messageBody)
		throws JMSException
	{
		sendMessage(messageBody, user.getUniqueID(), REGULAR_MESSAGE);
	}
	
    /**
     * Sends the message to everybody in the chat room.
     */
    public void broadcastMessage(ChatRoomMessage messageBody) 
        throws JMSException
    {
        sendMessage(messageBody, TARGET_USER_ALL, REGULAR_MESSAGE);    
    }
    
    /**
     * Method used to send all messages.  broadcastMessage() calls this
     * method to send user objects, and the internal mechanisms use this
     * method to send system objects, which are used to coordinate activity
     * in the chat room.
     */
    private void sendMessage(Serializable body, String target, short type) 
        throws JMSException 
    {
        if (_connected) {
            // Create the message
            ObjectMessage message = _session.createObjectMessage();
            message.setStringProperty(TARGET_USER_PROPERTY, target);
            message.setShortProperty(MESSAGE_TYPE_PROPERTY, type);
            message.setStringProperty(SENDER_USER_PROPERTY, 
                                      _currentUser.getUniqueID());
            message.setObject(body);
            
            // Then send it.
            _publisher.publish(message,
                              DeliveryMode.NON_PERSISTENT,
                              4,    // Priority
                              0);   // TimeToLive 0 equals forever
                            
        }
    }
    

    /**
     * The user <code>u</code> will be ignored if they are currently
     * being listened to.  This will result in a new filter being generated
     * and applied.
     */
    public void ignoreUser(ChatRoomUser u) throws JMSException 
	{
        int loc;
        if ( (loc = _connectedUsers.indexOf(u)) != -1) {
            
            if (! u.isIgnored()) {
                u.ignore();
                String newFilter = generateFilter();
                if (! newFilter.equals(_filter)) {
                    _filter = newFilter;
       
                    applyFilter();
                    
                }
            }
        }
    }
    
    /**
     * The user <code>u</code> will be listened to if they are currently
     * being ignored.  This will result in a new filter being generated
     * and applied.
     */
    public void listenToUser(ChatRoomUser u) throws JMSException 
	{
        int loc;
        if ( (loc = _connectedUsers.indexOf(u)) != -1) {
            
            if (u.isIgnored()) {
                u.listenTo();
                String newFilter = generateFilter();
                if (! newFilter.equals(this._filter)) {
                    this._filter = newFilter;
                    applyFilter();
                }
            }
        }
    }
    

    /**
     * Generates a string that can be used as the filter in a subscriber.
     * There are basically two types of filters that could be produced.
     * A generic filter that does not ignore anybody:
     * 
     * <pre><tt> 
     *      (target = 'all') OR (target = 'me') 
     * </pre></tt>
     * 
     * Or a filter could be produced which filters out ignored users' regular
     * messages:
     * 
     * <pre><tt>
     *      ( (target = 'all') OR (target = 'me') ) AND 
     *          ( (sender NOT IN ('ignored', 'ignored2', 'ignored3')) OR
     *               (messageType <> REGULAR_MESSAGE) )
     * </pre></tt>
     */
    private String generateFilter() 
	{
        
        // The base filter states that we want all messages who are targeted
        // to everybody or to the _currentUser.
        String base = "("+TARGET_USER_PROPERTY+" = '"+TARGET_USER_ALL
			+ "') OR ("
				+ TARGET_USER_PROPERTY+" = '"+_currentUser.getUniqueID()+"')";
        
        // Generate a SQL type list of users to ignore (if any)
        String ignoredUsers = null;
        for (int i = 0 ; i < _connectedUsers.size(); i++) {
            ChatRoomUser temp = (ChatRoomUser) _connectedUsers.elementAt(i);
            if (temp.isIgnored()) {
                if (ignoredUsers == null)
                    ignoredUsers = "'" + temp.getUniqueID() + "'";
                else 
                    ignoredUsers = 
						ignoredUsers + ", '" + temp.getUniqueID() + "'";
                
            }
        }
        
        // Return the correct form of the filter.
        if (ignoredUsers == null)
            return base;
        else 
            return "("+base+") AND ( ("+ 
                        SENDER_USER_PROPERTY + " NOT IN (" + ignoredUsers 
							+ ")) OR ("
								+ MESSAGE_TYPE_PROPERTY 
									+ " <> "+ REGULAR_MESSAGE+") )";
    }


    /**
     * Method to that starts a new TopicSubscriber with the currently defined
     * _filter.  No special care is taken to ensure that messages are not
     * lost from the time the first to subscriber is shutdown till the 
     * messageListener is set on the new subscriber.
     */
    private void applyFilter() throws JMSException 
	{
        _subscriber.close();
        _subscriber = _session.createSubscriber(_topic, _filter, false);
        _subscriber.setMessageListener(this);
    }

    
    /**
     * This is the asynchronous message listener.  It should only be called by
     * JMS.  The method contains much of the logic that makes the chat room
     * work.
     */
    public void onMessage(Message message) 
	{
		short			messageType;
        String			targetUser;
		Object			messageObject;
		ChatRoomMessage crm;
		ChatRoomUser	theUser;
		int				loc;
		
        try {
            messageObject = ( (ObjectMessage)message).getObject();
            messageType = 
                message.getShortProperty(ChatRoom.MESSAGE_TYPE_PROPERTY);
            targetUser  = 
                message.getStringProperty(ChatRoom.TARGET_USER_PROPERTY);
		} catch (JMSException e) { return; }
            
        switch (messageType) {


            // Regular messages are the actual chatting that is going
            // on.  No special action is required.
            case (REGULAR_MESSAGE) :
        
                crm = (ChatRoomMessage) messageObject;
				fireMessage(crm);
                break;
            
			// Join messages are sent by new users entering the chat room.
			// We need to notify all of our ChatRoomListeners of the new
			// user and then send a JOIN_REPLY_MESSAGE back to the new user 
			// so that they can know who is in the chat room.
			//
            case (ChatRoom.JOIN_MESSAGE) :
                ChatRoomUser newUser = (ChatRoomUser) messageObject;
                
                loc = _connectedUsers.indexOf(newUser);
                if ( loc == -1 ) {        
                    addUser(newUser);
                    
                    try {
                        sendMessage(_currentUser, newUser.getUniqueID(),
                                    JOIN_REPLY_MESSAGE);
                    } catch (JMSException e) { return; }	                    
                    
                }
                break;      
            
            // Message sent to us by everyone in the chat room after
            // the join message is broadcast.
            //
            case (ChatRoom.JOIN_REPLY_MESSAGE) :
                
                // Add the user to the list of chatters without
                // notification in the message display
                addUser((ChatRoomUser) messageObject);
                break;
            
            // Message sent by chatters that are leaving the chat room.
            case (ChatRoom.LEAVE_MESSAGE) :
                ChatRoomUser leavingUser = (ChatRoomUser) messageObject;
                
                if (_connectedUsers.indexOf(leavingUser) != -1 ) {
                    removeUser(leavingUser);
                }
            
                break;        
        
            
        }
    }   
           
        
    /** 
     * Adds a listener which will be notified of incoming messages.
     * 
     * @see ChatRoomListener
     */
    public synchronized void addChatRoomListener(ChatRoomListener crl) 
	{
        _listeners.addElement(crl);
    }
    
    /** 
     * Remove the specified ChatRoomListener so that it no longer is notified
     * about incoming messages
     * 
     * @see ChatRoomListener
     */
    public synchronized void removeMessageListener(ChatRoomListener crl) 
	{
        int loc;
        if ( (loc = _listeners.indexOf(crl, 0)) != -1)
            _listeners.removeElementAt(loc);
    }
    
	
    /** Notify all _listeners of the new message */
    private void fireMessage(ChatRoomMessage message) 
	{                    
        for(int i = 0; i < _listeners.size(); ++i)
            ( (ChatRoomListener)_listeners.elementAt(i) )
				.incomingMessage(message);
  
    }
    
    /** Notify all _listeners of a new user */
    private synchronized void fireUserAdded(ChatRoomUser theUser) 
	{
        for(int i = 0; i < _listeners.size(); ++i)
            ( (ChatRoomListener)_listeners.elementAt(i) )
				.userAdded(theUser);
    }
    
    /** Notify all listneres of a user that is being removed */
    private synchronized void fireUserRemoved(ChatRoomUser theUser) 
	{
    
        for(int i = 0; i < _listeners.size(); ++i)
            ( (ChatRoomListener)_listeners.elementAt(i) )
				.userRemoved(theUser);
   
    }

    private void addUser(ChatRoomUser user) 
	{
        _connectedUsers.addElement(user);
        fireUserAdded(user);
    }
    
 
    private void removeUser(ChatRoomUser user) 
	{
        int loc = _connectedUsers.indexOf(user);
        if ( loc != -1 ) {
            _connectedUsers.removeElementAt(loc);
            fireUserRemoved(user);
        }
    }
    
}