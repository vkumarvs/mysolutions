/*
 * ChatRoomMessage.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */
 
package chatdemo.chatroom;

/*****************************************************************************
 * Defines the content of all user messages sent in a chat room.
 ****************************************************************************/
public class ChatRoomMessage implements java.io.Serializable {
    
    protected String                    message = null;
    protected ChatRoomUser              sender = null;
    
    public ChatRoomMessage() {
        this("", null);
    }
    
    public ChatRoomMessage(String message) {
        this(message, null);
    } 
    
    public ChatRoomMessage(String message, ChatRoomUser user) {
        this.message = message;
        this.sender = user;
    }
    
    
    public ChatRoomUser getSender() {
        return sender;
    }
    public void setSender(ChatRoomUser newValue) {
        sender = newValue;
    }
    
    public String getMessage() {
        return message;
    }
    public void setMessage(String newValue) {
        message = newValue;
    }

    
    public String toString() {
        return sender.toString() + ": " + message;
    }
}

    