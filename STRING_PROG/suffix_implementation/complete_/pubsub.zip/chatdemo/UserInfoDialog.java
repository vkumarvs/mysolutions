/*
 * UserInfoDialog.java
 *
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */
package chatdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*****************************************************************************
 * An overly simplistic dialog to prompt the user for the alias they wish 
 * to use while in the chat rooms.
 ****************************************************************************/
public class UserInfoDialog extends JDialog {
        
    JTextField userID = new JTextField();
    JButton okButton = new JButton("OK");
    	
    public UserInfoDialog(JFrame parent) {
        super(parent);
            
        setModal(true);
        setTitle("Enter Chat User Name");
        setResizable(false);
        setSize(255,75);
        setVisible(false);
            
        okButton.setPreferredSize(new Dimension(70, 1));
        userID.setPreferredSize(new Dimension(1, 25));
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(userID, BorderLayout.NORTH);
        getContentPane().add(okButton, BorderLayout.EAST);
            
            
            
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (!(userID.getText().equals("")))
                    setVisible(false);          
            }
        });
    }
        
    public String getUserID() {
        return userID.getText();   
    }
        
}
