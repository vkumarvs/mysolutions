/*
 * JMSProvider.java
 * 
 * Copyright (c) 2000 Dan Greff. All Rights Reserved
 *
 * Redistribution and use in source and binary forms are permitted provided
 * that the above copyright notice and this paragraph are duplicated in all
 * such forms and that any documentation, advertising materials, and other 
 * materials related to such distribution and use acknowledge that the 
 * software was developed by Dan Greff.  The name of Dan Greff may not be 
 * used to endorse or promote products derived from this software without 
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF 
 * MERCHANTIBILITY AND FITNESS FOR ANY PURPOSE.
 *
 * @version 1.0 01/03/2000
 * @author  Dan Greff
 */

package chatdemo;

import java.util.Vector;

import java.lang.reflect.Method;
import javax.jms.*;

/*****************************************************************************
 * Class whose static methods provide provider implementations of top level
 * JMS interfaces.  Reflection is used to so that all implementations' classes
 * need not be available at either compile time or during run time.  Ideally
 * there would be more than would JMS implementation represented, but there
 * was not time to experiement with other implementations.
 ****************************************************************************/
public class JMSProvider  
{
	
    public static final String MQSERIES = "MQSERIES";
    
    /**
     * Returns the <code>providerName</code> implementation of 
     * TopicConnectionFactory initialized with the 
     * <code>configurationParameters</code>
     */
    public static TopicConnectionFactory createTopicConnectionFactory(
		String providerName, Vector configurationParameters)
			throws Exception, IllegalArgumentException
    {
        
		Class factoryClass = getProviderImplementation(providerName);
		
		Method theMethod =  factoryClass.getMethod(
		    "createTopicConnectionFactory",
		    new Class[] { Class.forName("java.util.Vector") });
		
		return (TopicConnectionFactory)
		    theMethod.invoke(null, new Object [] { configurationParameters});
		    
		    
    }
	
	/**
	 * Used to create a Vector of javax.jms.Topic(s) from a Vector
	 * of Strings which represent the Topic names.
	 */
	public static Vector createTopics(
		String provider, Vector identifiers)
			throws Exception, IllegalArgumentException
	{
        Class factoryClass = getProviderImplementation(provider);
		
		Method theMethod =  factoryClass.getMethod(
		    "createTopics",
		    new Class[] { Class.forName("java.util.Vector") });
		
		return (Vector) theMethod.invoke(null, new Object [] {identifiers});
		
		
	}
    
    
    
	/**
	 * Make changes here if adding another JMS implementation. 
	 */
	private static Class getProviderImplementation(String provider)
		throws IllegalArgumentException, ClassNotFoundException
	{
		
		String factoryClassName;
		
	    if (provider.equals(MQSERIES))
	        factoryClassName = "chatdemo.mqseries.JMSProviderImpl";
		else 
			throw new IllegalArgumentException("Unknown Factory Type");

		
		return Class.forName(factoryClassName);
		
	
	}
}