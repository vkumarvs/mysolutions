#include <windows.h>
#include <string.h>
#include <process.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// SRC, DEST, PID
	char param[3][MAX_PATH] = {"", "", ""}, *p1 = lpCmdLine, *p2;
	int count = 0, pid;

	while ( count < 3 && p1 - lpCmdLine < strlen(lpCmdLine) )
	{
		p2 = strchr(p1, ' ');
		if ( p2 )
			strncpy(param[count++], p1, p2 - p1);
		else
			strcpy(param[count++], p1);
		p1 = p2 + 1;
	}

	if ( count == 3 )
	{
		pid = atoi(param[2]);
		// Wait till main program exits
		HANDLE hProcess = OpenProcess(SYNCHRONIZE, FALSE, pid);
		WaitForSingleObject(hProcess, INFINITE);

		if ( CopyFile(param[0], param[1], FALSE) )
		{
			if ( MessageBox(NULL, "Program successfully updated. Launch the application?", "UPDATE", MB_YESNO|MB_ICONQUESTION) == IDYES )
				_execl(param[1], param[1], NULL);
		}
		else
			MessageBox(NULL, "CopyFile failed.", "UPDATE", MB_OK);
	}
	return 0;
}