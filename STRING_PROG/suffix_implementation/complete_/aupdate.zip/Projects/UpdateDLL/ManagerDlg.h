// ManagerDlg.h : header file
//
#pragma once

/////////////////////////////////////////////////////////////////////
// CManagerDlg dialog
class CManagerDlg : public CDialog
{
// Construction
public:
	CManagerDlg(BOOL bAdmin = FALSE, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CManagerDlg)
	enum { IDD = IDD_MANAGER };
	int		m_AccessMode;
	CString	m_FileName;
	CString	m_Password;
	CString	m_Server;
	CString	m_UserName;
	CString	m_Version;
	//}}AFX_DATA
	CString m_OrgServer, m_OrgUserName, m_OrgPassword, m_OrgVersion;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManagerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CManagerDlg)
	afx_msg void OnClear();
	afx_msg void OnCheck();
	afx_msg void OnUpload();
	afx_msg void OnChangeServer();
	afx_msg void OnSelchangeAccess();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
