// ManagerDlg.cpp : implementation file
//
#include <afxwin.h>
#include <afxdlgs.h>
#include <afxinet.h>
#include "Resource.h"
#include "Update.h"
#include "VersionDlg.h"
#include "ManagerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////
// Private variables
extern CString	AppName, Server, UserName, Password, AppVersion, Version;
extern BOOL		bUseFTP, bSetup;

/////////////////////////////////////////////////////////////////////
// Private routines
void SetStatus(LPCSTR Msg);
void Init(LPCSTR server, LPCSTR username, LPCSTR password);
BOOL Upload(LPCSTR FilePath, LPCSTR FileVersion);
BOOL Clear();

/////////////////////////////////////////////////////////////////////
// CManagerDlg dialog
CManagerDlg::CManagerDlg(BOOL bAdmin, CWnd* pParent)
	: CDialog(CManagerDlg::IDD + bAdmin, pParent)
{
	//{{AFX_DATA_INIT(CManagerDlg)
	m_AccessMode = bUseFTP;
	m_Password = Password;
	m_Server = Server;
	m_UserName = UserName;
	m_Version = Version;
	//}}AFX_DATA_INIT
	m_OrgServer = Server;
	m_OrgUserName = UserName;
	m_OrgPassword = Password;
	m_OrgVersion = Version;

	if ( Version != "" )
		if ( bSetup )
			m_FileName = "Setup.exe";
		else
			m_FileName = AppName + ".exe";
	else
		m_FileName = "";
}

void CManagerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManagerDlg)
	DDX_CBIndex(pDX, IDC_ACCESS, m_AccessMode);
	DDX_Text(pDX, IDC_FILENAME, m_FileName);
	DDX_Text(pDX, IDC_PASSWORD, m_Password);
	DDX_Text(pDX, IDC_SERVER, m_Server);
	DDX_Text(pDX, IDC_USER, m_UserName);
	DDX_Text(pDX, IDC_VERSION, m_Version);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CManagerDlg, CDialog)
	//{{AFX_MSG_MAP(CManagerDlg)
	ON_BN_CLICKED(ID_CLEAR, OnClear)
	ON_BN_CLICKED(ID_CHECK, OnCheck)
	ON_BN_CLICKED(ID_UPLOAD, OnUpload)
	ON_EN_CHANGE(IDC_SERVER, OnChangeServer)
	ON_CBN_SELCHANGE(IDC_ACCESS, OnSelchangeAccess)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDHELP, CWnd::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////
// CManagerDlg message handlers
void CManagerDlg::OnClear() 
{
	UpdateData();
	::Init(m_Server, m_UserName, m_Password);

	if ( ::Clear() )
	{
		m_Version = "";
		m_FileName = "";
		UpdateData(FALSE);
	}
}

void CManagerDlg::OnCheck() 
{
	UpdateData();
	::Init(m_Server, m_UserName, m_Password);

	if ( ::auCheck() )
	{
		m_Version = Version;
		if ( Version != "" )
			if ( bSetup )
				m_FileName = "Setup.exe";
			else
				m_FileName = AppName + ".exe";
		else
			m_FileName = "";
	}
	else
	{
		m_Version = "";
		m_FileName = "";
	}
	UpdateData(FALSE);
}

void CManagerDlg::OnUpload() 
{
	UpdateData();

	// Create restrictive filter
	CString S;
	S.Format("%s executable (%s.exe)|%s.exe|Setup executable (Setup.exe)|Setup.exe||",
		AppName, AppName, AppName);

	CFileDialog dlg(TRUE, NULL, NULL, NULL, S, this);
	if ( dlg.DoModal() == IDOK )
	{
		if ( dlg.GetFileName() == "Setup.exe" )
		{
			CVersionDlg VersionDlg(this);
			if ( VersionDlg.DoModal() != IDOK )
				return;
			m_Version = VersionDlg.m_Version;
		}

		// Update window and status line text
		::SetStatus("Uploading file...");
		UpdateWindow();

		::Init(m_Server, m_UserName, m_Password);

		if ( ::Clear() && ::Upload(dlg.GetPathName(), m_Version) )
		{
			m_FileName = dlg.GetFileName();
			m_Version = Version;
			UpdateData(FALSE);
		}
		::SetStatus("Ready");
	}
}

void CManagerDlg::OnSelchangeAccess() 
{
	UpdateData();
	if ( m_AccessMode == 0 )
		if ( m_Server.Left(2) != "\\\\" )
			m_Server = "\\\\" + m_Server;
		else;
	else
	{
		for ( int i = 0; m_Server[i] == '\\' && i <
			m_Server.GetLength(); i++ ) ;
		m_Server = m_Server.Mid(i);
	}
	UpdateData(FALSE);	
}

void CManagerDlg::OnChangeServer() 
{
	UpdateData();
	m_AccessMode = !m_Server.GetLength() || m_Server[0] != '\\';
	UpdateData(FALSE);	
}

void CManagerDlg::OnCancel() 
{
	::Init(m_OrgServer, m_OrgUserName, m_OrgPassword);
	Version = m_OrgVersion;
	CDialog::OnCancel();
}
