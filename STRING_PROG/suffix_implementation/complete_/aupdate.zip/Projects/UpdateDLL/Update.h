// Update.h : header file for UPDATE.DLL
//

// AutomatedUpdate initialization
extern "C" LPCSTR PASCAL auInit(LPCSTR Company, LPCSTR AppName = NULL, HINSTANCE hInstance = NULL,
	void* pMainFrm = NULL, LPCSTR Server = NULL, LPCSTR UserName = NULL,
	LPCSTR Password = NULL);

// Check for application update
extern "C" BOOL PASCAL auCheck(BOOL bSilent = FALSE);

// Display AutomatedUpdate manager dialog
extern "C" BOOL PASCAL auManage(BOOL bAdmin = FALSE);
