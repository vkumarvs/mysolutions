// Update.cpp : Defines the initialization routines for the DLL.
//
#include <afxwin.h>
#include <afxinet.h>
#include <WinNetwk.h>
#include <Process.h>
#include "Resource.h"
#include "ManagerDlg.h"

// AutomatedUpdate variables
CString	AppName, Server, UserName, Password, AppVersion, Version;
BOOL	bUseFTP, bSetup;

// MFC MainFrame pointer
CFrameWnd* pMainFrame = NULL;

CString	RemoteExe, RemoteInf, RemoteSetup, RemotePath, LocalPath,
	AppOld, AppNew, AppExe, UpdExe, SetupExe, FtpSite, KeyName;

/////////////////////////////////////////////////////////////////////
// Private routines
BOOL GetFileVersion(LPCSTR FileName, CString& Version);
void SetStatus(LPCSTR Msg);
void Init(LPCSTR server, LPCSTR username, LPCSTR password);
BOOL SaveSettings();

/////////////////////////////////////////////////////////////////////
// CSysException
class CSysException: public CException {
public:
	CString m_ErrorMsg;

	CSysException() : CException(TRUE)
	{
		LPVOID lpMsgBuf;
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL, GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR) &lpMsgBuf, 0, NULL);

		m_ErrorMsg = (LPCSTR)lpMsgBuf;
		LocalFree(lpMsgBuf);
	}

	BOOL GetErrorMessage(LPTSTR lpszError, UINT nMaxError,
		PUINT pnHelpContext = NULL)
	{
		strncpy(lpszError, (LPCSTR)m_ErrorMsg, nMaxError);
		return TRUE;
	}
};

///////////////////////////////////////////////////////////////////////
// Initialize AutomatedUpdate
extern "C" LPCSTR PASCAL auInit(LPCSTR company, LPCSTR appname,
	HINSTANCE hInstance, void* pWnd, LPCSTR server,
	LPCSTR username, LPCSTR password)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	pMainFrame = (CFrameWnd*)pWnd;

	// Get application directory path
	char path[MAX_PATH];
	::GetModuleFileName(hInstance, path, sizeof(path));
	GetFileVersion(path, AppVersion);
	*(strrchr(path, '\\') + 1) = '\0';
	LocalPath = path;

	// Initialize AutomatedUpdate
	HKEY hKey = NULL;
	AppName = appname;
	KeyName.Format("Software\\%s\\%s\\AutomatedUpdate", company, AppName);
	
	// Defaults for connection parameters
	Server = server;
	UserName = username;
	Password = password;

	// Set local pathes
	AppNew = LocalPath + AppName + ".new";
	AppOld = LocalPath + AppName + ".old";
	AppExe = LocalPath + AppName + ".exe";
	SetupExe = LocalPath + "Setup.exe";
	UpdExe = LocalPath + "Update.exe";

	// Read information from registry
	if ( ::RegOpenKeyEx(HKEY_LOCAL_MACHINE, KeyName,
		NULL, KEY_READ, &hKey) == ERROR_SUCCESS )
	{
		char value[32] = "";
		DWORD size = sizeof(value);
		DWORD dwType = REG_SZ;

		if ( ::RegQueryValueEx(hKey, "Server", NULL, &dwType,
			(BYTE*)value, &size) == ERROR_SUCCESS )
			Server = value;
		size = sizeof(value);
		if ( ::RegQueryValueEx(hKey, "UserName", NULL, &dwType,
			(BYTE*)value, &size) == ERROR_SUCCESS )
			UserName = value;
		size = sizeof(value);
		if ( ::RegQueryValueEx(hKey, "Password", NULL, &dwType,
			(BYTE*)value, &size) == ERROR_SUCCESS )
			Password = value;
		size = sizeof(value);
		::RegCloseKey(hKey);
	}
	Init(Server, UserName, Password);

	return AppVersion;
}

/////////////////////////////////////////////////////////////////////
// Check for update
extern "C" BOOL PASCAL auCheck(BOOL bSilent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// Update parent window status
	SetStatus("Checking for update...");

	BOOL bStatus = FALSE;
	CInternetSession* pInetSession = NULL;
	CFtpConnection* pFtpConnection = NULL;

	// Clear new version
	Version = "";
	bSetup = FALSE;

	TRY {
		// Get remote application version information
		if ( bUseFTP )
		{
			// Create INet session
			pInetSession = new CInternetSession(NULL, 1,
				PRE_CONFIG_INTERNET_ACCESS, NULL, NULL,
				INTERNET_FLAG_DONT_CACHE);
			
			// Create FTP connection
			pFtpConnection = pInetSession->GetFtpConnection(FtpSite,
				UserName, Password);

			CFtpFileFind FF(pFtpConnection);

			// Find Setup.exe
			bSetup = FF.FindFile(RemoteSetup);

			// Make sure that either application EXE or Setup.exe exists
			if ( bSetup || FF.FindFile(RemoteExe) )
			{
				// Open and read .INF file
				CInternetFile* pFile = pFtpConnection->OpenFile(RemoteInf);
				if ( pFile )
				{
					pFile->ReadString(Version);
					delete pFile;
				}
			}
		}
		else
		{
			// Establish network connection
			NETRESOURCE nr;
			nr.dwScope = 0;// RESOURCE_GLOBALNET
			//nr.dwUsage = RESOURCEUSAGE_CONNECTABLE;
			nr.dwType = RESOURCETYPE_DISK;
			nr.lpLocalName = nr.lpProvider = NULL;
			nr.lpRemoteName = (LPSTR)(LPCSTR)Server;
			if ( UserName != "" && ::WNetAddConnection2(&nr,
				Password != "" ? (LPCSTR)Password : NULL,
				UserName != "" ? (LPCSTR)UserName : NULL, 0) != NO_ERROR )
				THROW(new CSysException());

			// Get application executable version
			GetFileVersion(RemoteExe, Version);

			// Find Setup.exe
			bSetup = CFileFind().FindFile(RemoteSetup);

			// Get the version number from .INF file
			if ( bSetup )
			{
				CStdioFile File;
				// Open and read .INF file
				CFileException err;
				if (  File.Open(RemoteInf, CFile::modeRead|
					CFile::typeText|CFile::shareDenyNone, &err) )
				{
					CString SetupVersion;
					File.ReadString(SetupVersion);
					if ( SetupVersion > Version )
					{
						bSetup = TRUE;
						Version = SetupVersion;
					}
				}
				//else
				//	err.ReportError();
			}
		}

		// Compare versions
		if ( Version > AppVersion )
			if ( AfxMessageBox(IDS_UPDATE_PROCEED, MB_YESNO|
				MB_ICONQUESTION) == IDYES )
			{
				::SetStatus("Writing new executable to disk...");

				if ( !::CopyFile(AppExe, AppOld, FALSE) )
					THROW(new CSysException());

				// Obtain process ID
				CString PID;
				PID.Format("%i", ::GetCurrentProcessId());

				if ( bUseFTP )
				{
					// Download and run Setup.exe
					if ( bSetup )
						if ( pFtpConnection->GetFile(RemoteSetup,
							SetupExe, FALSE) )
							_execl(SetupExe, SetupExe, NULL);
						else
							THROW(new CSysException());
					else
						// Download new application executable
						if ( pFtpConnection->GetFile(RemoteExe, AppNew,
							FALSE) )
							_execl(UpdExe, UpdExe, AppNew, AppExe, PID,
								NULL);
						else
							THROW(new CSysException());
				}
				else
				{
					if ( bSetup )
					{
						// Run Setup.exe
						_execl(RemoteSetup, RemoteSetup, NULL);
						AfxMessageBox(IDS_SETUP_FAILED);
					}
					else
					{
						// Replacing application executable
						_execl(UpdExe, UpdExe, RemoteExe, AppExe, PID,
							NULL);
						AfxMessageBox(IDS_UPDATE_FAILED);
					}
				}
			}
			else
				bStatus = TRUE;
		else
		{
			if ( !bSilent ) AfxMessageBox("Progam is up to date.");
			bStatus = TRUE;
		}
	}
	CATCH_ALL(e) {
		e->ReportError();
	}
	END_CATCH_ALL

	// Clean up
	if ( pFtpConnection )
		delete pFtpConnection;
	if ( pInetSession )
		delete pInetSession;
	// Close network connection
	if ( !bUseFTP )
		::WNetCancelConnection2(Server, 0, FALSE);

	// Update parent window status
	SetStatus("Ready");
	return bStatus;
}

/////////////////////////////////////////////////////////////////////
// Open AutomatedUpdate manager window
extern "C" BOOL PASCAL auManage(BOOL bAdmin)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CManagerDlg dlg(bAdmin, pMainFrame);
	if ( dlg.DoModal() == IDOK )
	{
		Init(dlg.m_Server, dlg.m_UserName, dlg.m_Password);
		return SaveSettings();
	}
	return FALSE;
}

/////////////////////////////////////////////////////////////////////
// Misc. helper routines

// Get file version
BOOL GetFileVersion(LPCSTR FileName, CString& Version)
{
	VS_FIXEDFILEINFO* pVersion;
	BOOL Status = FALSE;
	char* data;
	DWORD handle;
	UINT size = ::GetFileVersionInfoSize((LPSTR)FileName, &handle);

	if ( size )
	{
		data = new char[size];

		if ( ::GetFileVersionInfo((LPSTR)FileName, handle, size, data) &&
			::VerQueryValue(data, "\\",  (void**)&pVersion, &size) )
		{
			Version.Format("%i.%i.%i",
				pVersion->dwProductVersionMS/65536UL,
				pVersion->dwProductVersionMS%65536UL,
				pVersion->dwProductVersionLS/65536UL);
			Status = TRUE;
		}
		delete data;
	}
	return Status;
}

// Update main application window status text
void SetStatus(LPCSTR Msg)
{
	if ( pMainFrame )
	{
		pMainFrame->SetMessageText(Msg);
		pMainFrame->UpdateWindow();

		if ( strcmp(Msg, "Ready") == 0 )
			pMainFrame->EndWaitCursor();
		else
			pMainFrame->BeginWaitCursor();
	}
}

// Setup AutomatedUpdate variables
void Init(LPCSTR server, LPCSTR username, LPCSTR password)
{
	Server = server;
	UserName = username;
	Password = password;
	bUseFTP = Server[0] != '\\';

	if ( bUseFTP )
	{
		int pos = Server.Find('\\');
		if ( pos != -1 )
		{
			RemotePath = Server.Mid(pos) + "\\" + AppName + "\\";
			FtpSite = Server.Left(pos);
		}
		else
		{
			RemotePath.Format("\\%s\\", AppName);
			FtpSite = Server;
		}
	}
	else
		RemotePath = Server + "\\" + AppName + "\\";
	
	RemoteExe = RemotePath + AppName + ".exe";
	RemoteSetup = RemotePath + "Setup.exe";
	RemoteInf = RemotePath + "VERSION.INF";
}

/////////////////////////////////////////////////////////////////////
// Upload executable to server
BOOL Upload(LPCSTR FilePath, LPCSTR FileVersion)
{
	BOOL bStatus = FALSE;
	CString version(FileVersion), FileName(FilePath);
	CFtpConnection* pFtpConnection = NULL;

	// Extract file name
	FileName = FileName.Mid(FileName.ReverseFind('\\') + 1);

	TRY {
		// Exit when can not determine version of the executable
		if ( FileName.CompareNoCase("Setup.exe") != 0 &&
			!::GetFileVersion(FilePath, version) )
			THROW(new CSysException());

		// Create temporary .INF file
		CStdioFile File("VERSION.INF", CFile::modeCreate|
			CFile::modeWrite|CFile::typeText);
		File.WriteString(version);
		File.Close();

		if ( bUseFTP )
		{
			// Create INet session
			CInternetSession InetSession(NULL, 1,
				PRE_CONFIG_INTERNET_ACCESS, NULL, NULL,
				INTERNET_FLAG_DONT_CACHE);
			
			// Create FTP connection
			pFtpConnection = InetSession.GetFtpConnection(FtpSite,
				UserName, Password);

			// Upload the file
			if ( !(pFtpConnection->PutFile(FilePath, RemotePath +
				FileName) && pFtpConnection->PutFile("VERSION.INF",
				RemoteInf)) )
			{
				SetLastError(ERROR_ACCESS_DENIED);
				THROW(new CSysException());
			}
		}
		else
		{
			// WinNetwork resource variable
			NETRESOURCE nr;
			nr.dwScope = 0;
			nr.dwType = RESOURCETYPE_DISK;
			nr.lpLocalName = nr.lpProvider = NULL;
			nr.lpRemoteName = (LPSTR)(LPCSTR)Server;

			// Establish network connection and copy files
			if ( (UserName != "" && ::WNetAddConnection2(&nr,
				Password != "" ? (LPCSTR)Password : NULL,
				UserName != "" ? (LPCSTR)UserName : NULL, 0) !=
				NO_ERROR) ||
				!::CopyFile(FilePath, RemotePath + FileName, FALSE) ||
				!::CopyFile("VERSION.INF", RemoteInf, FALSE) )
				THROW(new CSysException());
		}

		// Delete temporary .INF file
		::DeleteFile("VERSION.INF");
		Version = version;
		bStatus = TRUE;
	}
	CATCH_ALL(e) {
		e->ReportError();
	}
	END_CATCH_ALL

	// Clean up
	if ( pFtpConnection )
		delete pFtpConnection;
	// Close network connection
	if ( !bUseFTP )
		::WNetCancelConnection2(Server, 0, FALSE);

	return bStatus;
}

/////////////////////////////////////////////////////////////////////
// Clear server directory
BOOL Clear()
{
	CFtpConnection* pFtpConnection = NULL;
	BOOL bStatus = FALSE;

	TRY {
		if ( bUseFTP )
		{
			// Create INet session
			CInternetSession InetSession(NULL, 1,
				PRE_CONFIG_INTERNET_ACCESS, NULL, NULL,
				INTERNET_FLAG_DONT_CACHE);

			// Create FTP connection
			pFtpConnection = InetSession.GetFtpConnection(FtpSite,
				UserName, Password);
			CFtpFileFind FF(pFtpConnection);

			// Search for files and delete them
			if ( FF.FindFile(RemoteExe) &&
				!pFtpConnection->Remove(RemoteExe) ||
				FF.FindFile(RemoteSetup) &&
				!pFtpConnection->Remove(RemoteSetup) ||
				FF.FindFile(RemoteInf) &&
				!pFtpConnection->Remove(RemoteInf) )
			{
				SetLastError(ERROR_ACCESS_DENIED);
				THROW(new CSysException());
			}
			bStatus = TRUE;
		}
		else
		{
			// WinNetwork resource variable
			NETRESOURCE nr;
			nr.dwScope = 0;
			nr.dwType = RESOURCETYPE_DISK;
			nr.lpLocalName = nr.lpProvider = NULL;
			nr.lpRemoteName = (LPSTR)(LPCSTR)Server;

			// Establish network connection
			if ( UserName != "" && ::WNetAddConnection2(&nr,
				Password != "" ? (LPCSTR)Password : NULL,
				UserName != "" ? (LPCSTR)UserName : NULL, 0) !=
				NO_ERROR )
				THROW(new CSysException());

			CFileFind FF;
			// Search for files and delete them
			if ( FF.FindFile(RemoteExe) && !::DeleteFile(RemoteExe) ||
				FF.FindFile(RemoteSetup) && !::DeleteFile(RemoteSetup) ||
				FF.FindFile(RemoteInf) && !::DeleteFile(RemoteInf) )
				THROW(new CSysException());
			bStatus = TRUE;
		}
	}
	CATCH_ALL(e) {
		e->ReportError();
	}
	END_CATCH_ALL

	// Clean up
	if ( pFtpConnection )
		delete pFtpConnection;
	// Close network connection
	if ( !bUseFTP )
		::WNetCancelConnection2(Server, 0, FALSE);

	return bStatus;
}

/////////////////////////////////////////////////////////////////////
// Save AutomatedUpdate settings
BOOL SaveSettings()
{
	BOOL bStatus = FALSE;
	HKEY hKey = NULL;
	DWORD dwDisp = 0L;
	
	// Write registry information
	if ( ::RegCreateKeyEx(HKEY_LOCAL_MACHINE, KeyName, NULL,
		"AutomatedUpdate", 0L, KEY_WRITE, NULL, &hKey,
		&dwDisp) == ERROR_SUCCESS &&
		::RegSetValueEx(hKey, "Server", NULL, REG_SZ,
		(BYTE*)(LPCSTR)Server, Server.GetLength() + 1) ==
		ERROR_SUCCESS &&
		::RegSetValueEx(hKey, "UserName", NULL, REG_SZ,
		(BYTE*)(LPCSTR)UserName, UserName.GetLength() + 1) ==
		ERROR_SUCCESS &&
		::RegSetValueEx(hKey, "Password", NULL, REG_SZ,
		(BYTE*)(LPCSTR)Password, Password.GetLength() + 1) == 
		ERROR_SUCCESS )
		bStatus = TRUE;
	else
		AfxMessageBox(IDS_SAVESETTINGS_FAILED);
	
	if ( hKey ) ::RegCloseKey(hKey);
	return bStatus;
}

