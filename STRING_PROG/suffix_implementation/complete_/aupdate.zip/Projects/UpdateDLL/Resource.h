//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Update.rc
//
#define IDOK2                           3
#define IDHELP                          9
#define IDD_VERSION                     103
#define IDD_MANAGER                     189
#define IDD_MANAGERA                    190
#define IDC_SERVER                      1129
#define ID_CLEAR                        1138
#define IDC_ACCESS                      1139
#define IDC_MODE                        1140
#define IDC_VERSION                     1142
#define ID_UPLOAD2                      1143
#define ID_UPLOAD                       1143
#define IDC_FILENAME                    1166
#define IDC_USER                        1167
#define IDC_PASSWORD                    1168
#define ID_CHECK                        1169
#define IDS_FTP_FAILED                  1601
#define IDS_GETVERSION_FAILED           1602
#define IDS_CLEAR_FAILED                1603
#define IDS_UPLOAD_FAILED               1604
#define IDS_SAVESETTINGS_FAILED         1605
#define IDS_UPDATE_PROCEED              1606
#define IDS_BACKUP_FAILED               1607
#define IDS_SETUP_FAILED                1608
#define IDS_UPDATE_FAILED               1609

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
