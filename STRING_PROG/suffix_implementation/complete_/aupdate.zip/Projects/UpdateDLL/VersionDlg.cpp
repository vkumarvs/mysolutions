// VersionDlg.cpp : implementation file
//
#include <afxwin.h>
#include "Resource.h"
#include "VersionDlg.h"

/////////////////////////////////////////////////////////////////////
// CVersionDlg dialog
CVersionDlg::CVersionDlg(CWnd* pParent)
	: CDialog(CVersionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVersionDlg)
	m_Version = "";
	//}}AFX_DATA_INIT
}

void CVersionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVersionDlg)
	DDX_Text(pDX, IDC_VERSION, m_Version);
	//}}AFX_DATA_MAP
}
