// VersionDlg.h : header file
//
#pragma once

/////////////////////////////////////////////////////////////////////
// CVersionDlg dialog
class CVersionDlg : public CDialog
{
// Construction
public:
	CVersionDlg(CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CVersionDlg)
	enum { IDD = IDD_VERSION };
	CString	m_Version;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVersionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CVersionDlg)
	//}}AFX_MSG
};
