// UpdateDll.cpp : Defines the initialization routines for the DLL.
//
#include <afxwin.h>

CWinApp theApp;
