/**********************************************/
/* getmqmsg.cpp ... Get an MQ message.        */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_GETMQMSG_CPP
#define SW_GETMQMSG_CPP

#ifndef SW_JAXMQ_HPP
   #include "jaxmq.hpp"
#endif // SW_JAXMQ_HPP

#ifndef SW_TSTJXMQ_HPP
   #include "tstjxmq.hpp"
#endif // SW_TSTJXMQ_HPP

#include <iostream>
#include <string>

using namespace std;
using namespace SoftWoehr;

/**********/
/** Main **/
/**********/

int main (int argc, char *argv[]) {

   /* A queue mgr to work with */
   MQQueueManager mq_queue_manager;

   /* A queue to work with */
   MQQueue mq_queue;

   /* A message to get */
   MQMessage mq_get_message;

     /* Return code */
   int result = 0;

   /* Say "Howdy!" */
   cout << MQBase::release_version << endl;

   /* Make sure we've been given a queue manager name, queue name and message. */
   if (argc != 3) {
      cout << "usage: " << argv[0] << " queue_manager_name queue_name" << endl;
      result = 10;
      exit (result);
      }

   /* We have required args, now we're on our way. */
   else {

      /* Names of entities to open */
      string queue_manager_name(argv[1]);
      string queue_name(argv[2]);

      /* Connect to our queue manager */
      try {
         mq_queue_manager.connect(queue_manager_name);
         }

      /* Failed to open queue manager. */
      catch (MQQueueManager::FailedToConnectException & ex) {
         cout << "MQQueueManager::FailedToConnectException caught "
              << "opening " << queue_manager_name
              <<" ... Info follows:" << endl;
         cout << ex.get_text() << endl;
         cout << "Completion code : " << ex.get_completion_code() << endl;
         cout << "Reason          : " << ex.get_reason()          << endl;
         result = 20;
         }

      /* Failed to open queue manager. */
      catch (MQException & ex) {
         cout << "MQQueueManager::MQException caught "
              << "opening " << queue_manager_name
              <<" ... Info follows:" << endl;
         cout << ex.get_text() << endl;
         result = 21;
         }

      /* Announce success */
      cout << "MQQueueManager "
           << mq_queue_manager.get_name()
           << " called MQCONN()."  << endl;
      cout << "Handle is now      : "
           << mq_queue_manager.get_connection_handle()  << endl;
      cout << "Completion code is : "
           << mq_queue_manager.get_completion_code()    << endl;
      cout << "Reason is          : "
           << mq_queue_manager.get_reason()             << endl;

      /* If we didn't catch an error, proceed. */
      if (!result) {

         /* Open a queue */
         try {
            MQObject::Options options ( MQObject::Options::open_input_shared
                                      )
                                      ;
            mq_queue.open( mq_queue_manager
                         , queue_name
                         , options
                         )
                         ;
            }

          /* Free open queue manager */
         catch (MQQueue::FailedToOpenException & ex) {
            cout << "MQQueue::FailedToOpenException caught "
                 << "opening " << queue_name
                 << " ... Info follows:" << endl;
            cout << ex.get_text() << endl;
            release_queue_manager(mq_queue_manager);/* Free open queue manager*/
            result = 26;
            }

         /* Failed to open */
         catch (MQException &ey) {
            cout << "MQException caught "
                 << "opening " << queue_name
                 << " ... Info follows:" << endl;
            cout << ey.get_text() << endl;
            release_queue_manager(mq_queue_manager);/* Free open queue manager*/
            result = 27;
            }

         /* If no error */
         if (!result) {
            cout << queue_name << " successfully opened." << endl;
            // mq_queue.print();

            try {
            mq_queue.get(mq_get_message, 1000);
               }

            catch (MQObject::NotOpenedException & nonoex)
               {
               cout << "Exception caught getting message: " << nonoex.get_text() << endl;
               release_object(mq_queue);
               release_queue_manager(mq_queue_manager);
               result = 36;
               }

            catch (MQQueue::MessageGetException & mgex)
               {
               cout << "Exception caught getting message: " << mgex.get_text() << endl;
               cout << "Condition code: " << mgex.get_completion_code() << endl;
               cout << "Reason: "         << mgex.get_reason() << endl;
               release_object(mq_queue);
               release_queue_manager(mq_queue_manager);
               result = 37;
               }

            if (!result) {
               cout << "Returned message == '"
                    << mq_get_message.get_message()
                    <<"'"
                    << endl;
               cout << "Result from release queue == "
                    << release_object(mq_queue)
                    << endl;/* Close queue, no result, it hasn't been closed.*/
               cout << "Result from release queue manager == "
                    << release_queue_manager(mq_queue_manager)
                    << endl;                        /* Ditto queue manager.*/
               }
            }
         }
      }
   cout << flush;
   cerr << flush;
   #ifdef __TOS_WIN__
   system("pause");                   /* This command only exists on WinDos*/
   #endif                              /* __TOS_WIN__                      */
   return result;
   }                                   /* int main (int argc, char *argv[])*/

#endif                                 /* SW_GETMQMSG_CPP           */
