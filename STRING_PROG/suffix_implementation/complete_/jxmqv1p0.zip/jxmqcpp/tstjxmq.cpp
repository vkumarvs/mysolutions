/**********************************************/
/* tstjxmq.cpp ... Subrs for message examples.*/
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_TSTJXMQ_CPP
#define SW_TSTJXMQ_CPP

#ifndef SW_JAXMQ_HPP
   #include "jaxmq.hpp"
#endif // SW_JAXMQ_HPP

#include <string>
#include <iostream>

using namespace std;
using namespace SoftWoehr;

/* Disconnect from queue manager */
int release_queue_manager(MQQueueManager & queue_manager) {

   int result = 0;

   try {
      queue_manager.disconnect();
      }

   /* Problem releasing queue manager */
   catch (MQException & ex) {
      cout << "MQException caught on queue manager close. Info follows:" << endl;
      cout << ex.get_text() << endl;
      result = 40;
      }

   /* Success */
   cout << "MQQueueManager "
        << queue_manager.get_name()
        << " called MQDISC()."   << endl;
   cout << "Handle is now      : "
        << queue_manager.get_connection_handle()  << endl;
   cout << "Completion code is : "
        << queue_manager.get_completion_code()    << endl;
   cout << "Reason is          : "
        << queue_manager.get_reason()             << endl;

   /* Done */
   return result;
   }           /* int release_queue_manager(MQQueueManager & queue_manager)*/

/** Let go of an MQObject. */
int release_object(MQObject & object)
   {
   using namespace std;

   int result = 0;

   /* Close the queue. */
   try {
      MQObject::Options options(MQObject::Options::close_none);
      object.close(options);
      }

   /* Problem closing queue */
   catch (MQException &ez) {
      cout << "MQException caught on queue close. Info follows:" << endl;
      cout << ez.get_text() << endl;
      result = 35;
      }
   return result;
   }                                /* int release_object(MQQueue & object)*/

#endif                                 /* SW_TSTJXMQ_CPP            */
