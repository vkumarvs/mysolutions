/**********************************************/
/* mqqmgr.cpp ... Queue manager implementation*/
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQQMGR_CPP
#define SW_MQQMGR_CPP

#ifndef SW_MQQMGR_HPP
   #include "mqqmgr.hpp"
#endif // SW_MQQMGR_HPP

using namespace std;
using namespace SoftWoehr;

/*
 * class MQQueueManager
 */

      /** Ctor */
MQQueueManager::MQQueueManager()
   : my_connection_handle (MQHC_UNUSABLE_HCONN)        /* Connection handle*/
   , connected(false)
   {}

      /** Dtor */
MQQueueManager::~MQQueueManager(){if (is_connected()) disconnect();}

/** Connect to a queue manager */
MQQueueManager & MQQueueManager::connect (const string & mq_manager_name)
   {



   /* Don't discard previous connection blindly. */
   if (is_connected())
      {
      throw AlreadyConnectedException();
      }

   /* Instance our name */
   my_name = mq_manager_name;

   /* Copy the manager name, MQCONN() proto'ed char, not const char */
   unsigned int len           = my_name.length() + 1;       /* for the NULL*/
   char * holds_manager_name  = new char[len];           /* Use temporarily*/
   strcpy(holds_manager_name, my_name.c_str());    /* Copy name for MQ call*/

   /* Attempt the connection */
   MQCONN ( holds_manager_name                     /* Name of queue manager*/
          , &my_connection_handle                      /* Connection handle*/
          , &my_completion_code                          /* Completion code*/
          , &my_reason                   /* Reason code qualifying CompCode*/
          )
          ;

   /* Return memory */
   delete holds_manager_name;

   /* Record and report result */
   connected = (MQCC_OK == my_completion_code);

   /*
    * cout << "MQQueueManger " << my_name << " called MQCONN()."  << endl;
    * cout << "Handle is now      : " << my_connection_handle  << endl;
    * cout << "Completion code is : " << my_completion_code    << endl;
    * cout << "Reason is          : " << my_reason             << endl;
    */

   /* Throw on error */
   if (!is_connected()) {
      // cout << "Failed to connect." << endl;
      throw MQQueueManager::FailedToConnectException(my_completion_code, my_reason);
      }

   /* Done */
   return *this;
   }   /* MQQueueManager & MQQueueManager::connect (string mq_manager_name)*/

/** Disconnect from a queue manager */
MQQueueManager & MQQueueManager::disconnect(void) {

   /* If not connected, report and throw. */
   if (!is_connected())
      {
      throw MQQueueManager::NotConnectedException();
      }

   /* Go ahead with the disconnect. */
   MQDISC ( &my_connection_handle                      /* Connection handle*/
          , &my_completion_code                          /* Completion code*/
          , &my_reason                   /* Reason code qualifying CompCode*/
          )
          ;
   /*
    * cout << "MQQueueManager " << my_name << " called MQDISC()."  << endl;
    * cout << "Handle is now      : " << my_connection_handle  << endl;
    * cout << "Completion code is : " << my_completion_code    << endl;
    * cout << "Reason is          : " << my_reason             << endl;
    */
   connected = false;
   return *this;
   }                   /* MQQueueManager & MQQueueManager::disconnect(void)*/

/** Commit most recent unit of work on a queue manager */
MQQueueManager & MQQueueManager::commit(void)
   {

   /* If not connected, report and throw. */
   if (!is_connected())
      {
      throw MQQueueManager::NotConnectedException();
      }

   MQCMIT ( my_connection_handle
          , &my_completion_code
          , &my_reason
          );

   /* Throw on error */
   if (MQCC_OK != my_completion_code) {
      throw MQQueueManager::CommitException(my_completion_code,my_reason);
      }

   return *this;
   }                       /* MQQueueManager & MQQueueManager::commit(void)*/

/** Backout most recent unit of work on a queue manager */
MQQueueManager & MQQueueManager::back_out(void)
   {
  /* If not connected, report and throw. */
   if (!is_connected())
      {
      throw MQQueueManager::NotConnectedException();
      }

   MQBACK ( my_connection_handle
          , &my_completion_code
          , &my_reason
          );

   /* Throw on error */
   if (MQCC_OK != my_completion_code) {
      throw MQQueueManager::BackOutException(my_completion_code,my_reason);
      }

   return *this;
   }                     /* MQQueueManager & MQQueueManager::back_out(void)*/

/** Test connection */
bool MQQueueManager::is_connected(void) const { return connected; }

/** Name */
const string & MQQueueManager::get_name (void) const { return my_name; }

/** Connection handle */
MQHCONN  MQQueueManager::get_connection_handle (void) {return my_connection_handle; }

/** Completion code */
MQLONG MQQueueManager::get_completion_code (void) const{ return my_completion_code; }

/** Reason*/
MQLONG MQQueueManager::get_reason (void) const{ return my_reason; }

/** Represents object already open */
//      class MQQueueManager::AlreadyConnectedException : public MQException
//        public :
MQQueueManager::AlreadyConnectedException::AlreadyConnectedException()
   : MQException("Already connected to a queue manager.")
   {}
//        }; /* class AlreadyConnectedException : public MQException */

/** Represents qmgr failed to connect */
//      class FailedToConnectException : public MQException
//        public :
MQQueueManager::FailedToConnectException::FailedToConnectException
   ( MQLONG completion_code
   , MQLONG reason
   )
   : MQException("Failed to connect to a queue manager.", completion_code, reason)
   {}
//        }; /* class MQQueueManager::FailedToConnectException : public MQException */

/** Represents qmgr not connected */
//      class MQQueueManager::NotConnectedException : public MQException
//        public :
MQQueueManager::NotConnectedException::NotConnectedException()
   : MQException("Not connected to a queue manager.")
   {}
//        }; /* class MQQueueManager::NotConnectedException : public MQException */

//      /** Represents exception on a qmgr commit */
//      class MQQueueManager::CommitException : public MQException
//        public :
MQQueueManager::CommitException::CommitException
   ( MQLONG completion_code
   , MQLONG reason
   )
   : MQException( "Could not commit unit of work on queue manager."
                , completion_code
                , reason
                )
   {}
//        }; /* class MQQueueManager::CommitException: public MQException*/

/** Represents exception on a qmgr backout */
//      class BackOutException : public MQException
//        public :
MQQueueManager::BackOutException::BackOutException
   ( MQLONG completion_code
   , MQLONG reason
   )
   : MQException( "Could not back out unit of work on queue manager."
                , completion_code
                , reason
                )
   {}
//    };              /* class BackOutException: public MQException*/
//   }; /* class MQQueueManger */
#endif                                 /* SW_MQQMGR_CPP             */
