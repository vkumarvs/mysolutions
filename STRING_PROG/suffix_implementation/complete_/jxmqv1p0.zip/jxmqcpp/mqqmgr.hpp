/**********************************************/
/* mqqmgr.hpp ... Queue manager declarations. */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQQMGR_HPP
#define SW_MQQMGR_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

#ifndef SW_MQEXCEPT_HPP
   #include "mqexcept.hpp"
#endif // SW_MQEXCEPT_HPP

#include <string>

namespace SoftWoehr {

/** Represents an MQ queue manager */
class MQQueueManager : public MQBase {

   public   :

      /** Ctor */
      MQQueueManager();

      /** Dtor */
      virtual ~MQQueueManager();

      /** Connect to queue manager */
      virtual MQQueueManager & connect(const std::string & mqmgr);

      /** Disconnect from a queue manager */
      virtual MQQueueManager & disconnect(void);

      /** Commit most recent unit of work on a queue manager */
      virtual MQQueueManager & commit(void);

      /** Backout most recent unit of work on a queue manager */
      virtual MQQueueManager & back_out(void);

      /** Test connection */
      virtual bool is_connected(void) const;

      /** Connection handle */
      virtual MQHCONN get_connection_handle (void);

      /** Name */
      virtual const std::string & get_name (void) const;

      /** Completion code */
      MQLONG get_completion_code (void) const;

      /** Reason*/
      MQLONG get_reason (void) const;

   private  :
      std::string my_name;                                    /* Queue name*/
      MQHCONN     my_connection_handle;                /* Connection handle*/
      MQLONG      my_completion_code;                    /* Completion code*/
      MQLONG      my_reason;                                      /* Reason*/
      bool connected;

      /** Not implemented */
      MQQueueManager & operator= (const MQQueueManager & src);

      /** Not implemented */
      MQQueueManager (const MQQueueManager & src);

   public   :

        /** Represents qmgr already connected */
      class AlreadyConnectedException : public MQException
        {
        public :
        AlreadyConnectedException();
        };          /* class AlreadyConnectedException : public MQException*/

       /** Represents qmgr failed to connect */
      class FailedToConnectException : public MQException
        {
        public :
        FailedToConnectException(MQLONG completion_code, MQLONG reason);
        };           /* class FailedToConnectException : public MQException*/

      /** Represents qmgr not connected */
      class NotConnectedException : public MQException
        {
        public :
        NotConnectedException();
        };              /* class NotConnectedException : public MQException*/

      /** Represents exception on a qmgr commit */
      class CommitException : public MQException
        {
        public :
        CommitException(MQLONG completion_code, MQLONG reason);
        };              /* class CommitException: public MQException*/

      /** Represents exception on a qmgr backout */
      class BackOutException : public MQException
        {
        public :
        BackOutException(MQLONG completion_code, MQLONG reason);
        };              /* class BackOutException: public MQException*/
   };                                                /* class MQQueueManger*/

} // namespace SoftWoehr

#endif                                 /* SW_MQQMGR_HPP             */
