/**********************************************/
/* mqqueue.cpp ... Queue object implementation*/
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQQUEUE_CPP
#define SW_MQQUEUE_CPP

#ifndef SW_MQQUEUE_HPP
   #include "mqqueue.hpp"
#endif // SW_MQQUEUE_HPP

#ifndef SW_MQMSG_HPP
   #include "mqmsg.hpp"
#endif // SW_MQMSG_HPP

using namespace std;
using namespace SoftWoehr;

// class MQQueue : public MQObject {
   // public   :

/** Create an MQQueue with the descriptor already set to Queue */
MQQueue::MQQueue() {my_descriptor.object_type_queue();}

/** Dtor */
MQQueue::~MQQueue(){}

/** Open a named queue on a given queue manager */
MQQueue & MQQueue::open( MQQueueManager & queue_manager
                       , const string   & queue_name
                       , const MQObject::Options & options
                       )
   {

   /* Instance extra string fields in pre-created descriptor. */
   my_descriptor.set_object_name(queue_name);
   my_descriptor.set_object_queue_manager_name(queue_manager.get_name());

   MQObject::open( queue_manager // sets my_queue_manager from passed-in
                 , my_descriptor // already filled out
                 , options       // passed in
                 )
                 ;

   return *this;
   }             /* MQQueue & MQQueue::open( MQQueueManager & queue_manager*/
     /*               , string         & queue_name */
     /*               , MQObject::Options & options */
     /*               )   */

/** Put a message to the queue */
MQQueue & MQQueue::put ( unsigned char * message
                       , unsigned long message_length
                       , MQMessage::Descriptor & message_descriptor
                       , MQMessage::PutOptions & put_message_options
                       ) throw( MQQueue::NotOpenedException
                              , MQQueue::MessagePutException
                              )
   {
   /** See if we are opened */
   if (!is_opened())
      {
      throw NotOpenedException();
      }

   /** Put the message */
   MQPUT( get_connection_handle()
        , get_object_handle()
        , message_descriptor.get_PMQMD()
        , put_message_options.get_PMQPMO()
        , message_length
        , message
        , &my_completion_code
        , &my_reason
        )
        ;

   if (MQCC_OK != my_completion_code)
      {
      throw MessagePutException( my_completion_code
                               , my_reason
                               )
                               ;
      }

   return *this;
   }                                              /* MQQueue & MQQueue::put*/

 /** Put a message to the queue */
MQQueue & MQQueue::put (MQMessage & mq_message)
   throw( MQQueue::NotOpenedException
        , MQQueue::MessagePutException
        )
   {
   put( mq_message.get_message()
      , mq_message.get_length()
      , mq_message.get_descriptor()
      , mq_message.get_put_options()
      )
      ;
   return *this;
   }                      /* MQQueue & MQQueue::put ( MQMessage mq_message)*/

/** Static member function (Class method).
  * Put one message to a queue
  * without priorly opening a queue.
  * If returns aren't zero (0) throw exception.
  */
void MQQueue::put ( MQQueueManager      &queue_manager
                  , MQQueue::Descriptor &object_descriptor
                  , MQMessage           &message
                  ) throw( MQQueue::MessageStaticPutException)
   {
   MQLONG completion_code;
   MQLONG reason;

   MQPUT1 ( queue_manager.get_connection_handle()      /* Connection handle*/
          , object_descriptor.get_PMQOD()              /* Object descriptor*/
          , message.get_descriptor().get_PMQMD()      /* Message descriptor*/
          , message.get_put_options().get_PMQPMO()/* Options that control the action of MQPUT1*/
          , message.get_length()         /* Length of the message in Buffer*/
          , message.get_message()                           /* Message data*/
          , &completion_code                             /* Completion code*/
          , &reason                      /* Reason code qualifying CompCode*/
          )
          ;

   if (MQCC_OK != completion_code)
      { throw MQQueue::MessageStaticPutException(completion_code, reason); }
   }              /* void MQQueue::put ( MQQueueManager      &queue_manager*/
                 /*  , MQQueue::Descriptor &object_descriptor */
                 /*  , MQMessage           &message */
                 /*  ) throw( MQQueue::MessageStaticPutException) */

/** Get a message from the queue */
MQQueue & MQQueue::get ( unsigned char * message
                       , unsigned long message_length
                       , long * data_length
                       , MQMessage::Descriptor & message_descriptor
                       , MQMessage::GetOptions & get_message_options
                       ) throw( MQQueue::NotOpenedException
                              , MQQueue::MessageGetException
                              )
   {
   /** See if we are opened */
   if (!is_opened())
      {
      throw NotOpenedException();
      }

   /** Get the message */
   MQGET( get_connection_handle()
        , get_object_handle()
        , message_descriptor.get_PMQMD()
        , get_message_options.get_PMQGMO()
        , message_length
        , message
        , data_length
        , &my_completion_code
        , &my_reason
        )
        ;

   if (MQCC_OK != my_completion_code)
      {
      throw MessageGetException( my_completion_code
                               , my_reason
                               )
                               ;
      }

   return *this;
   }                                              /* MQQueue & MQQueue::get*/

/** Get a message from the queue */
MQQueue & MQQueue::get ( MQMessage & mq_message, unsigned long length)
   throw( MQQueue::NotOpenedException
        , MQQueue::MessageGetException
        )
   {
   unsigned char * temp = new unsigned char [length];
   long data_length;
   get( temp
      , length
      , &data_length
      , mq_message.get_descriptor()
      , mq_message.get_get_options()
      )
      ;

   mq_message.set_message(temp, data_length);              /* Store message*/
   delete temp;
   return *this;
   }/* MQQueue & MQQueue::get ( MQMessage & mq_message, unsigned long length)*/

/** Class representing error on message put */
//    class MQQueue::MessagePutException : public MQException
//         public   :
MQQueue::MessagePutException::MessagePutException( MQLONG completion_code
                                                 , MQLONG reason
                                                 )
   :  MQException("Message could not be put to queue.", completion_code, reason)
   {}/* MQQueue::MessagePutException::MessagePutException( MQLONG completion_code*/
      /*                                                  , MQLONG reason */
      /*                                                  )              */

/** Class representing error on message static put */
//    class MQQueue::MessageStaticPutException : public MQueue::MessagePutException
//         public   :
MQQueue::MessageStaticPutException::MessageStaticPutException( MQLONG completion_code
                                                             , MQLONG reason
                                                             )
   :  MessagePutException(completion_code, reason)
   {}/* MQQueue::MessageStaticPutException::MessageStaticPutException( MQLONG completion_code*/
      /*                                                  , MQLONG reason */
      /*                                                  )              */

/** Class representing error on message get */
//    class MQQueue::MessageGetException : public MQException
//         public   :
MQQueue::MessageGetException::MessageGetException( MQLONG completion_code
                                                 , MQLONG reason
                                                 )
   :  MQException("Message could not be gotten from queue.", completion_code, reason)
   {}/* MQQueue::MessageGetException::MessageGetException( MQLONG completion_code*/
      /*                                                  , MQLONG reason */
      /*                                                  )              */

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* The code within these blocks was autogenerated    */
/* using the following files found in $JXMQ/pl.      */
/* atrqqihp.pl atrqqicp.pl atrqqchp.pl atrqqccp.pl   */
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/** Character attribute factory for MQCA_BACKOUT_REQ_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_backout_req_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_BACKOUT_REQ_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_BACKOUT_REQ_Q_NAME // Excessive backout requeue name"
         )
         ;
         }
/** Character attribute factory for MQCA_BASE_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_base_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_BASE_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_BASE_Q_NAME // Name of queue that alias resolves to"
         )
         ;
         }
/** Character attribute factory for MQCA_CREATION_DATE */
MQInquiry::character_attribute *
   MQQueue::mqca_creation_date(void) {
      return new MQInquiry::character_attribute
         ( MQCA_CREATION_DATE
         , MQ_CREATION_DATE_LENGTH
         ,"MQCA_CREATION_DATE // Queue creation date"
         )
         ;
         }
/** Character attribute factory for MQCA_CREATION_TIME */
MQInquiry::character_attribute *
   MQQueue::mqca_creation_time(void) {
      return new MQInquiry::character_attribute
         ( MQCA_CREATION_TIME
         , MQ_CREATION_TIME_LENGTH
         ,"MQCA_CREATION_TIME // Queue creation time"
         )
         ;
         }
/** Character attribute factory for MQCA_INITIATION_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_initiation_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_INITIATION_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_INITIATION_Q_NAME // Initiation queue name"
         )
         ;
         }
/** Character attribute factory for MQCA_PROCESS_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_process_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_PROCESS_NAME
         , MQ_PROCESS_NAME_LENGTH
         ,"MQCA_PROCESS_NAME // Name of process definition"
         )
         ;
         }
/** Character attribute factory for MQCA_Q_DESC */
MQInquiry::character_attribute *
   MQQueue::mqca_q_desc(void) {
      return new MQInquiry::character_attribute
         ( MQCA_Q_DESC
         , MQ_Q_DESC_LENGTH
         ,"MQCA_Q_DESC // Queue description"
         )
         ;
         }
/** Character attribute factory for MQCA_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_Q_NAME // Queue name"
         )
         ;
         }
/** Character attribute factory for MQCA_REMOTE_Q_MGR_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_remote_q_mgr_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_REMOTE_Q_MGR_NAME
         , MQ_Q_MGR_NAME_LENGTH
         ,"MQCA_REMOTE_Q_MGR_NAME // Name of remote queue manager"
         )
         ;
         }
/** Character attribute factory for MQCA_REMOTE_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_remote_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_REMOTE_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_REMOTE_Q_NAME // Name of remote queue as known on remote queue manager"
         )
         ;
         }
/** Character attribute factory for MQCA_TRIGGER_DATA */
MQInquiry::character_attribute *
   MQQueue::mqca_trigger_data(void) {
      return new MQInquiry::character_attribute
         ( MQCA_TRIGGER_DATA
         , MQ_TRIGGER_DATA_LENGTH
         ,"MQCA_TRIGGER_DATA // Trigger data"
         )
         ;
         }
/** Character attribute factory for MQCA_XMIT_Q_NAME */
MQInquiry::character_attribute *
   MQQueue::mqca_xmit_q_name(void) {
      return new MQInquiry::character_attribute
         ( MQCA_XMIT_Q_NAME
         , MQ_Q_NAME_LENGTH
         ,"MQCA_XMIT_Q_NAME // Transmission queue name"
         )
         ;
         }
/** Integer attribute factory for MQIA_BACKOUT_THRESHOLD */
MQInquiry::integer_attribute *
   MQQueue::mqia_backout_threshold(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_BACKOUT_THRESHOLD
         ,"MQIA_BACKOUT_THRESHOLD // Backout threshold."
         )
         ;
         }
/** Integer attribute factory for MQIA_CURRENT_Q_DEPTH */
MQInquiry::integer_attribute *
   MQQueue::mqia_current_q_depth(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_CURRENT_Q_DEPTH
         ,"MQIA_CURRENT_Q_DEPTH // Number of messages on queue."
         )
         ;
         }
/** Integer attribute factory for MQIA_DEF_INPUT_OPEN_OPTION */
MQInquiry::integer_attribute *
   MQQueue::mqia_def_input_open_option(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_DEF_INPUT_OPEN_OPTION
         ,"MQIA_DEF_INPUT_OPEN_OPTION // Default open-for-input option."
         )
         ;
         }
/** Integer attribute factory for MQIA_DEF_PERSISTENCE */
MQInquiry::integer_attribute *
   MQQueue::mqia_def_persistence(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_DEF_PERSISTENCE
         ,"MQIA_DEF_PERSISTENCE // Default message persistence."
         )
         ;
         }
/** Integer attribute factory for MQIA_DEF_PRIORITY */
MQInquiry::integer_attribute *
   MQQueue::mqia_def_priority(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_DEF_PRIORITY
         ,"MQIA_DEF_PRIORITY // Default message priority."
         )
         ;
         }
/** Integer attribute factory for MQIA_DEFINITION_TYPE */
MQInquiry::integer_attribute *
   MQQueue::mqia_definition_type(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_DEFINITION_TYPE
         ,"MQIA_DEFINITION_TYPE // Queue definition type."
         )
         ;
         }
/** Integer attribute factory for MQIA_HARDEN_GET_BACKOUT */
MQInquiry::integer_attribute *
   MQQueue::mqia_harden_get_backout(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_HARDEN_GET_BACKOUT
         ,"MQIA_HARDEN_GET_BACKOUT // Whether to harden backout count."
         )
         ;
         }
/** Integer attribute factory for MQIA_INHIBIT_GET */
MQInquiry::integer_attribute *
   MQQueue::mqia_inhibit_get(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_INHIBIT_GET
         ,"MQIA_INHIBIT_GET // Whether get operations are allowed."
         )
         ;
         }
/** Integer attribute factory for MQIA_INHIBIT_PUT */
MQInquiry::integer_attribute *
   MQQueue::mqia_inhibit_put(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_INHIBIT_PUT
         ,"MQIA_INHIBIT_PUT // Whether put operations are allowed."
         )
         ;
         }
/** Integer attribute factory for MQIA_MAX_MSG_LENGTH */
MQInquiry::integer_attribute *
   MQQueue::mqia_max_msg_length(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_MAX_MSG_LENGTH
         ,"MQIA_MAX_MSG_LENGTH // Maximum message length."
         )
         ;
         }
/** Integer attribute factory for MQIA_MAX_Q_DEPTH */
MQInquiry::integer_attribute *
   MQQueue::mqia_max_q_depth(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_MAX_Q_DEPTH
         ,"MQIA_MAX_Q_DEPTH // Maximum number of messages allowed on queue."
         )
         ;
         }
/** Integer attribute factory for MQIA_MSG_DELIVERY_SEQUENCE */
MQInquiry::integer_attribute *
   MQQueue::mqia_msg_delivery_sequence(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_MSG_DELIVERY_SEQUENCE
         ,"MQIA_MSG_DELIVERY_SEQUENCE // Whether message priority is relevant."
         )
         ;
         }
/** Integer attribute factory for MQIA_OPEN_INPUT_COUNT */
MQInquiry::integer_attribute *
   MQQueue::mqia_open_input_count(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_OPEN_INPUT_COUNT
         ,"MQIA_OPEN_INPUT_COUNT // Number of MQOPEN calls that have the queue open for input."
         )
         ;
         }
/** Integer attribute factory for MQIA_OPEN_OUTPUT_COUNT */
MQInquiry::integer_attribute *
   MQQueue::mqia_open_output_count(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_OPEN_OUTPUT_COUNT
         ,"MQIA_OPEN_OUTPUT_COUNT // Number of MQOPEN calls that have the queue open for output."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_DEPTH_HIGH_EVENT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_depth_high_event(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_DEPTH_HIGH_EVENT
         ,"MQIA_Q_DEPTH_HIGH_EVENT // Control attribute for queue depth high events."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_DEPTH_HIGH_LIMIT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_depth_high_limit(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_DEPTH_HIGH_LIMIT
         ,"MQIA_Q_DEPTH_HIGH_LIMIT // High limit for queue depth."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_DEPTH_LOW_EVENT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_depth_low_event(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_DEPTH_LOW_EVENT
         ,"MQIA_Q_DEPTH_LOW_EVENT // Control attribute for queue depth low events."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_DEPTH_LOW_LIMIT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_depth_low_limit(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_DEPTH_LOW_LIMIT
         ,"MQIA_Q_DEPTH_LOW_LIMIT // Low limit for queue depth."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_DEPTH_MAX_EVENT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_depth_max_event(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_DEPTH_MAX_EVENT
         ,"MQIA_Q_DEPTH_MAX_EVENT // Control attribute for queue depth max events."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_SERVICE_INTERVAL */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_service_interval(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_SERVICE_INTERVAL
         ,"MQIA_Q_SERVICE_INTERVAL // Limit for queue service interval."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_SERVICE_INTERVAL_EVENT */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_service_interval_event(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_SERVICE_INTERVAL_EVENT
         ,"MQIA_Q_SERVICE_INTERVAL_EVENT // Control for queue service interval events."
         )
         ;
         }
/** Integer attribute factory for MQIA_Q_TYPE */
MQInquiry::integer_attribute *
   MQQueue::mqia_q_type(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_Q_TYPE
         ,"MQIA_Q_TYPE // Queue type."
         )
         ;
         }
/** Integer attribute factory for MQIA_RETENTION_INTERVAL */
MQInquiry::integer_attribute *
   MQQueue::mqia_retention_interval(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_RETENTION_INTERVAL
         ,"MQIA_RETENTION_INTERVAL // Queue retention interval."
         )
         ;
         }
/** Integer attribute factory for MQIA_SCOPE */
MQInquiry::integer_attribute *
   MQQueue::mqia_scope(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_SCOPE
         ,"MQIA_SCOPE // Queue definition scope."
         )
         ;
         }
/** Integer attribute factory for MQIA_SHAREABILITY */
MQInquiry::integer_attribute *
   MQQueue::mqia_shareability(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_SHAREABILITY
         ,"MQIA_SHAREABILITY // Whether queue can be shared."
         )
         ;
         }
/** Integer attribute factory for MQIA_TRIGGER_CONTROL */
MQInquiry::integer_attribute *
   MQQueue::mqia_trigger_control(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_TRIGGER_CONTROL
         ,"MQIA_TRIGGER_CONTROL // Trigger control."
         )
         ;
         }
/** Integer attribute factory for MQIA_TRIGGER_DEPTH */
MQInquiry::integer_attribute *
   MQQueue::mqia_trigger_depth(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_TRIGGER_DEPTH
         ,"MQIA_TRIGGER_DEPTH // Trigger depth."
         )
         ;
         }
/** Integer attribute factory for MQIA_TRIGGER_MSG_PRIORITY */
MQInquiry::integer_attribute *
   MQQueue::mqia_trigger_msg_priority(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_TRIGGER_MSG_PRIORITY
         ,"MQIA_TRIGGER_MSG_PRIORITY // Threshold message priority for triggers."
         )
         ;
         }
/** Integer attribute factory for MQIA_TRIGGER_TYPE */
MQInquiry::integer_attribute *
   MQQueue::mqia_trigger_type(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_TRIGGER_TYPE
         ,"MQIA_TRIGGER_TYPE // Trigger type."
         )
         ;
         }
/** Integer attribute factory for MQIA_USAGE */
MQInquiry::integer_attribute *
   MQQueue::mqia_usage(void) {
      return new MQInquiry::integer_attribute
         ( MQIA_USAGE
         ,"MQIA_USAGE // Usage."
         )
         ;
         }

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* End of autogenerated code.                        */
/* using the following files found in $JXMQ/pl.      */
/* atrqqihp.pl atrqqicp.pl atrqqchp.pl atrqqccp.pl   */
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/** Return an inquiry of all which applies to any queue. */
MQInquiry * MQQueue::inquiry_any_queue(void)
   {
   MQInquiry *pmqi = new MQInquiry;
   pmqi->add (mqca_q_desc());
   pmqi->add (mqca_q_name());
   pmqi->add (mqia_def_persistence());
   pmqi->add (mqia_def_priority());
   pmqi->add (mqia_inhibit_put());
   pmqi->add (mqia_q_type());
   return pmqi;
   }

#endif                                 /* SW_MQQUEUE_CPP            */
