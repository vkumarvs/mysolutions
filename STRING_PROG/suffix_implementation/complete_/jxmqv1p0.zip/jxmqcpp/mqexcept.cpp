/**********************************************/
/* mqexcept.cpp ... Exception implementation. */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQEXCEPT_CPP
#define SW_MQEXCEPT_CPP

#ifndef SW_MQEXCEPT_HPP
   #include "mqexcept.hpp"
#endif // SW_MQEXCEPT_HPP

using namespace std;
using namespace SoftWoehr;

// class MQException
//   public :

/** 0-arity ctor */
MQException::MQException()
   : my_text("Unknown MQException exception text.")
   , my_completion_code(MQCC_OK)
   , my_reason(0)
   {}                                         /* MQException::MQException()*/

/** 1-arity ctor */
MQException::MQException(const string & s)
   : my_text(s)
   , my_completion_code(MQCC_OK)
   , my_reason(0)
   {}                         /* MQException::MQException(const string & s)*/

/** 3-arity ctor */
MQException::MQException( const string & s
                        , MQLONG completion_code
                        , MQLONG reason
                        )
   : my_text(s)
   , my_completion_code(completion_code)
   , my_reason(reason)
   {}                         /* MQException::MQException( const string & s*/
                              /*                         , MQLONG completion_code */
                              /*                         , MQLONG reason */
                              /*                         ) */

/** Dtor */
MQException::~MQException() {}

/** Get exception text */
const string & MQException::get_text      (void)   const { return my_text; }

/** Get completion code */
MQLONG MQException::get_completion_code   (void)   const { return my_completion_code; }

/** Get reason */
MQLONG MQException::get_reason            (void)   const { return my_reason; }

#endif                                 /* SW_MQEXCEPT_CPP           */
