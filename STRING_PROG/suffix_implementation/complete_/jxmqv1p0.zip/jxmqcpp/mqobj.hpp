/**********************************************/
/* mqobj.hpp ... Object class declarations.   */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQOBJ_HPP
#define SW_MQOBJ_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

#ifndef SW_MQEXCEPT_HPP
   #include "mqexcept.hpp"
#endif // SW_MQEXCEPT_HPP

#ifndef SW_MQQMGR_HPP
   #include "mqqmgr.hpp"
#endif // SW_MQQMGR_HPP

#ifndef SW_MQINQ_HPP
   #include "mqinq.hpp"
#endif // SW_MQINQ_HPP

#include <string>

namespace SoftWoehr {

/** Represents an MQOPEN-able MQ Object */
class MQObject : public MQBase {

   public :

      /** Represents an MQ Object Descriptor */
      class Descriptor :  public MQBase {
         public :

            /** Represents name too long. */
            class NameTooLongException : public MQException
               {
               public :
                  NameTooLongException();
               };

            /** Ctor */
            Descriptor();

            /** Get object type as MQ constant */
            virtual MQLONG get_object_type(void) const;

            /** Set object type */
            Descriptor & object_type_queue(void);

            /** Set object type */
            Descriptor & object_type_process_definition(void);

            /** Set object type */
            Descriptor & object_type_queue_manager(void);

            /** Get object name */
            virtual const std::string & get_object_name(void) const;

            /** Set object name */
            virtual Descriptor & set_object_name(const std::string & object_name);

            /** Get object queue manager name */
            virtual const std::string & get_object_queue_manager_name(void) const;

            /** Set object queue manager name .. COPIES DATA */
            virtual Descriptor & set_object_queue_manager_name
               ( const std::string & object_queue_manager_name);

            /** Get pointer to MQOD struct */
            PMQOD get_PMQOD(void);

         private :
            /** MQ low-level obj descriptor. */
            MQOD my_MQOD;

            /** STL string of the name in my_MQOD.ObjectName */
            std::string my_name;

            /** STL string of the name in my_MQOD.ObjectQMgrName */
            std::string my_queue_manager_name;

         };                            /* class Descriptor :  public MQBase*/

      /** Represents an MQ create Options */
      class Options  :  public MQBase {
         public :
            Options (MQLONG opt = 0);
            virtual ~Options();

            MQLONG get_MQLONG (void);

            public   :

            /** Open options */
            static const MQLONG open_browse ;
            static const MQLONG open_input_shared;/* (only one of these two)*/
            static const MQLONG open_input_exclusive;/* (only one of these two)*/
            static const MQLONG open_inquire;
            static const MQLONG open_output ;
            static const MQLONG open_set    ;

            /** Close options */
            static const MQLONG close_none   ;
            static const MQLONG close_delete ;
            static const MQLONG close_purge  ;

         private :
            MQLONG  my_options;
         };                              /* class Options  :  public MQBase*/

   public :

      /** ctor */
      MQObject();

      /** dtor */
      virtual ~MQObject();

      /** Open referenced object */
      virtual MQObject & open ( MQQueueManager & queue_manager
                              , const Descriptor     & descriptor
                              , const Options  & options
                              )
                              ;
      /** Test open */
      virtual bool is_opened(void) const;

      /** Close object */
      virtual MQObject & close(MQObject::Options close_options);

      /** Perform an inquiry on the object */
      virtual const MQObject & inquire (MQInquiry & mq_inquiry) const;

      /** Perform an attribute set on the object */
      virtual const MQObject & set (MQSet & mq_set) const;

      /** Return ref to associated queue manager or throw if not open. */
      MQQueueManager & get_queue_manager(void) const;

      /** Return connection handle for associated queue manager or throw if not open. */
      MQHCONN get_connection_handle (void) const;

      /** Return object handle for associated object or throw if not open. */
      MQHOBJ get_object_handle (void) const;

      /** Return read-only descriptor of this object */
      const Descriptor & get_descriptor (void) const {return my_descriptor;}

      /** Return read-only name of this object. */
      const std::string & get_name (void) const {return get_descriptor().get_object_name();}

      /** Represents object already open */
      class AlreadyOpenException : public MQException
        {
        public :
        AlreadyOpenException();
        };               /* class AlreadyOpenException : public MQException*/

       /** Represents an error reported on object close */
       class ErrorOnCloseException : public MQException
        {
        public :
        ErrorOnCloseException(MQLONG completion_code, MQLONG reason);
        };              /* class ErrorOnCloseException : public MQException*/

       /** Represents object failed to open */
      class FailedToOpenException : public MQException
        {
        public :
        FailedToOpenException(MQLONG completion_code, MQLONG reason);
        };              /* class FailedToOpenException : public MQException*/

      /** Represents no queue manager associated with object */
      class NoAssociatedQueueManagerException : public MQException
        {
        public :
        NoAssociatedQueueManagerException();
        };/* class MQObject::NoAssociatedQueueManagerException : public MQException*/


      /** Represents queue not opened */
      class NotOpenedException : public MQException
        {
        public :
        NotOpenedException();
        };                 /* class NotOpenedException : public MQException*/

   protected   :
      Descriptor my_descriptor;     /* A descriptor of object to be opened.*/
      MQLONG  my_completion_code;                        /* Completion code*/
      MQLONG  my_reason;                 /* Reason code qualifying CompCode*/

      /* Not implemented */
      MQObject(const MQObject &);
      /* Not implemented */
      MQObject & operator=(const MQObject &);

   private     :
      MQQueueManager * my_queue_manager;       /* When open, instance this.*/
      MQHOBJ  my_object_handle;                  /* Handle returned by open*/
      bool    opened;                             /* TRUE if object is open*/
      Options my_options;              /* Record what our open options are.*/
   };                                     /* class MQObject : public MQBase*/

} // namespace SoftWoehr

#endif                                 /* SW_MQOBJ_HPP              */
