/**********************************************/
/* mqinq.cpp ... Inquiry and set implement.   */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQINQ_CPP
#define SW_MQINQ_CPP

#ifndef SW_MQINQ_HPP
   #include "mqinq.hpp"
#endif // SW_MQINQ_HPP

#include <string>
#include <vector>

using namespace std;
using namespace SoftWoehr;

/** Object to hold data for MQINQ calls. */
//class MQInquiry : public MQBase
//  public:

  //  class attribute : public MQBase
//      public:

                          /** Constructor*/
        MQInquiry::attribute::attribute  ( MQLONG selector_value
                                         , const string & name
                                         )
          : my_selector(selector_value)
          , my_name(name)
          {}

        /* Copy constructor */
        MQInquiry::attribute::attribute  (const  MQInquiry::attribute& srcObject)
        {
        my_selector = srcObject.get_selector();
        }

        MQInquiry::attribute::~attribute () {} // Destructor

        /** Read accessor */
        MQLONG MQInquiry::attribute::get_selector (void) const { return my_selector; }

      /** Return name of attribute */
      const string & MQInquiry::attribute::get_name (void) const {
         return my_name;
         }

      /** Attribute dump to stream. */
      const MQInquiry::attribute & MQInquiry::attribute::print(ostream & o) const {
         o  << "Attribute print out from MQInquiry::attribute::."
            << hex
            << (unsigned int) this
            << endl;
         o  << "------------------------------------------------"
            << endl;
         o  << "Selector == " << get_selector() << " " << get_name()
            << endl;
         return *this;
         }/* MQInquiry::attribute & MQInquiry::attribute::print(ostream & o)*/

//      protected:

        /** Write Accessor */
        MQInquiry::attribute & MQInquiry::attribute::set_selector
         (MQLONG selector)
            {my_selector=selector; return *this;}

   // End of attribute class definition


//    typedef class character_attribute : public attribute
//      public:


       /** Constructor */
        MQInquiry::character_attribute::
            character_attribute  ( MQLONG selector_value
                                 , MQLONG length
                                 , const string & name
                                 )
          : attribute(selector_value, name)
          , my_length(length)
          , my_value(new char[length])
          {}

        /** Copy ctor */
        MQInquiry::character_attribute::character_attribute
         (const character_attribute& srcObject)         /* Copy constructor*/
          : attribute(srcObject.get_selector())
          , my_length(srcObject.get_length())
          , my_value(new char[get_length()])
          {
          memcpy(my_value, srcObject.get_value(), my_length * sizeof(MQCHAR));
          }

        /** Assgn opr */
        MQInquiry::character_attribute & MQInquiry::character_attribute::operator=
            (const character_attribute& srcObject)
           {
           set_selector(srcObject.get_selector());
           my_length = srcObject.get_length();
           delete my_value;
           my_value=new char[get_length()];
           memcpy(my_value, srcObject.get_value(), my_length * sizeof(MQCHAR));
           return *this;
           }

       /** Dtor */
        MQInquiry::character_attribute::~character_attribute ()
         {delete my_value;} // Destructor

        /** Accessor */
        MQLONG MQInquiry::character_attribute::get_length(void) const
         { return my_length; }

        /** Accessor */
        const PMQCHAR MQInquiry::character_attribute:: get_value(void) const
         { return my_value;  }

        /** Copy data in to ctor-time-allocated buffer */
        MQInquiry::character_attribute & MQInquiry::character_attribute::set_value
         (const attribute_type *src)
          {
          memcpy(my_value, src, my_length * sizeof(MQCHAR));
          return *this;
          }

const MQInquiry::attribute & MQInquiry::character_attribute::print(ostream & o) const {
         o  << "Character attribute print out from MQInquiry::character_attribute::."
            << hex
            << (unsigned int) this
            << endl;
         o  << "------------------------------------------------"
            << endl;
         o  << "Selector == " << get_selector() << " " << get_name()
            << endl;

         unsigned int length = get_length() + 1;
         PMQCHAR pmqchar = new MQCHAR[length];
         pmqchar[length - 1] = '\0';
         strncpy(pmqchar, get_value(), length-1);
         o  << "Data[" << get_length() << "] == " << pmqchar
            << endl;
         o  << "_________________________________________________"
            << endl;
         return *this;
         }/* MQInquiry::character_attribute & MQInquiry::character_attribute::print(ostream & o)*/

// End of character_attribute class definition

//    typedef class integer_attribute : public attribute
//      public:

       /** Constructor */
         MQInquiry::integer_attribute::integer_attribute
            (selector_type selector_value
            , const string & name
            )
            : attribute(selector_value, name)
            , my_value(0)
            {}

        /** Copy ctor */
        MQInquiry::integer_attribute::integer_attribute
         (const integer_attribute& srcObject)           /* Copy constructor*/
          : attribute(srcObject.get_selector())
          , my_value(srcObject.get_value())
          {}

       /** Dtor */
        MQInquiry::integer_attribute::~integer_attribute () {}

        /** Accessor */
        MQLONG MQInquiry::integer_attribute::get_value(void) const { return my_value;  }

        /** Copy data in to ctor-time-allocated buffer */
        MQInquiry::integer_attribute & MQInquiry::integer_attribute::set_value
         (const attribute_type src)
          {
          my_value=src;
          return *this;
          }

const MQInquiry::attribute & MQInquiry::integer_attribute::print(ostream & o) const {
         o  << "Integer attribute print out from MQInquiry::integer_attribute::."
            << hex
            << (unsigned int) this
            << endl;
         o  << "------------------------------------------------"
            << endl;
         o  << "Selector == " << get_selector() << " " << get_name()
            << endl;
         o  << "Value == " << get_value()
            << endl;
         o  << "_________________________________________________"
            << endl;
         return *this;
         }/* MQInquiry::integer_attribute & MQInquiry::integer_attribute::print(ostream & o)*/

// End of integer_attribute class definition

    /** Array of char attrs */
//    class MQInquiry::character_attribute_vector : public vector <character_attribute_ptr>

   // public :
      /** Ctor */
      MQInquiry::character_attribute_vector::character_attribute_vector(){}

      /** Clean it out. */
      MQInquiry::character_attribute_vector & MQInquiry::character_attribute_vector::
         clean_out(void)
         {
         character_attribute_vector::iterator it;
         for (it=begin(); it < end(); ++it)
            {
            delete *it;
            }                                                    /* End for*/
         clear();
         return *this;
         }

      /** Assgn opr */
      MQInquiry::character_attribute_vector &
         MQInquiry::character_attribute_vector::operator=
            (const character_attribute_vector & srcObject)
         {
         clean_out();
         character_attribute_vector::const_iterator it;
         for (it=srcObject.begin(); it < srcObject.end(); ++it)
            {
            push_back(new character_attribute(**it));
            }                                                    /* End for*/
         return *this;
         }

      /** Copy ctor */
      MQInquiry::character_attribute_vector::character_attribute_vector
         (character_attribute_vector & srcObject)
         {
         *this = srcObject;
         }

      /** Dtor */
      MQInquiry::character_attribute_vector::~character_attribute_vector()
         { clean_out(); }

/** Attribute text dump to stream */
const MQInquiry::character_attribute_vector &
   MQInquiry::character_attribute_vector::print(ostream & o) const
   {
   character_attribute_vector::const_iterator it;
   for (it=begin(); it < end(); ++it)
      {
      o << "Dump of character_attribute_vector::." << hex << (unsigned int) this << endl;
      o << "-------------------------------------" << endl;
      (**it).print(o);
      o << "_____________________________________" << endl;
      }                                                          /* End for*/
   return *this;
   }                         /* const MQInquiry::character_attribute_vector*/

/* class character_attribute_vector : public vector <character_attribute_ptr> */

//    class MQInquiry::integer_attribute_vector : public vector <integer_attribute_ptr>
   // public :

       /** Ctor */
       MQInquiry::integer_attribute_vector::integer_attribute_vector(){}

       /** Clean it out. */
       MQInquiry::integer_attribute_vector & MQInquiry::integer_attribute_vector::
         clean_out (void) {
         integer_attribute_vector::iterator it;
         for (it=begin(); it < end(); ++it)
            {
            delete (*it);
            }                                                    /* End for*/
         clear();
         return *this;
         }

       /** Assgn opr */
       MQInquiry::integer_attribute_vector &
          MQInquiry::integer_attribute_vector::operator=
            (const integer_attribute_vector & srcObject)
          {
          clean_out();
          integer_attribute_vector::iterator it;
          for (it=begin(); it < end(); ++it)
             {
             push_back(new integer_attribute(**it));
             }                                                   /* End for*/
          return *this;
          }

       /** Copy ctor */
       MQInquiry::integer_attribute_vector::integer_attribute_vector
         (integer_attribute_vector & srcObject)
          {
          *this = srcObject;
          }

       /** Dtor */
       MQInquiry::integer_attribute_vector::~integer_attribute_vector() { clean_out(); }

/** Attribute text dump to stream */
const MQInquiry::integer_attribute_vector &
   MQInquiry::integer_attribute_vector::print(ostream & o) const
   {
   integer_attribute_vector::const_iterator it;
   for (it=begin(); it < end(); ++it)
      {
      o << "Dump of integer_attribute_vector::." << hex << (unsigned int) this << endl;
      o << "-----------------------------------" << endl;
      (**it).print(o);
      o << "___________________________________" << endl;
      }                                                          /* End for*/
   return *this;

               }
 /*  class integer_attribute_vector : public vector <integer_attribute_ptr> */

    /** Init object to hold data for MQINQ calls. */
    MQInquiry::MQInquiry  ()                                 /* Constructor*/
      : my_selector_array(NULL)
      , my_integer_attribute_array(NULL)
      , my_character_attribute_array(NULL)
      {}

    /** Copy constructor*/
    MQInquiry::MQInquiry  (const MQInquiry& srcObject)
      {
      *this = srcObject;
      }

    /** Assignment operator. */
    MQInquiry & MQInquiry::operator=(const MQInquiry& srcObject)
      {
      delete my_selector_array;
      my_selector_array = NULL;
      delete my_integer_attribute_array;
      my_integer_attribute_array = NULL;
      delete my_character_attribute_array;
      my_character_attribute_array = NULL;

      unsigned int i;
      my_integer_attributes   = srcObject.my_integer_attributes;
      my_character_attributes = srcObject.my_character_attributes;
      return *this;
      }

    /** Dtor */
    MQInquiry::~MQInquiry ()
      {
      delete my_selector_array;
      delete my_integer_attribute_array;
      delete my_character_attribute_array;
      }                                                       /* Destructor*/

      /** Add an integer attribute */
    MQInquiry & MQInquiry::add (integer_attribute_ptr pia)
      {
      my_integer_attributes.push_back(pia);
      return *this;
      }

    /** Add a character attribute */
    MQInquiry & MQInquiry::add (character_attribute_ptr pca)
      {
      my_character_attributes.push_back(pca);
      return *this;
      }

    /** Number of int attrs */
    unsigned int MQInquiry::n_integer_attributes  (void) const { return my_integer_attributes  .size(); }

    /** Number of char attrs */
    unsigned int MQInquiry::n_character_attributes(void) const { return my_character_attributes.size(); }

    /** Return nth int attr */
    const  MQInquiry::integer_attribute   & MQInquiry::get_nth_integer_attribute
      ( unsigned int n)
         #ifndef __GNUC__
             throw(std::out_of_range)
         #endif
      {
      return *my_integer_attributes[n];
      }

    /** Return nth char attr */
    const  MQInquiry::character_attribute & MQInquiry::get_nth_character_attribute
      (unsigned int n)
         #ifndef __GNUC__
             throw(std::out_of_range)
         #endif
      {
      return *my_character_attributes[n];
      }

//   protected:

    /** Sum total space needed by character attributes */
    unsigned int MQInquiry::character_attributes_length(void)
      {
      unsigned int result = 0;
      character_attribute_vector::iterator it;
      for (it=my_character_attributes.begin(); it < my_character_attributes.end(); ++it)
         {
         result += (**it).get_length();
         }                                                       /* End for*/
      return result;
      }                   /* unsigned int character_attributes_length(void)*/

      /** Number of selectors needed */
      unsigned int  MQInquiry::n_selectors (void) const
         {
         return n_integer_attributes() + n_character_attributes();
         }

      /** Marshall selectors for MQINC call */
      MQInquiry & MQInquiry::marshall_selectors (void){
         unsigned int i;
         delete my_selector_array;
         my_selector_array = new attribute::selector_type[n_selectors()];

         /* load the char attr selectors */
         for (i=0; i < n_character_attributes(); i++)
            {
            my_selector_array[i]
               = get_nth_character_attribute(i).get_selector();
            }

         /* load the int attr selectors */
        for (i=0; i < n_integer_attributes(); i++)
            {
            my_selector_array[i+n_character_attributes()]
               = get_nth_integer_attribute(i).get_selector();
            }
         return *this;
         }                         /* MQInquiry & marshall_selectors (void)*/

      /** Instance the two [out] value arrays from MQINC */
      MQInquiry & MQInquiry::instance_output_arrays (void) {

         delete my_integer_attribute_array;
         delete my_character_attribute_array;

         my_integer_attribute_array =
            new integer_attribute::attribute_type[n_integer_attributes()];

         memset(my_integer_attribute_array
               , 0
               , n_integer_attributes()
                 *  sizeof(integer_attribute::attribute_type)
               )
               ;

         my_character_attribute_array =
            new character_attribute::attribute_type[character_attributes_length()];

         memset(my_character_attribute_array
               , 0
               , character_attributes_length()
                 *  sizeof(character_attribute::attribute_type)
               )
               ;

         return *this;
         }                     /* MQInquiry & instance_output_arrays (void)*/

      /** Marshall character attributes into transmit buffer */
      MQInquiry &MQInquiry::marshall_character_attributes(void) {
         character_attribute_ptr p;
         unsigned int len;
         unsigned int offset = 0;
         character_attribute_vector::iterator it;
         for (it=my_character_attributes.begin(); it < my_character_attributes.end(); ++it)
            {
            p = *it;
            char * dest = my_character_attribute_array + offset;
            int    len  = p->get_length() - 1;
            strncpy( dest
                   , p->get_value()
                   , len
                   )
                   ;
            dest[len] = '\0';
            offset += p->get_length();
            }
            return *this;
         }                /* MQInquiry &marshall_character_attributes(void)*/


       /** Marshall integer attributes into transmit buffer */
      MQInquiry &MQInquiry::marshall_integer_attributes(void) {
         integer_attribute_ptr p;
         unsigned int len;
         unsigned int index = 0;
         integer_attribute_vector::iterator it;
         for (it=my_integer_attributes.begin(); it < my_integer_attributes.end(); ++it)
            {
            p = *it;
            my_integer_attribute_array[index++] = p->get_value();
            }
         return *this;
      }                     /* MQInquiry &marshall_integer_attributes(void)*/

      /** Instance arrays and fill them for transmission */
      MQInquiry &MQInquiry::marshall_attributes(void) {
         instance_output_arrays();
         marshall_character_attributes();
         marshall_integer_attributes();
         return *this;
         }

      /** Unmarshall character attributes from return buffer */
      MQInquiry &MQInquiry::unmarshall_character_attributes(void) {
         character_attribute_ptr p;
         unsigned int len;
         unsigned int offset = 0;
         character_attribute_vector::iterator it;
         for (it=my_character_attributes.begin(); it < my_character_attributes.end(); ++it)
            {
            p = *it;
            p->set_value(my_character_attribute_array);
            offset += p->get_length();
            }
            return *this;
         }              /* MQInquiry &unmarshall_character_attributes(void)*/

       /** Unmarshall integer attributes from return buffer */
      MQInquiry &MQInquiry::unmarshall_integer_attributes(void) {
         integer_attribute_ptr p;
         unsigned int len;
         unsigned int index = 0;
         integer_attribute_vector::iterator it;
         for (it=my_integer_attributes.begin(); it < my_integer_attributes.end(); ++it)
            {
            p = *it;
            p->set_value(my_integer_attribute_array[index++]);
            }
         return *this;
         }                /* MQInquiry &unmarshall_integer_attributes(void)*/

//   public   :

      /** Represents an error reported on object close */
//      class MQInquiry::InquiryException : public MQException
//        public :
           MQInquiry::InquiryException::InquiryException
            (MQLONG completion_code, MQLONG reason)
            : MQException("Error on MQInquiry::inquire()", completion_code, reason)
            {}
/* class MQInquiry::InquiryException : public MQException*/

      /** Send an inquiry */
      MQInquiry & MQInquiry::inquire
        (MQHCONN mq_connection_handle, MQHOBJ mq_object_handle)
         {
         marshall_selectors();
         instance_output_arrays();

         MQINQ ( mq_connection_handle
               , mq_object_handle
               , n_selectors()
               , my_selector_array
               , n_integer_attributes()
               , my_integer_attribute_array
               , character_attributes_length()
               , my_character_attribute_array
               , &completion_code
               , &reason
               )
               ;
         if(MQCC_OK != completion_code)
            {
            throw InquiryException(completion_code, reason);
            }

         /* Extract the return data into the attributes we stored. */
         unmarshall_character_attributes();
         unmarshall_integer_attributes();

         return *this;
         }   /* MQInquiry & MQInquiry::inquire (const MQObject & mq_object)*/

      /** Set attributes */
      MQInquiry & MQInquiry::set
         (MQHCONN mq_connection_handle, MQHOBJ mq_object_handle)
         {
         marshall_selectors ();
         marshall_attributes();

         MQSET ( mq_connection_handle
               , mq_object_handle
               , n_selectors()
               , my_selector_array
               , n_integer_attributes()
               , my_integer_attribute_array
               , character_attributes_length()
               , my_character_attribute_array
               , &completion_code
               , &reason
               )
               ;
         if(MQCC_OK != completion_code)
            {
            throw SetException(completion_code, reason);
            }

         return *this;
         }


/** Print all attributes */
const MQInquiry & MQInquiry::print (ostream & o) const
   {
   unsigned int i;
   character_attribute * char_attr;
   o << "Printout of MQInquiry::." << (unsigned int) this << endl;
   o << "All Character attributes" << endl;
   o << "************************" << endl;
        my_character_attributes.print(o);
   o << "All Integer attributes  " << endl;
   o << "************************" << endl;
        my_integer_attributes.print(o);
   o << "************************" << endl;
   return *this;
   }       /* const MQInquiry & MQInquiry::print (ostream & o = cout) const*/


// End of MQInquiry class definition

#endif                                 /* SW_MQINQ_CPP              */
