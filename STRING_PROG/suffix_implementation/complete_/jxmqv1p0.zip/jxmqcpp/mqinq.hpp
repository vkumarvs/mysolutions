/**********************************************/
/* mqinq.hpp ... inquiry & set objects        */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQINQ_HPP
#define SW_MQINQ_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

#ifndef SW_MQEXCEPT_HPP
   #include "mqexcept.hpp"
#endif // SW_MQEXCEPT_HPP

#include <vector>
#include <string>
#include <iostream>

namespace SoftWoehr {

/** Object to hold data for MQINQ calls. */
typedef class MQInquiry : public MQBase
{
  public:

    class attribute : public MQBase
    {
      public:

        typedef MQLONG selector_type;

        /** Constructor*/
        attribute  (MQLONG selector_value, const std::string & name = "");

        /** Copy constructor */
        attribute  (const attribute& srcObject);

        /** Destructor */
        ~attribute ();

        /** Read accessor */
        MQLONG get_selector (void) const;

        /** Return name of attribute */
        const std::string & get_name (void) const;

        /** Attribute text dump to stream */
        virtual const attribute & print(std::ostream & o = std::cout) const;

      protected:

        /** Unimplemented */
        attribute  () ;

        /** Write Accessor */
        attribute & set_selector(MQLONG selector);

      private:

        selector_type my_selector;
        std::string my_name;

    }; // End of attribute class definition

   public :

      typedef class character_attribute : public attribute
         {
         public:

         typedef MQCHAR attribute_type;

         /** Constructor */
         character_attribute  ( MQLONG selector_value
                              , MQLONG length
                              , const std::string & name = ""
                              );

         /** Copy ctor */
         character_attribute  (const character_attribute& srcObject);

         /** Assgn opr */
         character_attribute & operator= (const character_attribute& srcObject);

         /** Dtor */
         ~character_attribute (); // Destructor

         /** Accessor */
         MQLONG get_length(void) const;

         /** Accessor */
         const PMQCHAR get_value(void) const;

         /** Copy data in to ctor-time-allocated buffer */
         character_attribute & set_value (const attribute_type *src);

         /** Attribute text dump to stream */
         virtual const attribute & print(std::ostream & o = std::cout) const;

      private:

        MQLONG my_length;                            /* length of char attr*/
        PMQCHAR my_value;              /* Pointer to array of char for attr*/

      } * character_attribute_ptr;/* End of character_attribute class definition*/

      typedef class integer_attribute : public attribute
         {
         public:

         typedef MQLONG attribute_type;

         /** Constructor */
         integer_attribute  ( selector_type selector_value
                            , const std::string & name = ""
                            )
                            ;

         /** Copy ctor */
         integer_attribute  (const integer_attribute& srcObject);

         /** Dtor */
         ~integer_attribute ();

         /** Accessor */
         MQLONG get_value(void) const;

         /** Copy data in to ctor-time-allocated buffer */
         integer_attribute & set_value (const attribute_type src);

         /** Attribute text dump to stream */
         virtual const attribute & print(std::ostream & o = std::cout) const;

      private:

         attribute_type my_value;                               /* int attr*/

      } * integer_attribute_ptr;/* End of integer_attribute class definition*/

      /** Array of char attrs */
      class character_attribute_vector : public std::vector <character_attribute_ptr>
         {
         public   :

            /** Ctor */
            character_attribute_vector();

            /** Empty it out. */
            character_attribute_vector & clean_out (void);

            /** Assgn opr */
            character_attribute_vector &
               operator= (const character_attribute_vector & srcObject);

            /** Copy ctor */
            character_attribute_vector (character_attribute_vector & srcObject);

            /** Dtor */
            ~character_attribute_vector();

            /** Attribute text dump to stream */
            virtual const character_attribute_vector & print(std::ostream & o = std::cout) const;

         };/* class character_attribute_vector : public vector <character_attribute_ptr>*/

      class integer_attribute_vector : public std::vector <integer_attribute_ptr>
         {
         public   :

            /** Ctor */
            integer_attribute_vector();

            /** Empty it out. */
            integer_attribute_vector & clean_out (void);

             /** Assgn opr */
             integer_attribute_vector &
                operator= (const integer_attribute_vector & srcObject);

            /** Copy ctor */
            integer_attribute_vector (integer_attribute_vector & srcObject);

            /** Dtor */
            ~integer_attribute_vector();

            /** Attribute text dump to stream */
            virtual const integer_attribute_vector & print(std::ostream & o = std::cout) const;

         };/* class integer_attribute_vector : public vector <integer_attribute_ptr>*/

    /** Init object to hold data for MQINQ calls. */
    MQInquiry  ();

    /** Copy constructor*/
    MQInquiry  (const MQInquiry& srcObject);

    /** Assignment operator. */
    MQInquiry & operator=(const MQInquiry& srcObject);

    /** Dtor */
    ~MQInquiry ();                                            /* Destructor*/

      /** Add an integer attribute */
    MQInquiry & add (integer_attribute_ptr pia);

    /** Add a character attribute */
    MQInquiry & add (character_attribute_ptr pca);

    /** Number of int attrs */
    unsigned int n_integer_attributes  (void) const;

    /** Number of char attrs */
    unsigned int n_character_attributes(void) const;

    /** Return nth int attr */
    const integer_attribute &
      get_nth_integer_attribute
         ( unsigned int n)
         #ifndef __GNUC__
             throw(std::out_of_range)
         #endif
             ;

    /** Return nth char attr */
    const character_attribute &
      get_nth_character_attribute
         (unsigned int n)
         #ifndef __GNUC__
             throw(std::out_of_range)
         #endif
             ;

   protected:

    /** Sum total space needed by character attributes */
    unsigned int character_attributes_length(void);

      /** Number of selectors needed */
      unsigned int n_selectors (void) const;

      /** Marshall selectors for MQINC call */
      MQInquiry & marshall_selectors (void);

      /** Instance the two [out] value arrays from MQINC */
      MQInquiry & instance_output_arrays (void);

      /** Marshall character attributes into transmit buffer */
      MQInquiry & marshall_character_attributes(void);

       /** Marshall integer attributes into transmit buffer */
      MQInquiry & marshall_integer_attributes(void) ;

      /** Instance arrays and fill them for transmission */
      MQInquiry & marshall_attributes(void);

      /** Unmarshall character attributes from return buffer */
      MQInquiry & unmarshall_character_attributes(void);

       /** Unmarshall integer attributes from return buffer */
      MQInquiry & unmarshall_integer_attributes(void) ;

   public   :

      /** Represents an error reported on object close */
      typedef class InquiryException : public MQException
        {
        public :
           InquiryException(MQLONG completion_code, MQLONG reason);
        } SetException;      /* class InquiryException : public MQException*/

      /** Send an inquiry */
      MQInquiry & inquire (MQHCONN mq_connection_handle, MQHOBJ mq_object_handle);

      /** Set attributes */
      MQInquiry & set (MQHCONN mq_connection_handle, MQHOBJ mq_object_handle);

      /** Print all attributes */
      const MQInquiry & print (std::ostream & o = std::cout) const;

  private:
        character_attribute_vector  my_character_attributes ;
        integer_attribute_vector    my_integer_attributes   ;
        attribute::selector_type            *  my_selector_array;
        integer_attribute  ::attribute_type *  my_integer_attribute_array;
        character_attribute::attribute_type *  my_character_attribute_array;
        MQLONG completion_code;
        MQLONG reason;

   } MQSet; // End of MQInquiry class definition

} // namespace SoftWoehr

#endif                                 /* SW_MQINQ_HPP              */
