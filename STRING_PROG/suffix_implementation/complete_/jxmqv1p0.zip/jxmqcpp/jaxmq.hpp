/**********************************************/
/* jaxmq.hpp ... pull in all declarations.    */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_JAXMQ_HPP
#define SW_JAXMQ_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

#ifndef SW_MQEXCEPT_HPP
   #include "mqexcept.hpp"
#endif // SW_MQEXCEPT_HPP

#ifndef SW_MQQMGR_HPP
   #include "mqqmgr.hpp"
#endif // SW_MQQMGR_HPP

#ifndef SW_MQINQ_HPP
   #include "mqinq.hpp"
#endif // SW_MQINQ_HPP

#ifndef SW_MQOBJ_HPP
   #include "mqobj.hpp"
#endif // SW_MQOBJ_HPP

#ifndef SW_MQQUEUE_HPP
   #include "mqqueue.hpp"
#endif // SW_MQQUEUE_HPP

#ifndef SW_MQMSG_HPP
   #include "mqmsg.hpp"
#endif // SW_MQMSG_HPP

#ifndef SW_MQQMOBJ_HPP
   #include "mqqmobj.hpp"
#endif // SW_MQQMOBJ_HPP

#ifndef SW_MQPRCOBJ_HPP
   #include "mqprcobj.hpp"
#endif // SW_MQPRCOBJ_HPP

#endif                                 /* SW_JAXMQ_HPP              */
