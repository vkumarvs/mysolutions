/**********************************************/
/* mqmsq.hpp ... Message class declarations.  */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQMSG_HPP
#define SW_MQMSG_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

namespace SoftWoehr {

/** Represent MQ Message */
class MQMessage : public MQBase
   {
   public:
      /** Constructor*/
      MQMessage  ();

      /** Constructor arity/2 */
      MQMessage (const unsigned char * message, unsigned long length);

      /** Copy constructor*/
      MQMessage  (const MQMessage& srcObject);

      /** Destructor*/
      ~MQMessage ();

      /** Assignment operator */
      MQMessage & operator= (const MQMessage& srcObject);

      /** Represent MQ Put Message Options. */
      class PutOptions : public MQBase
         {
         public:

            /** Constructor */
            PutOptions  ();

            /** Copy constructor*/
            PutOptions  (const PutOptions& srcObject);

            /** Constructor arity/1 */
            PutOptions  (const MQPMO & mqpmo);

            /** Destructor*/
            ~PutOptions ();

            /** Assignment */
            PutOptions & operator= (const PutOptions& srcObject);

            /** Accessor */
            PMQPMO get_PMQPMO (void);

            /** Put options */
            static const MQLONG put_syncpoint ;  /* (only one of these two)*/
            static const MQLONG put_no_syncpoint ; /* (only one of these two)*/
            static const MQLONG put_no_context;
            static const MQLONG put_default_context;
            static const MQLONG put_identity_context;
            static const MQLONG put_pass_all_context;
            static const MQLONG put_set_identity_context;
            static const MQLONG put_set_all_context;
            static const MQLONG put_alternate_user_authority;
            static const MQLONG put_fail_if_quiescing;
            static const MQLONG put_none;

         private:

            /** Message options struct from MQ includes. */
            MQPMO my_MQPMO;

        };  // End of PutOptions class definition

      /** Represent MQ Get Message Options. */
      class GetOptions : public MQBase
         {
         public:

            /** Constructor */
            GetOptions  ();

            /** Copy constructor*/
            GetOptions  (const GetOptions& srcObject);

            /** Constructor arity/1 */
            GetOptions  (const MQGMO & mqgmo);

            /** Destructor*/
            ~GetOptions ();

            /** Assignment */
            GetOptions & operator= (const GetOptions& srcObject);

            /** Accessor */
            PMQGMO get_PMQGMO (void);

            /**  Get options */
            static const MQLONG get_wait;
            static const MQLONG get_no_wait;
            static const MQLONG get_syncpoint;
            static const MQLONG get_no_syncpoint;
            static const MQLONG get_browse_first;
            static const MQLONG get_browse_next;
            static const MQLONG get_message_under_cursor;
            static const MQLONG get_browse_message_under_cursor;
            static const MQLONG get_lock;
            static const MQLONG get_unlock;
            static const MQLONG get_accept_truncated_message;
            static const MQLONG get_fail_if_quiescing;
            static const MQLONG get_convert;
            static const MQLONG get_none;

         private:

            /** Message options struct from MQ includes. */
            MQGMO my_MQGMO;

         }; // End of GetOptions class definition

      /** Represents MQ Message Descriptor */
      class Descriptor : public MQBase
         {
         public:
            /** Constructor */
            Descriptor  ();

            /** Copy constructor*/
            Descriptor  (const Descriptor& srcObject);

            /** Destructor */
            virtual ~Descriptor ();

            /** Assignment */
            Descriptor & operator= (const Descriptor& srcObject);

            /** Accessor */
            PMQMD get_PMQMD (void);

         protected:

         private:
            /** Message descriptor struct from MQ includes */
            MQMD my_MQMD;

         }; // End of Descriptor class definition

      /** Copy in a message from unsigned char * and length */
      MQMessage & set_message(const unsigned char * message, unsigned long length);

      /** Get pointer to unsigned chars making up message */
      unsigned char * get_message(void);

      /** Get length of message */
      unsigned long get_length(void) const;

      /** Get ref to the put options */
      PutOptions & get_put_options(void);

      /** Get ref to the get options */
      GetOptions & get_get_options(void);

      /** Get ref to the descriptor */
      Descriptor & get_descriptor(void);

   protected:

   private:

      /** Actual message content */
      unsigned char * my_message;

      /** Actual message length */
      unsigned long my_length;

      /** Put options assoc. with this msg. */
      PutOptions my_put_options;

      /** Get options assoc. with this msg. */
      GetOptions my_get_options;

      /** Descriptor assoc. with this msg. */
      Descriptor my_descriptor;

   }; // End of MQMessage class definition

} // namespace SoftWoehr

#endif                                 /* SW_MQMSG_HPP              */
