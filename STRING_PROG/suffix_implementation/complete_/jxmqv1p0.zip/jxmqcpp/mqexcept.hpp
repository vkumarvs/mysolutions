/**********************************************/
/* mqexcept.hpp ... exception class           */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQEXCEPT_HPP
#define SW_MQEXCEPT_HPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

#include <string>

namespace SoftWoehr {

/** Text-bearing exceptions */
class MQException : public MQBase {
   public :

      /** 0-arity ctor */
      MQException();

      /** 1-arity ctor */
      MQException(const std::string & s);

      /** 3-arity ctor */
      MQException( const std::string & s
                 , MQLONG completion_code
                 , MQLONG reason
                 )
                 ;

      /** Dtor */
      virtual ~MQException();

      /** Get exception text */
      virtual const std::string & get_text (void)   const;

      /** Get completion code */
      virtual MQLONG get_completion_code   (void)   const;

      /** Get reason */
      virtual MQLONG get_reason            (void)   const;

   private :
      std::string my_text;
      MQLONG my_completion_code;
      MQLONG my_reason;
      };

} // namespace SoftWoehr

#endif                                 /* SW_MQEXCEPT_HPP           */
