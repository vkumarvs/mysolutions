/**********************************************/
/* tstjxmq.hpp ... Subrs for message examples.*/
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_TSTJXMQ_HPP
#define SW_TSTJXMQ_HPP

#ifndef SW_JAXMQ_HPP
   #include "jaxmq.hpp"
#endif // SW_JAXMQ_HPP

/* Disconnect from queue manager */
int release_queue_manager(SoftWoehr::MQQueueManager & queue_manager);

/** Let go of an MQObject. */
int release_object(SoftWoehr::MQObject & object);

#endif                                 /* SW_TSTJXMQ_HPP                   */
