/**********************************************/
/* mqmsg.cpp ... Message class implementation.*/
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQMSG_CPP
#define SW_MQMSG_CPP

#ifndef SW_MQMSG_HPP
   #include "mqmsg.hpp"
#endif // SW_MQMSG_HPP

#include <string>

using namespace std;
using namespace SoftWoehr;

/** Represent MQ Message */
//class MQMessage : public MQBase
//   public:

/** Constructor*/
MQMessage::MQMessage  ()
   : my_message(NULL)
   , my_length(0)
   {}                                               /* MQMessage::MQMessage*/

/** Constructor arity/2 */
MQMessage::MQMessage (const unsigned char * message, unsigned long length)
   : my_message(NULL)
   , my_length(0)
   {
   set_message(message, length);
   }             /* MQMessage (unsigned char * message, unsigned in length)*/

/** Copy constructor*/
MQMessage::MQMessage  (const MQMessage& srcObject)
   : my_message(NULL)
   , my_length(0)
   {
   *this = srcObject;
   }                  /* MQMessage::MQMessage  (const MQMessage& srcObject)*/

/** Destructor*/
MQMessage::~MQMessage ()
   {
   delete my_message;
   }

/** Assignment operator */
MQMessage & MQMessage::operator= (const MQMessage& srcObject)
   {
   set_message(srcObject.my_message, srcObject.my_length);
   my_put_options=srcObject.my_put_options;
   my_descriptor=srcObject.my_descriptor;
   return *this;
   }

/** Represent MQ Put Message Options. */
// class MQMessage::PutOptions : public MQBase
//  public:

/** Constructor */
MQMessage::PutOptions::PutOptions  ()
   {
   using namespace std;
   MQPMO tmp = {MQPMO_DEFAULT};
   memcpy(&my_MQPMO, &tmp, sizeof (MQPMO));
   }                               /* MQMessage::PutOptions::PutOptions  ()*/

/** Copy constructor*/
MQMessage::PutOptions::PutOptions  (const PutOptions& srcObject)
   {
   *this = srcObject;
   }    /* MQMessage::PutOptions::PutOptions  (const PutOptions& srcObject)*/

/** Constructor arity/1 */
MQMessage::PutOptions::PutOptions  (const MQPMO & mqpmo) {
   using namespace std;
   memcpy(&my_MQPMO, &mqpmo, sizeof (MQPMO));}

/** Destructor*/
MQMessage::PutOptions::~PutOptions ()
   {}                              /* MQMessage::PutOptions::~PutOptions ()*/

/** Assignment */
MQMessage::PutOptions & MQMessage::PutOptions::operator= (const MQMessage::PutOptions& srcObject)
   {
   using namespace std;
   memcpy(&my_MQPMO, &srcObject.my_MQPMO, sizeof (MQPMO));
   return *this;
   }/* MQMessage::PutOptions & PutOptions::operator= (const MQMessage::PutOptions& srcObject)*/

/** Accessor */
PMQPMO MQMessage::PutOptions::get_PMQPMO (void)
   {
   return &my_MQPMO;
   }                     /* PMQPMO MQMessage::PutOptions::get_PMQPMO (void)*/

/** Put options */
const MQLONG MQMessage::PutOptions::put_syncpoint  = MQPMO_SYNCPOINT;
const MQLONG MQMessage::PutOptions::put_no_syncpoint  = MQPMO_NO_SYNCPOINT;
const MQLONG MQMessage::PutOptions::put_no_context = MQPMO_NO_CONTEXT;
const MQLONG MQMessage::PutOptions::put_default_context = MQPMO_DEFAULT_CONTEXT;
const MQLONG MQMessage::PutOptions::put_identity_context = MQPMO_PASS_IDENTITY_CONTEXT;
const MQLONG MQMessage::PutOptions::put_pass_all_context = MQPMO_PASS_ALL_CONTEXT;
const MQLONG MQMessage::PutOptions::put_set_identity_context = MQPMO_SET_IDENTITY_CONTEXT;
const MQLONG MQMessage::PutOptions::put_set_all_context = MQPMO_SET_ALL_CONTEXT;
const MQLONG MQMessage::PutOptions::put_alternate_user_authority = MQPMO_ALTERNATE_USER_AUTHORITY;
const MQLONG MQMessage::PutOptions::put_fail_if_quiescing = MQPMO_FAIL_IF_QUIESCING;
const MQLONG MQMessage::PutOptions::put_none = MQPMO_NONE;

// }; // End of MQMessage::PutOptions class definition

/** Represent MQ Put Message Options. */
// class MQMessage::GetOptions : public MQBase
//  public:

/** Constructor */
MQMessage::GetOptions::GetOptions  ()
   {
   MQGMO tmp = {MQGMO_DEFAULT};
   using namespace std;
   memcpy(&my_MQGMO, &tmp, sizeof (MQGMO));
   }                               /* MQMessage::GetOptions::GetOptions  ()*/

/** Copy constructor*/
MQMessage::GetOptions::GetOptions  (const GetOptions& srcObject)
   {
   *this = srcObject;
   }    /* MQMessage::GetOptions::GetOptions  (const GetOptions& srcObject)*/

/** Constructor arity/1 */
MQMessage::GetOptions::GetOptions  (const MQGMO & mqgmo) {
   using namespace std;
   memcpy(&my_MQGMO, &mqgmo, sizeof (MQGMO));}

/** Destructor*/
MQMessage::GetOptions::~GetOptions ()
   {}                              /* MQMessage::GetOptions::~GetOptions ()*/

/** Assignment */
MQMessage::GetOptions & MQMessage::GetOptions::operator= (const MQMessage::GetOptions& srcObject)
   {
   using namespace std;
   memcpy(&my_MQGMO, &srcObject.my_MQGMO, sizeof (MQGMO));
   return *this;
   }/* MQMessage::GetOptions & GetOptions::operator= (const MQMessage::GetOptions& srcObject)*/

/** Accessor */
PMQGMO MQMessage::GetOptions::get_PMQGMO (void)
   {
   return &my_MQGMO;
   }                     /* PMQGMO MQMessage::GetOptions::get_PMQGMO (void)*/

/** Get options */
const MQLONG MQMessage::GetOptions::get_wait = MQGMO_WAIT;
const MQLONG MQMessage::GetOptions::get_no_wait = MQGMO_NO_WAIT;
const MQLONG MQMessage::GetOptions::get_syncpoint = MQGMO_SYNCPOINT;
const MQLONG MQMessage::GetOptions::get_no_syncpoint = MQGMO_NO_SYNCPOINT;
const MQLONG MQMessage::GetOptions::get_browse_first = MQGMO_BROWSE_FIRST;
const MQLONG MQMessage::GetOptions::get_browse_next = MQGMO_BROWSE_NEXT;
const MQLONG MQMessage::GetOptions::get_message_under_cursor = MQGMO_MSG_UNDER_CURSOR;
const MQLONG MQMessage::GetOptions::get_browse_message_under_cursor = MQGMO_BROWSE_MSG_UNDER_CURSOR;
const MQLONG MQMessage::GetOptions::get_lock = MQGMO_LOCK;
const MQLONG MQMessage::GetOptions::get_unlock = MQGMO_UNLOCK;
const MQLONG MQMessage::GetOptions::get_accept_truncated_message = MQGMO_ACCEPT_TRUNCATED_MSG;
const MQLONG MQMessage::GetOptions::get_fail_if_quiescing = MQGMO_FAIL_IF_QUIESCING;
const MQLONG MQMessage::GetOptions::get_convert = MQGMO_CONVERT;
const MQLONG MQMessage::GetOptions::get_none = MQGMO_NONE;

// }; // End of MQMessage::GetOptions class definition

/** Represents MQ Message Descriptor */
//class MQMessage::Descriptor : public MQBase
//  public:

/** Constructor */
MQMessage::Descriptor::Descriptor()
   {
   using namespace std;
   MQMD tmp = {MQMD_DEFAULT};
   memcpy (&my_MQMD, &tmp, sizeof(MQMD));
   }                                 /* MQMessage::Descriptor::Descriptor()*/

/** Copy constructor*/
MQMessage::Descriptor::Descriptor  (const MQMessage::Descriptor& srcObject)
   {
   *this = srcObject;
   }                      /* MQMessage::Descriptor::MQMessage::Descriptor()*/

/** Destructor */
MQMessage::Descriptor::~Descriptor ()
   {}                              /* MQMessage::Descriptor::~Descriptor ()*/

/** Assignment */
MQMessage::Descriptor & MQMessage::Descriptor::operator= (const MQMessage::Descriptor& srcObject)
   {
   using namespace std;
   memcpy (&my_MQMD, &srcObject.my_MQMD, sizeof(MQMD));
   return *this;
   }/* MQMessage::Descriptor & MQMessage::Descriptor::operator= (const MQMessage::Descriptor& srcObject)*/

/** Accessor */
PMQMD MQMessage::Descriptor::get_PMQMD (void)
   {
   return &my_MQMD;
   }                       /* PMQMD MQMessage::Descriptor::get_PMQMD (void)*/

// }; // End of MQMessage::Descriptor class definition

/** Copy in a message from unsigned char * and length */
MQMessage & MQMessage::set_message(const unsigned char * message, unsigned long length)
   {
   using namespace std;
   delete my_message;
   my_length = length;
   my_message = new unsigned char [my_length];
   memcpy (my_message, message, my_length);
   return *this;
   }/* MQMessage & MQMessage::set_message(const unsigned char * message, unsigned int length)*/

/** Get pointer to unsigned chars making up message */
unsigned char * MQMessage::get_message(void) { return my_message; }

/** Get length of message */
unsigned long MQMessage::get_length(void) const { return my_length; }

/** Get ref to the put options */
MQMessage::PutOptions & MQMessage::get_put_options(void) { return my_put_options; }

/** Get ref to the get options */
MQMessage::GetOptions & MQMessage::get_get_options(void) { return my_get_options; }

/** Get ref to the descriptor */
MQMessage::Descriptor & MQMessage::get_descriptor(void) { return my_descriptor; }

// }; // End of MQMessage class definition

#endif                                 /* SW_MQMSG_CPP              */
