/**********************************************/
/* mqbase.cpp ... Base class implementation.  */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQBASE_CPP
#define SW_MQBASE_CPP

#ifndef SW_MQBASE_HPP
   #include "mqbase.hpp"
#endif // SW_MQBASE_HPP

using namespace std;

namespace SoftWoehr {

// /** Base class of hierarchy */
// class MQBase
   // public :

const string MQBase::release_version =
"SoftWoehr Library Release 1.0 Copyright *C* 1999 for IBM MQSeries** 2.x.";

/** Ctor */
MQBase::MQBase (){}

/** Dtor */
MQBase::~MQBase(){}

} // namespace SoftWoehr

#endif                                 /* SW_MQBASE_CPP             */
