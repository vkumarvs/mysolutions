/**********************************************/
/* mqqueue.hpp ... Queue class declarations.  */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQQUEUE_HPP
#define SW_MQQUEUE_HPP

#ifndef SW_MQOBJ_HPP
   #include "mqobj.hpp"
#endif // SW_MQOBJ_HPP

#ifndef SW_MQMSG_HPP
   #include "mqmsg.hpp"
#endif // SW_MQMSG_HPP

namespace SoftWoehr {

/** Represents a queue */
class MQQueue : public MQObject
   {
   public   :

      /** Create an MQQueue with the descriptor already set to Queue */
      MQQueue();

      /** Dtor */
      virtual ~MQQueue();

      /** Class representing error on message put */
      class MessagePutException : public MQException
         {
         public   :
            MessagePutException( MQLONG completion_code
                               , MQLONG reason
                               )
                               ;
         };               /* class MessagePutException : public MQException*/

      /** Class representing error on message static put */
      class MessageStaticPutException : public MessagePutException
         {
         public   :
            MessageStaticPutException
               ( MQLONG completion_code
               , MQLONG reason
               )
               ;
         }; /* class MessageStaticPutException : public MessagePutException*/

      /** Class representing error on message get */
      class MessageGetException : public MQException
         {
         public   :
            MessageGetException( MQLONG completion_code
                               , MQLONG reason
                               )
                               ;
         };               /* class MessageGetException : public MQException*/

      /** Open this object in style of superclass.
        * This overload serves merely to keep the very picky Sun
        * Sun CC 5.0 * compiler from complaining about name hiding.
        */
      virtual MQObject & open ( MQQueueManager & queue_manager
                              , const Descriptor& descriptor
                              , const Options   & options
                              )
        {
        return MQObject::open( queue_manager
                             , descriptor
                             , options
                             )
                             ;
        }

      /** Open a named queue on a given queue manager */
      virtual MQQueue & open( MQQueueManager    & queue_manager
                            , const std::string & queue_name
                            , const MQObject::Options & options
                            )
                            ;

      /** Put a message to the queue */
      MQQueue & put ( unsigned char * message
                    , unsigned long message_length
                    , MQMessage::Descriptor & message_descriptor
                    , MQMessage::PutOptions & put_message_options
                    ) throw( NotOpenedException
                           , MessagePutException
                           )
                    ;

      /** Put a message to the queue */
      MQQueue & put ( MQMessage & mq_message)
         throw( NotOpenedException
              , MessagePutException
              )
         ;

      /** Static member function (Class method).
        * Put one message to a queue
        * without priorly opening a queue.
        * If returns aren't zero (0) throw exception.
        */
      static void put  ( MQQueueManager      &queue_manager
                       , MQQueue::Descriptor &object_descriptor
                       , MQMessage           &message
                       ) throw (MessageStaticPutException)
                       ;

      /** Get a message from the queue */
      MQQueue & get ( unsigned char * message
                    , unsigned long message_length
                    , long * data_length
                    , MQMessage::Descriptor & message_descriptor
                    , MQMessage::GetOptions & get_message_options
                    ) throw( NotOpenedException
                           , MessageGetException
                           )
                    ;

      /** Get a message from the queue */
      MQQueue & get ( MQMessage & mq_message, unsigned long length)
         throw( NotOpenedException
              , MessageGetException
              )
         ;

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* The code within these blocks was autogenerated    */
/* using the following files found in $JXMQ/pl.      */
/* atrqqihp.pl atrqqicp.pl atrqqchp.pl atrqqccp.pl   */
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/** Character attribute factory for MQCA_BACKOUT_REQ_Q_NAME */
static MQInquiry::character_attribute *
   mqca_backout_req_q_name(void);

/** Character attribute factory for MQCA_BASE_Q_NAME */
static MQInquiry::character_attribute *
   mqca_base_q_name(void);

/** Character attribute factory for MQCA_CREATION_DATE */
static MQInquiry::character_attribute *
   mqca_creation_date(void);

/** Character attribute factory for MQCA_CREATION_TIME */
static MQInquiry::character_attribute *
   mqca_creation_time(void);

/** Character attribute factory for MQCA_INITIATION_Q_NAME */
static MQInquiry::character_attribute *
   mqca_initiation_q_name(void);

/** Character attribute factory for MQCA_PROCESS_NAME */
static MQInquiry::character_attribute *
   mqca_process_name(void);

/** Character attribute factory for MQCA_Q_DESC */
static MQInquiry::character_attribute *
   mqca_q_desc(void);

/** Character attribute factory for MQCA_Q_NAME */
static MQInquiry::character_attribute *
   mqca_q_name(void);

/** Character attribute factory for MQCA_REMOTE_Q_MGR_NAME */
static MQInquiry::character_attribute *
   mqca_remote_q_mgr_name(void);

/** Character attribute factory for MQCA_REMOTE_Q_NAME */
static MQInquiry::character_attribute *
   mqca_remote_q_name(void);

/** Character attribute factory for MQCA_TRIGGER_DATA */
static MQInquiry::character_attribute *
   mqca_trigger_data(void);

/** Character attribute factory for MQCA_XMIT_Q_NAME */
static MQInquiry::character_attribute *
   mqca_xmit_q_name(void);

/** Integer attribute factory for MQIA_BACKOUT_THRESHOLD */
static MQInquiry::integer_attribute *
   mqia_backout_threshold(void);

/** Integer attribute factory for MQIA_CURRENT_Q_DEPTH */
static MQInquiry::integer_attribute *
   mqia_current_q_depth(void);

/** Integer attribute factory for MQIA_DEF_INPUT_OPEN_OPTION */
static MQInquiry::integer_attribute *
   mqia_def_input_open_option(void);

/** Integer attribute factory for MQIA_DEF_PERSISTENCE */
static MQInquiry::integer_attribute *
   mqia_def_persistence(void);

/** Integer attribute factory for MQIA_DEF_PRIORITY */
static MQInquiry::integer_attribute *
   mqia_def_priority(void);

/** Integer attribute factory for MQIA_DEFINITION_TYPE */
static MQInquiry::integer_attribute *
   mqia_definition_type(void);

/** Integer attribute factory for MQIA_HARDEN_GET_BACKOUT */
static MQInquiry::integer_attribute *
   mqia_harden_get_backout(void);

/** Integer attribute factory for MQIA_INHIBIT_GET */
static MQInquiry::integer_attribute *
   mqia_inhibit_get(void);

/** Integer attribute factory for MQIA_INHIBIT_PUT */
static MQInquiry::integer_attribute *
   mqia_inhibit_put(void);

/** Integer attribute factory for MQIA_MAX_MSG_LENGTH */
static MQInquiry::integer_attribute *
   mqia_max_msg_length(void);

/** Integer attribute factory for MQIA_MAX_Q_DEPTH */
static MQInquiry::integer_attribute *
   mqia_max_q_depth(void);

/** Integer attribute factory for MQIA_MSG_DELIVERY_SEQUENCE */
static MQInquiry::integer_attribute *
   mqia_msg_delivery_sequence(void);

/** Integer attribute factory for MQIA_OPEN_INPUT_COUNT */
static MQInquiry::integer_attribute *
   mqia_open_input_count(void);

/** Integer attribute factory for MQIA_OPEN_OUTPUT_COUNT */
static MQInquiry::integer_attribute *
   mqia_open_output_count(void);

/** Integer attribute factory for MQIA_Q_DEPTH_HIGH_EVENT */
static MQInquiry::integer_attribute *
   mqia_q_depth_high_event(void);

/** Integer attribute factory for MQIA_Q_DEPTH_HIGH_LIMIT */
static MQInquiry::integer_attribute *
   mqia_q_depth_high_limit(void);

/** Integer attribute factory for MQIA_Q_DEPTH_LOW_EVENT */
static MQInquiry::integer_attribute *
   mqia_q_depth_low_event(void);

/** Integer attribute factory for MQIA_Q_DEPTH_LOW_LIMIT */
static MQInquiry::integer_attribute *
   mqia_q_depth_low_limit(void);

/** Integer attribute factory for MQIA_Q_DEPTH_MAX_EVENT */
static MQInquiry::integer_attribute *
   mqia_q_depth_max_event(void);

/** Integer attribute factory for MQIA_Q_SERVICE_INTERVAL */
static MQInquiry::integer_attribute *
   mqia_q_service_interval(void);

/** Integer attribute factory for MQIA_Q_SERVICE_INTERVAL_EVENT */
static MQInquiry::integer_attribute *
   mqia_q_service_interval_event(void);

/** Integer attribute factory for MQIA_Q_TYPE */
static MQInquiry::integer_attribute *
   mqia_q_type(void);

/** Integer attribute factory for MQIA_RETENTION_INTERVAL */
static MQInquiry::integer_attribute *
   mqia_retention_interval(void);

/** Integer attribute factory for MQIA_SCOPE */
static MQInquiry::integer_attribute *
   mqia_scope(void);

/** Integer attribute factory for MQIA_SHAREABILITY */
static MQInquiry::integer_attribute *
   mqia_shareability(void);

/** Integer attribute factory for MQIA_TRIGGER_CONTROL */
static MQInquiry::integer_attribute *
   mqia_trigger_control(void);

/** Integer attribute factory for MQIA_TRIGGER_DEPTH */
static MQInquiry::integer_attribute *
   mqia_trigger_depth(void);

/** Integer attribute factory for MQIA_TRIGGER_MSG_PRIORITY */
static MQInquiry::integer_attribute *
   mqia_trigger_msg_priority(void);

/** Integer attribute factory for MQIA_TRIGGER_TYPE */
static MQInquiry::integer_attribute *
   mqia_trigger_type(void);

/** Integer attribute factory for MQIA_USAGE */
static MQInquiry::integer_attribute *
   mqia_usage(void);

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* End of autogenerated code.                        */
/* using the following files found in $JXMQ/pl.      */
/* atrqqihp.pl atrqqicp.pl atrqqchp.pl atrqqccp.pl   */
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/** Compose an inquiry which applies to any queue. */
static MQInquiry * inquiry_any_queue(void);

};                                    /* class MQQueue : public MQObject*/

} // namespace SoftWoehr

#endif                                 /* SW_MQQUEUE_HPP      */
