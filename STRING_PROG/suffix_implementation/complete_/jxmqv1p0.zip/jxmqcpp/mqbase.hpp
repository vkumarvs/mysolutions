/**********************************************/
/* mqbase.hpp ... base class declaration.     */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQBASE_HPP
#define SW_MQBASE_HPP

#ifndef MQC_INCLUDED
   #include <cmqc.h>
#endif // MQC_INCLUDED

#ifndef MQCFC_INCLUDED
   #include <cmqcfc.h>
#endif // MQCFC_INCLUDED

#ifndef MQXC_INCLUDED
   #include <cmqxc.h>
#endif // MQXC_INCLUDED

#ifndef MQZC_INCLUDED
   #include <cmqzc.h>
#endif // MQZC_INCLUDED

#include <string>

namespace SoftWoehr {

/** Base class of hierarchy */
class MQBase {
   public :

      static const std::string release_version;

      /** Ctor */
      MQBase ();

      /** Dtor */
      virtual ~MQBase();
   };

} // namespace SoftWoehr

#endif                                 /* SW_MQBASE_HPP             */
