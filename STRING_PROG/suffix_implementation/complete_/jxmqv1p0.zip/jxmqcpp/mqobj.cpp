/**********************************************/
/* mqobj.cpp ... Object implementation.       */
/* Part of SoftWoehr Library for IBM MQSeries */
/* Copyright *C* 1999 Jack J. Woehr           */
/* PO Box 51, Golden, Colorado 80402-0051     */
/* http://www.well.com/user/jax/SoftWoehr     */
/* jwoehr@ibm.net jax@well.com                */
/* ********************************************/
/* This is open source software. Please see   */
/* file license.txt. THERE IS NO WARRANTY.    */
/**********************************************/
#ifndef SW_MQOBJ_CPP
#define SW_MQOBJ_CPP

#ifndef SW_MQOBJ_HPP
   #include "mqobj.hpp"
#endif // SW_MQOBJ_HPP

#ifndef SW_MQINQ_HPP
   #include "mqinq.hpp"
#endif // SW_MQINQ_HPP

using namespace std;
using namespace SoftWoehr;

/*
 * class MQObject
 */

/** ctor */
MQObject::MQObject()
   : my_queue_manager(NULL)
   , opened (false)
   {
   }

/** dtor */
MQObject::~MQObject() { if (is_opened()) close(MQObject::Options::close_none);}

/** Test open */
bool MQObject::is_opened(void) const { return opened; }

/** Represents an MQ Object Descriptor */
//      class Descriptor :  public MQBase {
//         public :

// class MQObject::Descriptor::NameTooLongException
//   public :
    /** Represents name too long. */
    // class NameTooLongException : public MQException
    // public :
        MQObject::Descriptor::NameTooLongException::NameTooLongException()
          : MQException ("Name too long for object name in object descriptor.")
          {}/* MQObject::Descriptor::NameTooLongException::NameTooLongException()*/

/** Ctor */
MQObject::Descriptor::Descriptor()
   {
   using namespace std;

   /* Construct according to MQOD_DEFAULT */
   MQOD tmp = {MQOD_DEFAULT};
   memcpy(&my_MQOD, &tmp, sizeof(MQOD));
   }

/** Get object type as MQ constants */
MQLONG MQObject::Descriptor::get_object_type(void) const
   {
   return my_MQOD.ObjectType;
   }

/** Set object type */
MQObject::Descriptor & MQObject::Descriptor::object_type_queue(void) {
   my_MQOD.ObjectType = MQOT_Q;
   return *this;
   }

/** Set object type */
MQObject::Descriptor & MQObject::Descriptor::object_type_process_definition(void) {
   my_MQOD.ObjectType = MQOT_PROCESS;
   return *this;
   }

/** Set object type */
MQObject::Descriptor & MQObject::Descriptor::object_type_queue_manager(void) {
   my_MQOD.ObjectType = MQOT_Q_MGR;
   return *this;
   }

/** Get object name */
const string & MQObject::Descriptor::get_object_name(void) const
   {
   return my_name;
   }

/** Set object name .. COPIES DATA */
MQObject::Descriptor & MQObject::Descriptor::set_object_name( const string & object_name) {
   if (
      (object_name.length() + (1 * sizeof(char))) // NULL terminator
      > sizeof(my_MQOD.ObjectName)
      )
      {
      throw NameTooLongException();
      }
   strcpy (my_MQOD.ObjectName, object_name.c_str());

   /* Assign to the STL string we keep to give const string refs to name. */
   my_name = object_name;

   return *this;
   }

/** Get object queue manager name */
const string & MQObject::Descriptor::get_object_queue_manager_name(void) const
   {
   return my_queue_manager_name;
   }/* const string & MQObject::Descriptor::get_object_queue_manager_name(void) const*/

/** Set object queue manager name .. COPIES DATA */
MQObject::Descriptor &
   MQObject::Descriptor::set_object_queue_manager_name
      ( const string & object_queue_manager_name)
   {
   if (
      (object_queue_manager_name.length() + (1 * sizeof(char)))/* NULL terminator*/
      > sizeof(my_MQOD.ObjectQMgrName)
      )
      {
      throw NameTooLongException();
      }
   strcpy (my_MQOD.ObjectQMgrName, object_queue_manager_name.c_str());

   /* Assign to the STL string we keep to give const string refs to name. */
   my_queue_manager_name = object_queue_manager_name;

   return *this;
   }                                              /* MQObject::Descriptor &*/
   /* MQObject::Descriptor::set_object_queue_manager_name */
   /* ( const string & object_queue_manager_name) */

/** Get pointer to MQOD struct */
PMQOD MQObject::Descriptor::get_PMQOD(void) { return &my_MQOD; }

//////////////////////////////
// End of MQObject::Descriptor
//////////////////////////////

/** Represents an MQ create Options */
// class MQObject::MQOptions
//   public :
MQObject::Options::Options (MQLONG opt) : my_options(opt) {}

MQObject::Options::~Options(){}

MQLONG MQObject::Options::get_MQLONG(void) {return my_options;}
/** Static members */

/** Open options */
const MQLONG MQObject::Options::open_browse           = MQOO_BROWSE  ;
const MQLONG MQObject::Options::open_input_shared     = MQOO_INPUT_SHARED   ;/* (only one of these)*/
const MQLONG MQObject::Options::open_input_exclusive  = MQOO_INPUT_EXCLUSIVE;/* (only one of these)*/
const MQLONG MQObject::Options::open_inquire          = MQOO_INQUIRE ;
const MQLONG MQObject::Options::open_output           = MQOO_OUTPUT  ;
const MQLONG MQObject::Options::open_set              = MQOO_SET     ;

/** Close options */
const MQLONG MQObject::Options::close_none   =  MQCO_NONE         ;
const MQLONG MQObject::Options::close_delete =  MQCO_DELETE       ;
const MQLONG MQObject::Options::close_purge  =  MQCO_DELETE_PURGE ;

///////////////////////////
// End of MQObject::Options
///////////////////////////

// Back to MQObject itself.

/** Open referenced object */
MQObject & MQObject::open  ( MQQueueManager             & queue_manager
                           , const MQObject::Descriptor & descriptor
                           , const MQObject::Options    & options
                           )
   {
   /** Don't discard if already open. */
   if (is_opened()) throw AlreadyOpenException();

   /* Instance pointer to associated queue manager */
   if (my_queue_manager != &queue_manager)
      {
      my_queue_manager = &queue_manager;
      }

   /* Copy object data if necessary */
   if (&my_descriptor != &descriptor)
      {
      my_descriptor = descriptor;
      }

   /* Copy object data if necessary */
   if (&my_options != &options)
      {
      my_options = options;
      }

   /* Do the open */
   MQOPEN( get_connection_handle()
         , my_descriptor.get_PMQOD()
         , my_options.get_MQLONG()
         , &my_object_handle
         , &my_completion_code
         , &my_reason
         )
         ;

   /* Did we succeed */
   if (my_completion_code != MQCC_OK) {
      my_queue_manager = NULL;
      opened = false;
      throw FailedToOpenException(my_completion_code, my_reason);
      }

   /* If we got here, we're open. */
   opened = true;

   /* Done */
   return *this;
   }  /* MQObject & MQObject::open  ( MQQueueManager        & queue_manager*/
     /*                    , MQObject::Descriptor  & descriptor */
     /*                    , MQObject::Options     & options    */
     /*                    )                                    */

/** Close object */
MQObject & MQObject::close(MQObject::Options close_options) {

   /* Don't close if not opened.*/
   if (!is_opened())
      {
      throw NotOpenedException();
      }

   // !!! Should check close options here against my_options
   // !!! which preserves the original options to compare against.
   // !!! There do exist some illegal combinations of state and close
   // !!! options so it would be wise to investigate.

   /* Do the close */
   MQCLOSE ( get_connection_handle()
           , &my_object_handle
           , close_options.get_MQLONG()
           , &my_completion_code
           , &my_reason
           )
           ;

   /* Examine errors. Some imply the queue is no longer open. Some don't. */
   if (MQCC_FAILED == my_completion_code)
      {
//     switch (my_reason)
//          {
//          case MQRC_CALL_IN_PROGRESS :/* (2219, X'8AB') MQ call reentered before previous call complete.*/
//             break;
//
//          case MQRC_CONNECTION_BROKEN:/* (2009, X'7D9') Connection to queue manager lost.*/
//             opened = false;
//             break;
//
//          case MQRC_HCONN_ERROR      :/* (2018, X'7E2') Connection handle not valid.*/
//             opened = false;
//             break;
//
//          case MQRC_HOBJ_ERROR       :/* (2019, X'7E3') Object handle not valid.*/
//             opened = false;
//             break;
//
//          case MQRC_NOT_AUTHORIZED   :/* (2035, X'7F3') Not authorized for access.*/
//             break;
//
//          case MQRC_OBJECT_DAMAGED   : // (2101, X'835') Object damaged.
//             opened = false;
//             break;
//
//          case MQRC_OPTION_NOT_VALID_FOR_TYPE :/* (2045, X'7FD') Option not valid for object type.*/
//             break;
//
//          case MQRC_OPTIONS_ERROR    :/* (2046, X'7FE') Options not valid or not consistent.*/
//             break;
//
//          case MQRC_Q_MGR_STOPPING   :/* (2162, X'872') Queue manager shutting down.*/
//             opened = false;
//             break;
//
//          case MQRC_Q_NOT_EMPTY      :/* (2055, X'807') Queue contains 1 or more messages or uncommitted put or get*/
//             break;
//
//          case MQRC_RESOURCE_PROBLEM :/* (2102, X'836') Insufficient system resources available.*/
//             break;
//
//          case MQRC_SECURITY_ERROR   :/* (2063, X'80F') Security error occurred.*/
//             break;
//
//          case MQRC_STORAGE_NOT_AVAILABLE  :/* (2071, X'817') Insufficient storage available.*/
//             break;
//
//          case MQRC_UNEXPECTED_ERROR       :/* (2195, X'893') Unexpected error occurred.*/
//             break;
//
//          default  :
//             break;
//             // Nada
//          }

      throw ErrorOnCloseException(my_completion_code, my_reason);
      }

   /* In any event, we are closed after this. */
   opened = false;

   /* Done */
   return *this;
   }

/** Perform an inquiry on the object */
const MQObject & MQObject::inquire (MQInquiry & mq_inquiry) const
   {
   mq_inquiry.inquire(get_connection_handle(), get_object_handle());
   return *this;
   }         /* MQObject & MQObject::inquire (MQInquiry & mq_inquiry) const*/

/** Perform an attribute set on the object */
const MQObject & MQObject::set (MQSet & mq_set) const
   {
   mq_set.set(get_connection_handle(), get_object_handle());
   return *this;
   }               /* const MQObject & MQObject::set (MQSet & mq_set) const*/

/** Return ref to associated queue manager or throw if not open. */
MQQueueManager & MQObject::get_queue_manager(void) const {
   if (NULL==my_queue_manager) {
      throw NoAssociatedQueueManagerException();
      }
   return *my_queue_manager;
   }                  /* MQQueueManager & MQObject::get_queue_manager(void)*/

/** Return connection handle for associated queue manager or throw if not open. */
MQHCONN MQObject::get_connection_handle (void) const {
   return get_queue_manager().get_connection_handle();
   }                                /* MQHCONN get_connection_handle (void)*/

/** Return object handle for associated object or throw if not open. */
MQHOBJ MQObject::get_object_handle (void) const
   {
   if (!is_opened())
      {
      throw NotOpenedException();
      }
   return my_object_handle;
   }                           /* MQHOBJ MQObject::get_object_handle (void)*/

/** Represents object already open */
// class AlreadyOpenException : public MQException
//               public :
MQObject::AlreadyOpenException::AlreadyOpenException()
   : MQException("This object is already open.")
   {}

/** Represents an error reported on object close */
// class ErrorOnCloseException : public MQException
//        public :
MQObject::ErrorOnCloseException::ErrorOnCloseException(MQLONG completion_code, MQLONG reason)
   : MQException("This object encountered an error closing.", completion_code, reason)
   {}
//        };           /* class ErrorOnCloseException : public MQException*/

/** Represents object failed to open */
// class FailedToOpenException : public MQException
//        public :
MQObject::FailedToOpenException::FailedToOpenException(MQLONG completion_code, MQLONG reason)
   : MQException("This object failed to open.", completion_code, reason)
   {}
//        };           /* class FailedToOpenException : public MQException*/

/** Represents no queue manager associated with object */
//      class NoAssociatedQueueManagerException : public MQException
//        public :
MQObject::NoAssociatedQueueManagerException::NoAssociatedQueueManagerException()
   : MQException("This object has no associated queue manager.")
   {}
//        };              /* class MQObject::NoAssociatedQueueManagerException : public MQException*/

/** Represents object not opened */
//      class NotOpenedException : public MQException
//        public :
MQObject::NotOpenedException::NotOpenedException()
   : MQException("This object is not open.")
   {}
//        };              /* class NotOpenedException : public MQException*/

#endif // SW_MQOBJ_CPP
