
package dph.find;

/**
 * The listener interface for receiving FindActionEvent events.
 * Interface representing the behavior a user takes when
 * performing find, findNext, or findPrevious.
 */
public interface FindActionListener extends java.util.EventListener
{
    public abstract void findPerformed(FindActionEvent event);
    public abstract void findNextPerformed(FindActionEvent event);
    public abstract void findPreviousPerformed(FindActionEvent event);
    public abstract void findAllPerformed(FindActionEvent event);
}