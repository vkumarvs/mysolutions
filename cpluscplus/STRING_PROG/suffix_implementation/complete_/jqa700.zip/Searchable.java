
package dph.find;

import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.util.ListIterator;

/**
 * An interface representing the object being searched. The implementor
 * of this interface will be searched for hits matching the criteria
 * passed as a java.awt.datatransfer.Transferable argument to the search method.
 */
public interface Searchable
{
    /**
     * Conducts the search. The criteria is anything which implements
     * the Transferable interface.  The criteria can be interrogated
     * to determine what flavor of search pattern is being used, and
     * that flavor can then be assessed for applicability to the searchable
     * object.  Returns a bidirectional iterator over the search results.
     *
     * @param  inCriteria Transferable implementation appropriate for this Searchable.
     * @return ListIterator that allows bidirectional iteration over result collection.
     *
     * @exception UnsupportedFlavorException if the criteria are not of a type that
     *            can be searched for within the Searchable object.
     */
    public ListIterator search(Transferable inCriteria) 
        throws UnsupportedFlavorException;
}
