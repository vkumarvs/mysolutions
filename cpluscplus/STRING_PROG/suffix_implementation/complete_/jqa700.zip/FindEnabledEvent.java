
package dph.find;

/**
 * The FindEnabledEvent event sent by FindEnabler objects.  These
 * events notify the interface of the state of the find.
 */
public class FindEnabledEvent extends java.util.EventObject
{
    private boolean canFind;
    private boolean canFindNext;
    private boolean canFindPrevious;
    
// Constructors
    /**
     * Construct so that each member
     * is explicitly initialized.
     */
    public FindEnabledEvent(Object source, boolean canFind, 
        boolean canFindNext, boolean canFindPrevious)
    {
        super(source);
        this.canFind = canFind;
        this.canFindNext = canFindNext;
        this.canFindPrevious = canFindPrevious;
    }
    
    /**
     * Construct without explicit initialization.
     */
    public FindEnabledEvent(Object source)
    {
        super(source);
    }
    
// Public methods

    // Get and set each class member.
    public void setCanFind(boolean state)
    {
        canFind = state;
    }
    
    public boolean getCanFind()
    {
        return canFind;
    }
    
    public void setCanFindNext(boolean state)
    {
        canFindNext = state;
    }
    
    public boolean getCanFindNext()
    {
        return canFindNext;
    }
    
    public void setCanFindPrevious(boolean state)
    {
        canFindPrevious = state;
    }
    
    public boolean getCanFindPrevious()
    {
        return canFindPrevious;
    }
}