
package dph.find;

import java.awt.datatransfer.*;
import java.util.*;

/**
 * Adapter to make Strings into objects that can be searched.
 * This class assumes that instances of Transferable search criteria are Strings
 * forming patterns to be located within the sequence.  Wild cards are not
 * currently supported. A subclass could do this. This class detects all
 * instances of the pattern  within the Searchable String, storing hits in an
 * SearchResultCollection. Transferable search criteria for this class
 * should be DataFlavor.stringFlavor objects, or UnsupportedFlavorException will
 * be thrown.  Matches can be case-sensitive or not.  Typically, subclasses can
 * specialize this for DNA or Contig searching.
 */
public class SearchableStringAdapter implements Searchable
{
// Private data
    private String          mTargetString;   // the string to be searched
    private String          mSearchPattern;  // the pattern being searched for
    private boolean         mSearched;       // flag whether hits have been detected
    private boolean         mMatchCase;      // use case-sensitive matching

    private ArrayList       mStarts; // all detected hits of pattern

// Constructor

    /**
     * Cache off the sequence, but don't know the pattern yet
     * so don't detect any hits.  Could be case-sensitive.
     */
    public SearchableStringAdapter(String inString, boolean inMatchCase)
    {
        mTargetString = inString;
        mSearched = false;
        mMatchCase = inMatchCase;
    }

    /**
     * Cache off the sequence and pattern. Wait until user calls search
     * method to detect hits where pattern exists with the sequence. Call to
     * setPattern will reset the collection array to house hits for the pattern.
     */
    public SearchableStringAdapter(String inString, 
                                   Transferable inPattern, 
                                   boolean inMatchCase)
                                       throws UnsupportedFlavorException
    {
        this(inString,inMatchCase);
        this.setPattern(inPattern);
    }


    /**
     * Set whether this is case-sensitive match or not.
     */
    public void setCaseSensitivity(boolean inMatchCase)
    {
        mMatchCase = inMatchCase;
    }


    /**
     * Is this a case-sensitive match or not?
     */
    public boolean isCaseSensitive()
    {
        return mMatchCase;
    }


    /**
     * Set a new searchable target string.
     */
    public void setSearchableString(String inTargetString)
    {
        mTargetString = inTargetString;
        mSearched = false;
    }


// Searchable interface implementation
    /**
     * Can accept a new pattern, which will reset the collection array if the
     * pattern is not same as existing pattern.  Calls searchForPattern which
     * does the pattern matching and storing of hits in collection.  Returns
     * a bidirectional iterator over the detected hits.
     */
    public ListIterator search(Transferable inPattern)
        throws UnsupportedFlavorException
    {
        this.setPattern(inPattern);
        this.searchForPattern();
        ListIterator iter = null;
        if(mStarts != null)
        {
            iter = mStarts.listIterator();
        }
        return iter;
    }


// Protected methods
    /**
     * Accept a String pattern to be searched for.  If can't get String to be the
     * search pattern from the Transferable argument, throw exception.  Don't really
     * need to make this public since the search method itself can take the new
     * pattern to be searched for.
     */
    protected void setPattern(Transferable inPattern)
        throws UnsupportedFlavorException
    {
        // Must have a String object at this point
        if(inPattern.isDataFlavorSupported(DataFlavor.stringFlavor))
        {
            try {
                // Get the String pattern and test if is a new one.
                String pattern = (String)inPattern.getTransferData(DataFlavor.stringFlavor);
                if(pattern != null  &&  !pattern.equals(mSearchPattern))
                {
                    mSearchPattern = pattern;
                    mSearched = false;
                }
            } catch(ClassCastException ex) {
                throw new UnsupportedFlavorException(DataFlavor.stringFlavor);
            } catch(java.io.IOException ex) {
                System.out.println("Unable to acquire search pattern from data flavor");
                ex.printStackTrace(System.out);
            }
        }
        else
        {
            throw new UnsupportedFlavorException(DataFlavor.stringFlavor);
        }
    }

    public String getPattern()
    {
        return mSearchPattern;
    }

    /**
     * If the pattern hasn't been found in the sequence yet, find it.
     * Do case-sensitive or case-insensitive pattern matching.
     */
    protected void searchForPattern()
    {
        // Search if we haven't already searched this string for this pattern
        if(!mSearched  && mSearchPattern != null  &&  mTargetString != null)
        {
            // newing of collection is here
            mStarts = new ArrayList();

            // Test for case-sensitivity
            String sourceStr = mTargetString;
            String patternStr = mSearchPattern;
            if(!mMatchCase)
            {
                sourceStr = mTargetString.toUpperCase();
                patternStr = mSearchPattern.toUpperCase();
            }

            // Put all hits in the container
            int locale = 0;
            while(locale != -1)
            {
                locale = sourceStr.indexOf(patternStr,locale);
                if(locale != -1)
                {
                    mStarts.add(new Integer(locale));
                    locale ++;
                }
            }

            // Now we have searched it
            mSearched = true;
        }
    }
}