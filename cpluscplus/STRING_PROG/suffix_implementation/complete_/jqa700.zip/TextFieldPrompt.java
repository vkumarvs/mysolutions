
package dph.find.test;

import java.awt.*;
import java.io.*;
import dph.find.*;
import java.util.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

public class TextFieldPrompt extends TextField 
    implements TextListener, FindPrompt, FindEnabler
{
    private Vector findEnabledListeners = new Vector();
    
// Constructor    
    public TextFieldPrompt(int columns)
    {
        super(columns);
        this.addTextListener(this);
    }
    
// java.awt.event.TextListener interface implementation
    /**
     * Whenever the text value changes, let any registered
     * listeners know.
     */
    public void textValueChanged(TextEvent event)
    {
        // Create a FindEnabledEvent with this as its source.
        // Set the find state equal to whether there is
        // something to find or not and fire the event off
        // to all FindEnabledListener listeners.
        FindEnabledEvent evt = new FindEnabledEvent(this);
        String str = this.getText();
        evt.setCanFind(str.length() > 0);
        for(int i = 0; i < findEnabledListeners.size(); ++i)
        {
            FindEnabledListener listener = 
                (FindEnabledListener)findEnabledListeners.elementAt(i);
            listener.findChanged(evt);    
        }
    }
    
// FindPrompt interface implementation
    /**
     * The TextField itself is the prompting component
     * that users interact with.
     */
    public Component getPromptComponent()
    {
        return this;
    }
    
// FindEnabler interface implementation
    public void addFindEnabledListener(FindEnabledListener listener)
    {
        findEnabledListeners.addElement(listener);
    }
    
    public void removeFindEnabledListener(FindEnabledListener listener)
    {
        findEnabledListeners.removeElement(listener);
    }
    
// java.awt.datatransfer.Transferable interface
    /**
     * Return an array of DataFlavor objects indicating 
     * the flavors the data can be provided in. For now
     * just return the String flavor because we are doing
     * a text search using Strings.
     */
    public DataFlavor[] getTransferDataFlavors()
    {
        DataFlavor[] flavors = {DataFlavor.stringFlavor};
        return flavors;
    }

    /**
     * Can transfer only String data.
     */
    public boolean isDataFlavorSupported(DataFlavor flavor)
    {
        return flavor.equals(DataFlavor.stringFlavor);
    }


    /**
     * Return an object which represents the data to be transferred.
     * The class of the object returned is defined by the class of 
     * the flavor passed as an argument.
     *
     * @param  flavor  the requested flavor for the data
     *
     * @exception IOException  if the data is no longer available in the requested flavor.
     * @exception UnsupportedFlavorException if the requested data flavor is not supported.
     */
    public Object getTransferData(DataFlavor flavor)
        throws UnsupportedFlavorException, IOException
    {
        if(!flavor.equals(DataFlavor.stringFlavor))
        {
            throw new UnsupportedFlavorException(flavor);
        }
        return getText();
    }
}