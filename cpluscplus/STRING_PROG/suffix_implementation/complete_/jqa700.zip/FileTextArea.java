
package dph.find.test;

import dph.util.*;
import java.awt.*;
import dph.find.*;
import java.util.*;
import java.awt.datatransfer.*;

/**
 * Subclass of TextArea that accomplishes several things:
 * 1) Holds the text that is to be searched, which it gets from
 *    a text file.  The constructor for this class takes a
 *    file name which should point to a text file.  The text
 *    is loaded from the file into this TextArea when an 
 *    instance of this is created.
 *
 * 2) Implemets the FindResult interface, so this class is the
 *    graphical component that handles the results of conducting
 *    the search.  It does so by iterating back and forth through
 *    the results, highlightng the current pattern.
 *
 * 3) Implements the FindListener interface, so when the user
 *    presses the find, findNext, or findPrevious buttons, this
 *    receives event notifications and can update the view.
 *
 * This class generates FindEnabledEvents that reflect the state of
 * the search.  Thus, findPrevious and findNext are not always
 * enabled, but changes to their state are reflected by these events.
 */
public class FileTextArea extends TextArea 
    implements FindResult, FindActionListener, FindEnabler
{
    private Vector              findEnabledListeners = new Vector();
    private String              pattern;
    private boolean             forward = true;
    private boolean             hasNext;
    private boolean             hasPrevious;
    private ListIterator        resultIter;
    private FindEnabledEvent    findEnabledEvent;
    
    
// Constructor
    /**
     * Read in the file named in the argument to this
     * constructor and set it as the text for this TextArea.
     */
    public FileTextArea(int rows, int columns, String fileSpec)
        throws java.io.IOException
    {
        super(rows, columns);
        
        // Read in the contents of the file named in the argument.
        FileStringReader fr = new FileStringReader(fileSpec);
        String txt = fr.readFileIntoString();
        fr.close();
        setText(txt);
        
        // Setup an event we can use throughout the life of this search.
        findEnabledEvent = new FindEnabledEvent(this);
        findEnabledEvent.setCanFind(true);
    }
    
// FindResult interface implementation    
    public Component getResultComponent()
    {
        return this;
    }
    
    /**
     * We are notified of the search result.
     */
    public void setSearchResult(java.util.ListIterator iter)
    {
        resultIter = iter;
    }
    
    /**
     * Return whether to have next & previous activity,
     * or only the find activity.
     */
    public boolean wantsNextPreviousBehavior()
    {
        return true;
    }
    
// FindActionListener interface implementation    
    public void findPerformed(FindActionEvent event)
    {
        // Store off the String that I am searching for
        try
        {
            FindPrompt prompt = (FindPrompt)event.getSource();
            pattern = (String)prompt.getTransferData(DataFlavor.stringFlavor);
        } 
        catch(Exception ex)
        {
            // needs to handle cast, io, interrupted exceptions
        }
        
        if(resultIter.hasNext())
        {
            forward = true;
            Integer integer = (Integer)resultIter.next();
            this.select(integer.intValue(), integer.intValue() + pattern.length());
            hasPrevious = false;
            hasNext = resultIter.hasNext();
            this.enableInterface();
            requestFocus();
        }
    }
    
    public void findNextPerformed(FindActionEvent event)
    {
        if(forward)
        {
            hasPrevious = resultIter.hasPrevious();
            Integer integer = (Integer)resultIter.next();
            this.select(integer.intValue(), integer.intValue() + pattern.length());
            hasNext = resultIter.hasNext();
            this.enableInterface();
       }
        else
        {
            resultIter.next(); // advance extra because changed direction
            Integer integer = (Integer)resultIter.next();
            this.select(integer.intValue(), integer.intValue() + pattern.length());
            hasPrevious = resultIter.hasPrevious();
            hasNext = resultIter.hasNext();
            this.enableInterface();
        }
        forward = true;
        requestFocus();
    }
    
    public void findPreviousPerformed(FindActionEvent event)
    {
        if(forward)
        {
            resultIter.previous(); // extra because changed direction
            Integer integer = (Integer)resultIter.previous();
            this.select(integer.intValue(), integer.intValue() + pattern.length());
            hasNext = resultIter.hasNext();
            hasPrevious = resultIter.hasPrevious();
            this.enableInterface();
        }
        else
        {
            hasNext = resultIter.hasNext();
            Integer integer = (Integer)resultIter.previous();
            hasPrevious = resultIter.hasPrevious();
            this.select(integer.intValue(), integer.intValue() + pattern.length());
            this.enableInterface();
        }
        forward = false;
        requestFocus();
    }
    
    public void findAllPerformed(FindActionEvent event)
    {
        // no-op
    }
    
// FindEnabler interface implementation
    public void addFindEnabledListener(FindEnabledListener listener)
    {
        if(!findEnabledListeners.contains(listener))
            findEnabledListeners.addElement(listener);
    }
    
    public void removeFindEnabledListener(FindEnabledListener listener)
    {
        if(findEnabledListeners.contains(listener))
            findEnabledListeners.removeElement(listener);
    }
    
// Protected methods
    protected void enableInterface()
    {
        FindEnabledEvent event = new FindEnabledEvent(this);
        event.setCanFindNext(hasNext);
        event.setCanFindPrevious(hasPrevious);
        for(int i = 0; i < findEnabledListeners.size(); ++i)
        {
            FindEnabledListener listener =
                (FindEnabledListener)findEnabledListeners.elementAt(i);
            listener.findChanged(event);    
        }
    }
}