 
 package dph.find;
 
 import java.awt.datatransfer.*;
 import java.io.*;

/**
 * Make a String into a Transferable.
 */
 public class TransferableStringAdapter implements Transferable
 {
    private String string;

    public TransferableStringAdapter(String inString)
    {
        string = inString;
    }

// java.awt.datatransfer.Transferable interface
    /**
     * Return an array of DataFlavor objects indicating the flavors the data can be
     * provided in. The array should be ordered according to preference for
     * providing the data (from most richly descriptive to least descriptive). For
     * now just return the String flavor.
     */
    public DataFlavor[] getTransferDataFlavors()
    {
        DataFlavor[] flavors = {DataFlavor.stringFlavor};
        return flavors;
    }

    /**
     * Can transfer only String data, so far.
     */
    public boolean isDataFlavorSupported(DataFlavor flavor)
    {
        return flavor.equals(DataFlavor.stringFlavor);
    }


    /**
     * Return an object which represents the data to be transferred.
     * The class of the object returned is defined by the representation
     * class of the flavor.
     *
     * @param  flavor  the requested flavor for the data
     *
     * @exception IOException  if the data is no longer available in the requested flavor.
     * @exception UnsupportedFlavorException if the requested data flavor is not supported.
     */
    public Object getTransferData(DataFlavor flavor)
        throws UnsupportedFlavorException, IOException
    {
        if(!flavor.equals(DataFlavor.stringFlavor))
        {
            throw new UnsupportedFlavorException(flavor);
        }
        return string;
    }
 }