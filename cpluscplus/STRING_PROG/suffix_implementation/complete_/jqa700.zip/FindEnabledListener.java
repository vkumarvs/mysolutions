
package dph.find;

/**
 * The listener interface for receiving FindEnabledEvents.
 * Interface representing the state of a find based on the
 * prompting class and/or the result-handling class.
 */
public interface FindEnabledListener extends java.util.EventListener
{
    /**
     * Notify listeners that the find capability of
     * the FindPrompt changed.
     */
    public abstract void findChanged(FindEnabledEvent event);
    
    /**
     * Notify listeners that the findNext capability of
     * the FindResult changed.
     */
    public abstract void findNextChanged(FindEnabledEvent event);
    
    /**
     * Notify listeners that the findPrevious capability of
     * the FindResult changed.
     */
    public abstract void findPreviousChanged(FindEnabledEvent event);
    
    /**
     * Notify listeners that the findAll capability of
     * the FindPrompt changed.
     */
    public abstract void findAllChanged(FindEnabledEvent event);
}