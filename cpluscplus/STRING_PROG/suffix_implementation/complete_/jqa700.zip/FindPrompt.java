
package dph.find;

import java.awt.Component;

/**
 * Interface which represents the component that is presented
 * to the user as a way to prompt the user to enter criteria 
 * for a search.  This interface folds together both the 
 * prompting component itself and, by extending Transferable,
 * the criteria that will be used as the pattern to be searched for.
 */
public interface FindPrompt extends java.awt.datatransfer.Transferable
{
    /**
     * Return the Component that is the prompt itself.  This is
     * assumed to be a graphical Component.
     */
    public abstract Component getPromptComponent();
}