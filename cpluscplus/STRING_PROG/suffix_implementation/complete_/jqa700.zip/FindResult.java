
package dph.find;

import java.awt.Component;

/**
 * Interface that represents the (probably graphical) Component
 * which handles (probably by displaying) the result of the
 * the find search.
 */
public interface FindResult
{
    public abstract Component getResultComponent();

    /**
     * Give this result handler class a bi-directional iterator 
     * over the results of the search.
     */
    public abstract void setSearchResult(java.util.ListIterator iter); 
    
    
    /**
     * Return whether this find results handler desires 
     * next & previous activity, or only the find activity.
     */
    public abstract boolean wantsNextPreviousBehavior();
}