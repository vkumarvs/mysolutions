
package dph.util;

import java.io.*;


public class FileStringReader extends FileReader 
{

    File file;
    BufferedReader reader;

    public FileStringReader( String fileName ) throws FileNotFoundException, IOException 
	 {
        this( new File( fileName ) );
    }

    public FileStringReader( File file ) throws FileNotFoundException, IOException 
	 {
        super( file );
        this.file = file;
        this.bufferTheReader();
    }

    public String readFileIntoString() throws IOException 
	 {
        int size = (int) file.length();
        char[] data = new char[size];
        int chars_read = 0;
        while( chars_read < size )
            chars_read += this.read( data, chars_read, size-chars_read );
        return new String( data );
    }

    public String readLine() throws IOException 
	 {
       return reader.readLine();
    }

    private void bufferTheReader() 
	 {
        reader = new BufferedReader( this );
    }
}
