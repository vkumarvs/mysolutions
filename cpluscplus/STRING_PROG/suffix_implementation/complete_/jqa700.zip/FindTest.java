
package dph.find.test;

import java.awt.*;
import dph.find.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

public class FindTest
{
    // Pass in name of text file to load into
    // the FileTextArea.
    public static void main(String[] args)
    {
        Searchable searchable = null;
        FindPrompt prompt = null;
        FindResult result = null;
        try
        {
            prompt = new TextFieldPrompt(45);
            result = new FileTextArea(20, 45, args[0]);
            String str = ((TextArea)result).getText();
            searchable = 
                new SearchableStringAdapter(str, prompt, true);
            FindDialog dialog = 
                new FindDialog(new Frame(), prompt, result, searchable);
            dialog.pack();
            dialog.setVisible(true);
        }catch(UnsupportedFlavorException ex) 
        {
            System.out.println("can't search " + searchable + " with " + prompt);
        } catch(java.io.IOException ex)
        {
            System.out.println("can't search " + args[0] + ": " + ex);
        }
    }
}