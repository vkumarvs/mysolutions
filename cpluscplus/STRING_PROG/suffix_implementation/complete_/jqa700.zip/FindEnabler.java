
package dph.find;

/**
 * Interface representing that its implementer can
 * add and remove FindEnabledListener objects.
 */
public interface FindEnabler
{
    public abstract void addFindEnabledListener(FindEnabledListener listener);
    public abstract void removeFindEnabledListener(FindEnabledListener listener);
}