
package dph.find;

import java.awt.*;
import java.util.*;
import dph.find.test.*;
import java.awt.event.*;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

/**
 * The dialog that shows when you want to do a find.
 * It shows the FindPrompt and FindResult components,
 * and displays the find, next, previous, & close buttons.
 *
 * This is responsible for generating the FindActionEvents
 * that take place when the find, next, and previous
 * buttons are pressed, so it maintains a vector of
 * listeners who want to be notified when the find actions
 * happen.
 *
 * It also listens for FindEnabledEvents, so it must
 * register itself with the FindResult component if that
 * component delivers FindEnabledEvents.
 */
public class FindDialog extends Dialog implements FindEnabledListener
{
    private FindPrompt findPrompt;
    private FindResult findResult;
    private Searchable searchable;
    
    private Vector findActionListeners = new Vector();
    
    // gui controls
    Button findBtn;
    Button nextBtn;
    Button prevBtn;
    Button closeBtn;
    
// Constructor
    /**
     * The constructor takes the parent frame for this dialog,
     * the prompting component, the result handling component,
     * and the Searchable target that should be searched.  The
     * FindPrompt object will be (or contain) the criteria or pattern 
     * that is to be searched for within the Searchable.
     */
    public FindDialog(Frame frame, FindPrompt prompt, 
                      FindResult result, Searchable searchable)
    {
        super(frame, "Find", true);
        this.findPrompt = prompt;
        this.findResult = result;
        this.searchable = searchable;
        
        this.setupGUI();
        this.setupEventHandling();
        this.addListeners();
    }
    
// FindEnabledListener interface implementation
    public void findChanged(FindEnabledEvent event)
    {
        findBtn.setEnabled(event.getCanFind());
        nextBtn.setEnabled(event.getCanFindNext());
        prevBtn.setEnabled(event.getCanFindPrevious());
    }
    public void findAllChanged(FindEnabledEvent event){}
    public void findNextChanged(FindEnabledEvent event){}
    public void findPreviousChanged(FindEnabledEvent event){}

    
// Public methods
    // Register listeners who want to be notified when the
    // find, next, and previous buttons are pressed.  These
    // are registered as part of the construction of this
    // dalog.
    public void addFindActionListener(FindActionListener listener)
    {
        findActionListeners.addElement(listener);
    }
    
    public void removeFindActionListener(FindActionListener listener)
    {
        findActionListeners.removeElement(listener);
    }
    
    // Close the application
    public void close()
    {
        System.exit(0);
    }
    
    
// Protected methods
    protected void addListeners()
    {
        // Register the result handler to listen for button clicks.
        if(findResult instanceof FindActionListener)
        {
            this.addFindActionListener((FindActionListener)findResult);
        }
        
        // Register this to listen to the result handler for
        // enabling events.
        if(findResult instanceof FindEnabler)
            ((FindEnabler)findResult).addFindEnabledListener(this);
            
        // Register this to listen to the find prompt for
        // enabling events.
        if(findPrompt instanceof FindEnabler)
            ((FindEnabler)findPrompt).addFindEnabledListener(this);
    }
    
    protected void setupGUI()
    {
        Panel p = null;
        
        Component promptView = findPrompt.getPromptComponent();
        if(promptView != null)
        {
            p = new Panel();
            p.add(promptView);
            add("North", p);
        }
        
        Component resultView = findResult.getResultComponent();
        if(resultView != null)
        {
            p = new Panel();
            p.add(resultView);
            add("Center", p);
        }
        
        p = new Panel();
        findBtn = new Button("Find");
        findBtn.setEnabled(false);
        p.add(findBtn);
        
        if(findResult.wantsNextPreviousBehavior())
        {
            nextBtn = new Button("Next");
            nextBtn.setEnabled(false);
            p.add(nextBtn);
            prevBtn = new Button("Previous");
            prevBtn.setEnabled(false);
            p.add(prevBtn);
        }
        
        closeBtn = new Button("Close");
        p.add(closeBtn);
        add("South", p);
    }
    
    protected void setupEventHandling()
    {
        // Add window listener to close application
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent event)
            {
                close();
            }
        });
        
        // Close dialog when close button is pressed
        closeBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt)
            {
                close();
            }
        });
        
        // Search the Searchable using the Transferable, and
        // give search results to the result handler.  Notify
        // listeners. This is where search starts.
        findBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt)
            {
                try {
                    // Conduct the search
                    ListIterator iter = searchable.search(findPrompt);
                    findResult.setSearchResult(iter);
                    
                    // Notify listeners
                    FindActionEvent event = new FindActionEvent(FindDialog.this.findPrompt);
                    for(int i = 0; i < findActionListeners.size(); ++i)
                    {
                        FindActionListener listener =
                            (FindActionListener)findActionListeners.elementAt(i);
                        listener.findPerformed(event);    
                    }
                } catch(UnsupportedFlavorException ex){
                    System.out.println("Couldn't search " + searchable 
                                       + " using " + findPrompt);
                }
            }
        });
    
        nextBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt)
            {
                // Notify listeners
                FindActionEvent event = new FindActionEvent(FindDialog.this);
                for(int i = 0; i < findActionListeners.size(); ++i)
                {
                    FindActionListener listener =
                        (FindActionListener)findActionListeners.elementAt(i);
                    listener.findNextPerformed(event);    
                }
            }
        });
    
        prevBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt)
            {
                // Notify listeners
                FindActionEvent event = new FindActionEvent(FindDialog.this);
                for(int i = 0; i < findActionListeners.size(); ++i)
                {
                    FindActionListener listener =
                        (FindActionListener)findActionListeners.elementAt(i);
                    listener.findPreviousPerformed(event);    
                }
            }
        });
    }
}