
package dph.find;

/**
 * The event delivered when a user takes a find action of
 * either find, findNext, or findPrevious.
 */
public class FindActionEvent extends java.util.EventObject
{
    public FindActionEvent(Object source)
    {
        super(source);
    }
}