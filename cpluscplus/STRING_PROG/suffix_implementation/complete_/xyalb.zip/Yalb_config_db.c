/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_config_db.c,v 1.2 1994/03/07 10:36:47 carlsson Exp $
 * $Log: yalb_config_db.c,v $
 * Revision 1.2  1994/03/07  10:36:47  carlsson
 * Fixed bug in `is_missval()'.
 *
 * Revision 1.1  1994/02/28  19:26:38  carlsson
 * Introduced #ifdef VERBOSE.
 *
 * Revision 1.0  1993/12/21  10:49:37  carlsson
 * Initial revision
 */

#include "yalb_config_db.h"
#ifdef LINUX
#include <stdio.h>
#include <string.h>
#endif

#ifndef YALB_DATA
#ifdef UNIX
#define YALB_DATA "/usr/local/lib/yalb"
#endif
#ifdef WIN32
#define YALB_DATA "\\usr\\local\\lib\\yalb"
#endif
#endif
#ifndef YALB_CONFIG
#define YALB_CONFIG "yalb.config"
#endif


extern int sscanf(const char *,const char *, ...);
extern int fclose();
extern int fputs();
#ifdef WIN32
extern int _stricmp();
#define strcasecmp _stricmp
#endif
#ifdef UNIX
extern int strcasecmp();
#endif

#define TRUE 1
#define FALSE 0

#define KEY_TIMEOUT "Timeout\t= %ld"
#define KEY_POLL_TIMEOUT "PollTimeout\t= %ld"
#define KEY_SWAP_VALIDITY "SwapValidity\t= %d"
#define KEY_IDLE_HOST "IdleHost\t= %f"
#define KEY_MINIMUM_TOP "MinimumTop\t= %d"
#define KEY_IMPROVMENT "Improvment\t= %d"
#define KEY_STRATEGY "Strategy\t= %s"
#define KEY_LOADPOLLING "Loadpolling\t= %s"
#define KEY_HOST "Host\t= %s"
#define KEY_OS_NAME "OsName\t= %s"
#define KEY_CHOOSE "Choose\t= %s"
#define KEY_STATISTICS "Statistics\t= %s"
#define KEY_ALPHA "Alpha\t= %f"
#define KEY_SYS1 "Sys1\t= %f"
#define KEY_SYS2 "Sys2\t= %f"
#define KEY_SWAP_SERVER "SwapServer\t = %s"
#define KEY_MACHINE "Machine\t = %s"
#define KEY_MAX_LONG "LongJobs\t = %d"

#define MISS_VAL_TIMEOUT -1L
#define MISS_VAL_POLL_TIMEOUT -1L
#define MISS_VAL_SWAP_VALIDITY -1
#define MISS_VAL_IDLE_HOST -1.0
#define MISS_VAL_MINIMUM_TOP -1
#define MISS_VAL_IMPROVMENT -1
#define MISS_VAL_STRATEGY -1
#define MISS_VAL_LOADPOLLING -1
#define MISS_VAL_HOST ""
#define MISS_VAL_OS_NAME ""
#define MISS_VAL_CHOOSE -1
#define MISS_VAL_STATISTICS -1
#define MISS_VAL_ALPHA -1.0
#define MISS_VAL_SYS1 -1.0
#define MISS_VAL_SYS2 -1.0
#define MISS_VAL_SWAP_SERVER ""
#define MISS_VAL_MACHINE ""
#define MISS_VAL_MAX_LONG -1

#define MIN_SWAP_VALIDITY 0
#define MAX_SWAP_VALIDITY 100
#define MIN_IMPROVMENT 0
#define MAX_IMPROVMENT 100



static system_config *global_system_config = NULL;
static host_config_list *global_host_list = NULL;
static host_config_list *global_current_host_list = NULL;


void clear_host_config(host_config *out_host_config)
{
	strcpy(out_host_config->name, MISS_VAL_HOST);
	strcpy(out_host_config->os_name, MISS_VAL_OS_NAME);
	out_host_config->choose = MISS_VAL_CHOOSE;
	strcpy(out_host_config->swap_server, MISS_VAL_SWAP_SERVER);
	strcpy(out_host_config->machine, MISS_VAL_MACHINE);
	out_host_config->alpha = MISS_VAL_ALPHA;
	out_host_config->sys1 = MISS_VAL_SYS1;
	out_host_config->sys2 = MISS_VAL_SYS2;
	out_host_config->max_long = MISS_VAL_MAX_LONG;
}

void clear_system_config(system_config *out_system_config)
{
	out_system_config->timeout = MISS_VAL_TIMEOUT;
	out_system_config->poll_timeout = MISS_VAL_POLL_TIMEOUT;
	out_system_config->swap_validity = MISS_VAL_SWAP_VALIDITY;
	out_system_config->idle_host = MISS_VAL_IDLE_HOST;
	out_system_config->minimum_top = MISS_VAL_MINIMUM_TOP;
	out_system_config->improvment = MISS_VAL_IMPROVMENT;
	out_system_config->strategy = MISS_VAL_STRATEGY;
	out_system_config->loadpolling = MISS_VAL_LOADPOLLING;
	out_system_config->statistics = MISS_VAL_STATISTICS;
}


static int is_open(void)
{
	return( global_system_config ? TRUE : FALSE );
}



static int host_list_insert(host_config_list *in_current_host)	 
{
	in_current_host->rest_of_list = global_host_list;
	global_host_list = in_current_host;
	return( OK_CFDB );
}
	
static host_config_list *host_list_get(char *host)
{
	host_config_list *hlp = global_host_list;

	while( hlp ) {
		if( strcmp(hlp->host_config.name, host) == 0 ) {
			break;
		}
		hlp = hlp->rest_of_list;
	}
	return( hlp );
}

static int read_all_config(FILE *in_fp, int *out_line_number)
{
	char buf[MAXLINELEN];
	char value[MAXLINELEN];
	host_config_list *current_host = NULL;
	int ret;

	global_system_config = (system_config *)malloc(sizeof(system_config));
	clear_system_config(global_system_config);

	if( out_line_number != NULL ) {
		*out_line_number = 0;
	}
	while( fgets(buf, MAXLINELEN, in_fp) != NULL ) {
		if( out_line_number != NULL ) {
			(*out_line_number)++;
		}

		if( *buf == '#' || *buf == ' ' || *buf == '\t' || *buf == '\n' ) {
			;
		}
		else if( sscanf(buf, KEY_TIMEOUT, &global_system_config->timeout) == 1 ) {
			;
		}
		else if( sscanf(buf, KEY_POLL_TIMEOUT, &global_system_config->poll_timeout) == 1 ) {
			;
		}
		else if( sscanf(buf, KEY_SWAP_VALIDITY, &global_system_config->swap_validity) == 1 ) {
			if( global_system_config->swap_validity < MIN_SWAP_VALIDITY || global_system_config->swap_validity > MAX_SWAP_VALIDITY ) {
				return( ERR_CFDB_VALUE );
			}
		}
		else if( sscanf(buf, KEY_IDLE_HOST, &global_system_config->idle_host) == 1 ) {
			;
		}
		else if( sscanf(buf, KEY_MINIMUM_TOP, &global_system_config->minimum_top) == 1 ) {
			;
		}
		else if( sscanf(buf, KEY_IMPROVMENT, &global_system_config->improvment) == 1 ) {
			if( global_system_config->improvment < MIN_IMPROVMENT || global_system_config->improvment > MAX_IMPROVMENT ) {
				return( ERR_CFDB_VALUE );
			}
		}
		else if( sscanf(buf, KEY_STRATEGY, value) == 1 ) {

				if( strcasecmp(value, TOPLIST_NAME) == 0 )
			{
				global_system_config->strategy = TOPLIST;
			}
			else 
		if( strcasecmp(value, TOPHOST_NAME) == 0 )
						
				{
				global_system_config->strategy = TOPHOST;
			}
			else {
				return( ERR_CFDB_VALUE );
			}
		}
		else if( sscanf(buf, KEY_LOADPOLLING, value) == 1 ) {
		

if( strcasecmp(value, YES_NAME) == 0 ) 

			{
				global_system_config->loadpolling = TRUE;
			}
			else 
if( strcasecmp(value, NO_NAME) == 0 ) 
{
				global_system_config->loadpolling = FALSE;
			}
			else {
				return( ERR_CFDB_VALUE );
			}
		}
		else if( sscanf(buf, KEY_HOST, value) == 1 ) {
			current_host = (host_config_list *)malloc(sizeof(host_config_list));
			clear_host_config(&current_host->host_config);
			strcpy(current_host->host_config.name, value);
			if( (ret = host_list_insert(current_host) != OK_CFDB ) ) {
				return( ret );
			}
		}
		else if( current_host && sscanf(buf, KEY_OS_NAME, current_host->host_config.os_name) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_CHOOSE, value) == 1 ) {
if( strcasecmp(value, YES_NAME) == 0 ) {
				current_host->host_config.choose = TRUE;
			}
			else 

	if( strcasecmp(value, NO_NAME) == 0 ) {
					
					current_host->host_config.choose = FALSE;
			}
			else {
				return( ERR_CFDB_VALUE );
			}
			
		}
		else if( sscanf(buf, KEY_STATISTICS, value) == 1 ) {
	if( strcasecmp(value, YES_NAME) == 0 ) {

				global_system_config->statistics = TRUE;
			}
			else 

		if( strcasecmp(value, NO_NAME) == 0 ) {

				global_system_config->statistics = FALSE;
			}
			else {
				return( ERR_CFDB_VALUE );
			}
			
		}
		else if( current_host && sscanf(buf, KEY_ALPHA, &current_host->host_config.alpha) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_SYS1, &current_host->host_config.sys1) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_SYS2, &current_host->host_config.sys2) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_SWAP_SERVER, current_host->host_config.swap_server) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_MACHINE, current_host->host_config.machine) == 1 ) {
			;
		}
		else if( current_host && sscanf(buf, KEY_MAX_LONG, &current_host->host_config.max_long) == 1 ) {
			;
		}
		else {
			return( ERR_CFDB_FORMAT );
		}
	}
	global_current_host_list = global_host_list;
	return( OK_CFDB );
}
			


int is_missval(int type, void *value)
{
	int ret;

	switch( type ) {
	      case TYPE_TIMEOUT:
		ret = ( *(long int *)value == MISS_VAL_TIMEOUT ? TRUE : FALSE );
		break;
	      case TYPE_POLL_TIMEOUT:
		ret = ( *(long int *)value == MISS_VAL_POLL_TIMEOUT ? TRUE : FALSE );
		break;
	      case TYPE_SWAP_VALIDITY:
		ret = ( *(int *)value == MISS_VAL_SWAP_VALIDITY ? TRUE : FALSE );
		break;
	      case TYPE_IDLE_HOST:
		ret = ( *(float *)value == MISS_VAL_IDLE_HOST ? TRUE : FALSE );
		break;
	      case TYPE_MINIMUM_TOP:
		ret = ( *(int *)value == MISS_VAL_MINIMUM_TOP ? TRUE : FALSE );
		break;
	      case TYPE_IMPROVMENT:
		ret = ( *(int *)value == MISS_VAL_IMPROVMENT ? TRUE : FALSE );
		break;
	      case TYPE_STRATEGY:
		ret = ( *(int *)value == MISS_VAL_STRATEGY ? TRUE : FALSE );
		break;
	      case TYPE_LOADPOLLING:
		ret = ( *(int *)value == MISS_VAL_LOADPOLLING ? TRUE : FALSE );
		break;
	      case TYPE_HOST:
		ret = ( strcmp((char *)value, MISS_VAL_HOST) == 0 ? TRUE : FALSE );
		break;
	      case TYPE_OS_NAME:
		ret = ( strcmp((char *)value, MISS_VAL_OS_NAME) == 0 ? TRUE : FALSE );
		break;
	      case TYPE_CHOOSE:
		ret = ( *(int *)value == MISS_VAL_CHOOSE ? TRUE : FALSE );
		break;
	      case TYPE_STATISTICS:
		ret = ( *(int *)value == MISS_VAL_STATISTICS ? TRUE : FALSE );
		break;
	      case TYPE_ALPHA:
		ret = ( *(float *)value <= 0.0 ? TRUE : FALSE );
		break;
	      case TYPE_SYS1:
		ret = ( *(float *)value <= 0.0 ? TRUE : FALSE );
		break;
	      case TYPE_SYS2:
		ret = ( *(float *)value <= 0.0 ? TRUE : FALSE );
		break;
	      case TYPE_MAX_LONG:
		ret = ( *(int *)value == MISS_VAL_MAX_LONG ? TRUE : FALSE );
		break;
	      case TYPE_SWAP_SERVER:
		ret = ( strcmp((char *)value, MISS_VAL_SWAP_SERVER) == 0 ? TRUE : FALSE );
		break;
	      case TYPE_MACHINE:
		ret = ( strcmp((char *)value, MISS_VAL_MACHINE) == 0 ? TRUE : FALSE );
		break;
	      default:
#ifdef VERBOSE
		printf("Unknown type: %d", type);
#endif
		break;
	}
	return( ret );
}

static void config_path(char *path)
{
	strcpy(path, YALB_DATA);
#ifdef UNIX
strcat(path, "/");
#endif
#ifdef WIN32
	   strcat(path, "\\");
#endif
		strcat(path, YALB_CONFIG);
}

static int write_all()
{
	FILE *config_fp;
	char path[80];
	char buf[MAXLINELEN];
	host_config_list *hlp = global_host_list;

	config_path(path);
	if( (config_fp = fopen(path, "w")) == NULL ) {
		return(ERR_CFDB_OPEN);
	}

	if( !is_missval(TYPE_TIMEOUT, (void *)&(global_system_config->timeout)) ) {
		sprintf(buf, KEY_TIMEOUT, global_system_config->timeout);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_POLL_TIMEOUT, (void *)&(global_system_config->poll_timeout)) ) {
		sprintf(buf, KEY_POLL_TIMEOUT, global_system_config->poll_timeout);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_SWAP_VALIDITY, (void *)&(global_system_config->swap_validity)) ) {
		sprintf(buf, KEY_SWAP_VALIDITY, global_system_config->swap_validity);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_IDLE_HOST, (void *)&(global_system_config->idle_host)) ) {
		sprintf(buf, KEY_IDLE_HOST, global_system_config->idle_host);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_MINIMUM_TOP, (void *)&(global_system_config->minimum_top)) ) {
		sprintf(buf, KEY_MINIMUM_TOP, global_system_config->minimum_top);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_IMPROVMENT, (void *)&(global_system_config->improvment)) ) {
		sprintf(buf, KEY_IMPROVMENT, global_system_config->improvment);
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_STRATEGY, (void *)&(global_system_config->strategy)) ) {
		switch( global_system_config->strategy ) {
		      case TOPLIST:
			sprintf(buf, KEY_STRATEGY, TOPLIST_NAME);
			break;
		      case TOPHOST:
			sprintf(buf, KEY_STRATEGY, TOPHOST_NAME);
			break;
		      default:
			sprintf(buf, KEY_STRATEGY, TOPHOST_NAME);
			break;
		}
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_LOADPOLLING, (void *)&(global_system_config->loadpolling)) ) {
		switch( global_system_config->loadpolling ) {
		      case TRUE:
			sprintf(buf, KEY_LOADPOLLING, YES_NAME);
			break;
		      case FALSE:
			sprintf(buf, KEY_LOADPOLLING, NO_NAME);
			break;
		      default:
			sprintf(buf, KEY_LOADPOLLING, NO_NAME);
			break;
		}
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	if( !is_missval(TYPE_STATISTICS, (void *)&(global_system_config->statistics)) ) {
		switch( global_system_config->statistics ) {
		      case TRUE:
			sprintf(buf, KEY_STATISTICS, YES_NAME);
			break;
		      case FALSE:
			sprintf(buf, KEY_STATISTICS, NO_NAME);
			break;
		      default:
			sprintf(buf, KEY_STATISTICS, NO_NAME);
			break;
		}
		strcat(buf, "\n");
		fputs(buf, config_fp);
	}
	

	while( hlp ) {
		fputs("\n", config_fp);
		sprintf(buf, KEY_HOST, hlp->host_config.name);
		strcat(buf, "\n");
		fputs(buf, config_fp);

		if( !is_missval(TYPE_OS_NAME, &(hlp->host_config.os_name)) ) {
			sprintf(buf, KEY_OS_NAME, hlp->host_config.os_name);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_CHOOSE, (void *)&(hlp->host_config.choose)) ) {
			switch( hlp->host_config.choose ) {
			      case TRUE:
				sprintf(buf, KEY_CHOOSE, YES_NAME);
				break;
			      case FALSE:
				sprintf(buf, KEY_CHOOSE, NO_NAME);
				break;
			      default:
				sprintf(buf, KEY_CHOOSE, NO_NAME);
				break;
			}
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_ALPHA, &(hlp->host_config.alpha)) ) {
			sprintf(buf, KEY_ALPHA, hlp->host_config.alpha);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_SYS1, &(hlp->host_config.sys1)) ) {
			sprintf(buf, KEY_SYS1, hlp->host_config.sys1);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_SYS2, &(hlp->host_config.sys2)) ) {
			sprintf(buf, KEY_SYS2, hlp->host_config.sys2);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_MAX_LONG, &(hlp->host_config.max_long)) ) {
			sprintf(buf, KEY_MAX_LONG, hlp->host_config.max_long);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_SWAP_SERVER, &(hlp->host_config.swap_server)) ) {
			sprintf(buf, KEY_SWAP_SERVER, hlp->host_config.swap_server);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		if( !is_missval(TYPE_MACHINE, &(hlp->host_config.machine)) ) {
			sprintf(buf, KEY_MACHINE, hlp->host_config.machine);
			strcat(buf, "\n");
			fputs(buf, config_fp);
		}
		hlp = hlp->rest_of_list;
	}
	fclose(config_fp);
	return( OK_CFDB );
}





int write_system_config(system_config *in_system_config)
{
	if( !is_open() ) {
		return( ERR_CFDB_NOT_OPEN );
	}
	if( !is_missval(TYPE_TIMEOUT, (void *)&(in_system_config->timeout)) ) {
		global_system_config->timeout = in_system_config->timeout;
	}
	if( !is_missval(TYPE_POLL_TIMEOUT, (void *)&(in_system_config->poll_timeout)) ) {
		global_system_config->poll_timeout = in_system_config->poll_timeout;
	}
	if( !is_missval(TYPE_SWAP_VALIDITY, (void *)&(in_system_config->swap_validity)) ) {
		global_system_config->swap_validity = in_system_config->swap_validity;
	}
	if( !is_missval(TYPE_IDLE_HOST, (void *)&(in_system_config->idle_host)) ) {
		global_system_config->idle_host = in_system_config->idle_host;
	}
	if( !is_missval(TYPE_MINIMUM_TOP, (void *)&(in_system_config->minimum_top)) ) {
		global_system_config->minimum_top = in_system_config->minimum_top;
	}
	if( !is_missval(TYPE_IMPROVMENT, (void *)&(in_system_config->improvment)) ) {
		global_system_config->improvment = in_system_config->improvment;
	}
	if( !is_missval(TYPE_STRATEGY, (void *)&(in_system_config->strategy)) ) {
		global_system_config->strategy = in_system_config->strategy;
	}
	if( !is_missval(TYPE_LOADPOLLING, (void *)&(in_system_config->loadpolling)) ) {
		global_system_config->loadpolling = in_system_config->loadpolling;
	}
	if( !is_missval(TYPE_STATISTICS, (void *)&(in_system_config->statistics)) ) {
		global_system_config->statistics = in_system_config->statistics;
	}

	return( write_all() );
}


int write_host_config(host_config *in_host_config)
{
	host_config_list *current_host;

	if( !is_open() ) {
		return( ERR_CFDB_NOT_OPEN );
	}
	
	if( is_missval(TYPE_HOST, (void *)in_host_config->name) ) {
		return( ERR_CFDB_NO_VALUE );
	}

	if( (current_host = host_list_get(in_host_config->name)) == NULL ) {
		current_host = (host_config_list *)malloc(sizeof(host_config_list));
		clear_host_config(&current_host->host_config);
		strcpy(current_host->host_config.name, in_host_config->name);
		host_list_insert(current_host);
	}


	if( !is_missval(TYPE_OS_NAME, (void *)&in_host_config->os_name) ) {
		strcpy(current_host->host_config.os_name, in_host_config->os_name);
	}
	if( !is_missval(TYPE_ALPHA, (void *)&in_host_config->alpha) ) {
		current_host->host_config.alpha = in_host_config->alpha;
	}
	if( !is_missval(TYPE_CHOOSE, (void *)&in_host_config->choose) ) {
		current_host->host_config.choose = in_host_config->choose;
	}
	if( !is_missval(TYPE_SYS1, (void *)&in_host_config->sys1) ) {
		current_host->host_config.sys1 = in_host_config->sys1;
	}
	if( !is_missval(TYPE_SYS2, (void *)&in_host_config->sys2) ) {
		current_host->host_config.sys2 = in_host_config->sys2;
	}
	if( !is_missval(TYPE_MAX_LONG, (void *)&in_host_config->max_long) ) {
		current_host->host_config.max_long = in_host_config->max_long;
	}
	if( !is_missval(TYPE_SWAP_SERVER, (void *)&in_host_config->swap_server) ) {
		strcpy(current_host->host_config.swap_server, in_host_config->swap_server);
	}
	if( !is_missval(TYPE_MACHINE, (void *)&in_host_config->machine) ) {
		strcpy(current_host->host_config.machine, in_host_config->machine);
	}

       	return( write_all() );
}
int read_system_config(system_config *out_system_config)
{
	if( !is_open() ) {
		return( ERR_CFDB_NOT_OPEN );
	}
	*out_system_config = *global_system_config;
	return( OK_CFDB );
}

int read_host_config(host_config *out_host_config, char *in_host_name)
{
	if( !is_open() ) {
		return( ERR_CFDB_NOT_OPEN );
	}
	
	if( in_host_name ) {
		global_current_host_list = global_host_list;
		while( global_current_host_list ) {
	if( strcasecmp(global_current_host_list->host_config.name, in_host_name) == 0 ) {
				*out_host_config = global_current_host_list->host_config;
				global_current_host_list = global_host_list;
				return( OK_CFDB );
			}
			global_current_host_list = global_current_host_list->rest_of_list;
		}
		global_current_host_list = global_host_list;
		return( ERR_CFDB_NO_HOST );
	}
	else {
		if( global_current_host_list ) {
			*out_host_config = global_current_host_list->host_config;
			global_current_host_list = global_current_host_list->rest_of_list;
			return( OK_CFDB );
		}
		else {
			global_current_host_list = global_host_list;
			return( ERR_CFDB_NO_HOST );
		}
	}
}
	
			  
			

int open_config(int *line_number)
{
	char path[MAX_PATH_LEN];
	int ret;
	FILE *config_fp;
fprintf(stdout,"Reached here\n");
fflush(stdout);
	if( is_open() ) {
		return( ERR_CFDB_IS_OPEN );
	}
	
	config_path(path);

	if( (config_fp = fopen(path, "r")) == NULL ) {
		return(ERR_CFDB_OPEN);
	}

	ret = read_all_config(config_fp, line_number);

	fclose(config_fp);

	return(ret);
}

int close_config(void)
{
	host_config_list *hlp;

	if( is_open() ) {
		free( global_system_config );
		global_system_config = NULL;
		while( global_host_list ) {
			hlp = global_host_list->rest_of_list;
			free(global_host_list);
			global_host_list = hlp;
		}
		global_host_list = NULL;
		global_current_host_list = global_host_list;
		return( OK_CFDB );
	}
	else {
		return( ERR_CFDB_NOT_OPEN );
	}
}

#if 0	  
	
static int is_digit(char c)
{
	if( c >= '0' && c <= '9' ) {
		return( TRUE );
	}
	else {
		return( FALSE );
	}
}

static int is_delimiter(int c)
{
	if( c == ' ' || c == '\n' || c == '\t' || c == EOF) {
		return( TRUE );
	}
	else {
		return( FALSE );
	}
}

static void skip_delimiters()
{
	int c;

	while( (c = fgetc(global_fp)) != EOF ) {
		if( !is_delimiter(c) ) {
			ungetc(c, global_fp);
			return;
		}
	}
}
	

static int parse_config
static int parse(FILE *fp)
{
	global_fp = fp;
	if( (res = scan()) != OK_CFDB ) {
		return(res);
	}

	return( parse_config() );
}

static int get_token()
{
	int i = 0;

	while( qqq_tab[i].name != NULL ) {
		if( strcmp(value, qqq_tab[i].name) == 0 ) {
			break;
		}
		i++;
	}
	
	return( qqq_tab[i].token );
}

static void scan(void)
{
	int c;
	int state = 0;
	int pos = 0;

	skip_delimiters();
	do {
		c = fgetc(global_fp);

		switch( state ) {
		      case 0:
			switch( c ) {
			      case EOF:
				token = TOK_EOF;
				return( OK_CFDB );
				break;
			      case '#':
				state = 1;
				break;
			      case '"':
				state = 2;
				break;
			      case '0'..'9':
				value[pos++] = (char)c;
				state = 3;
				break;
			      case 'a'..'z', 'A'..'Z':
				value[pos++] = (char)c;
				state = 6;
				break;
			      case '=':
				token = TOK_ASSIGN;
				return( OK_CFDB );
				break;
			      default:
				return( ERR_CFDB_SCAN );
				break;
			}

		      case 1:
			if( c == '\n'  || c == EOF) {
				token = TOK_COMMENT;
				return( OK_CFDB );
			}

		      case 2:
			if( c == '"' ) {
				token = TOK_STRING;
				value[pos] = '\0';
				return( OK_CFDB );
			}
			else {
				value[pos++] = (char)c;
			}
			break;

		      case 3:
			switch( c ) {
			      case '.':
				value[pos++] = (char)c;
				state = 4;
				break;
			      case '0'..'9':
				value[pos++] = (char)c;
				break;
			      default:
				if( is_delimiter(c) ) {
					value[pos] = '\0';
					token = TOK_INT;
					return( OK_CFDB );
				}
				else {
					return( ERR_CFDB_SCAN );
				}
				break;
			}
			break;

		      case 4:
			if( is_digit(c) ) {
				value[pos++] = (char)c;
				state = 5;
			}
			else {
				return( ERR_CFDB_SCAN );
			}
			break;

		      case 5:
			if( is_digit(c) ) {
				value[pos++] = (char)c;
			}
			else if( is_delimiter(c) ) {
				values[pos] = '\0';
				token = TOK_REAL;
				return( OK_CFDB );
			}
			else {
				return( ERR_CFDB_SCAN );
			}
			break;

		      case 6:
			if( is_delimiter(c) ) {
				value[pos] = '\0';
				token = get_token();
				if( token != TOK_UNKNOWN ) {
					return( OK_CFDB );
				}
				else {
					return( ERR_CFDB_SCAN );
				}
			}
			else {
				value[pos++] = (char)c;
			}
			break;
		}
	} while( c != EOF );
}
#endif				
		
	
