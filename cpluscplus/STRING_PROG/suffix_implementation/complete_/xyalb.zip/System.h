/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: system.h,v 1.5 1994/03/09 14:41:41 carlsson Exp $
 * $Log: system.h,v $
 * Revision 1.5  1994/03/09  14:41:41  carlsson
 * Added the availability "categories" HOST_DOWN, HOST_AVAIL, and
 * HOST_NOT_AVAIL.
 *
 * Revision 1.4  1993/12/20  08:47:02  carlsson
 * Removed all KEY_Specs... definitions.
 * Removed the definition of FILE
 * Changed LDAEMON_SERVER to DAEMON_SERVICE
 * Changed LMANAGER_SERVER to LOMA_SERVICE
 * Changed RMANAGER_SERVER to REMA_SERVICE
 * Added definition of NICE
 * Added the message types CONFIG_READ_HOST, CONFIG_READ_SYS, CONFIG_READ_REPLY, KILL_REQUEST and GET_FASTEST_HOST
 *
 * Revision 1.3  1993/12/15  10:04:05  carlsson
 * Moved the definitions of NORMAL_JOB and LONG_JOB to system.h.
 *
 * Revision 1.2  1993/12/06  14:47:18  stille
 * Changed timeout for load-polling second time :-)
 *
 * Revision 1.1  1993/12/06  14:44:08  stille
 * Changed timeout for load-polling
 *
 * Revision 1.0  1993/12/02  15:12:35  stille
 * Initial revision
 *
 * 
 */

#ifndef _SYSTEM_H
#define _SYSTEM_H
#include "sysdef.h"
#include <errno.h>


#ifdef WIN32  
	#include "win32.h"
        #include <stdlib.h>
	#include <stdio.h>
#endif

#ifdef LINUX
	#define  __KERNEL_STRICT_NAMES 
	#define __GNUC__ 2
	#undef __STRICT_ANSI__
	#include <linux/in.h>
	#include <netdb.h> /*10.12*/
	#define FAR 
	#define caddr_t __caddr_t
#endif

#ifdef SUNOS
	#include <signal.h>
	#include <netinet/in.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <sys/stat.h>
	#include <sys/syscall.h>
	#include <sys/wait.h>
	#include <sys/mman.h>
	#include <sys/un.h>
	#include <sys/param.h>
	#include <sys/socket.h>
	#include <sys/resource.h>
	#include <sys/ipc.h>
	#include <fcntl.h>
	#include <sys/types.h>
	#include <sys/time.h>
#endif

#ifdef UNIX
	#include <sys/mman.h>
	#include <sys/un.h>
	#include <netdb.h>
	#include <syslog.h>    
	#define UCHAR unsigned char 
	#define SOCKET  int  
#endif

/*
 * Message structure for load-poll
 */

typedef struct {
  int kind;                     /* Kind of message */
  int magic_number;             /* Magic number for authentication */
  union {
    struct {  int availability;                   /* Availability of host */
	      float loadfactor;                   /* Load index of host */
	    } load_info;
    struct {  int number_of_hosts;          /* Number of hosts requested
					     * from application resp. number
					     * of hosts returned from 
					     * load-manager */
	      /* Optional list of wanted hosts from application
	       * resp. list of returned from load-manager */
	      struct sockaddr_in list[MAXHOSTS]; 

	      float factor[MAXHOSTS];           /* Load index of host */
	      int avail[MAXHOSTS];              /* Availability of hosts */
	    } message;
    int errorcode;                              /* Error-code  */
    struct in_addr addr;
    int how;
  } data;

/* Possible values for the field `data.message.avail[]' */

#define HOST_DOWN -2           /* The host is down */
#define HOST_NOT_AVAIL -1      /* The host is not available */
#define HOST_AVAIL 0           /* The host is available */

#define data_avail        data.load_info.availability
#define data_load         data.load_info.loadfactor
#define data_factor       data.message.factor
#define data_number       data.message.number_of_hosts
#define data_hostlist     data.message.list
#define data_error        data.errorcode

} rpc_message;

/*
 * Structure for client authentication of rexec-manager
 */

/* Maximum number of groups a user can be in */
#define MAX_NUM_GROUPS          10


typedef struct {
  int kind;                      /* Kind of message */
  int magic_number;              /* Magic number of system */
  unsigned short port;                  /* Port given to rexec manager */
  int proc_nr;                   /* Process number given to rexec manager */
#ifdef WIN95
  SOCKET sock_nr;
#else
  int sock_nr;  /* Socket number on which the call was made */
#endif

#ifdef WIN32
  PSID ruid; 
PSID rgid;
/*BYTE rgid[LUSIZE];               /* Real user id */
/*BYTE rgid[LUSIZE];       /* Real group id */       
 
#endif
#ifdef UNIX
   unsigned short euid;                  /* Effective user id */
  unsigned short egid;                  /* Effective group id */
   unsigned short ruid;                  /*Real user id */
  unsigned short rgid;                  /* Real group id */
   int ngroups;                   /* Number of groups */
  int groups[MAX_NUM_GROUPS];    /* Groups the user is in */
#endif

} auth_request;


/*
 * Structure for reply of loaddaemon to above request
 */

typedef struct {
int kind;                         /* Kind of message */
int magic_number;                 /* Magic number of system */
int ok;                           /* Authentication ok? */
} auth_reply;

/*
 * Structure for request to read configuration file
 */

#if 0

/* XXX: not used. */

typedef struct {
	int kind;
	int magic_number;
	struct hostent host_ent;
} config_read_request;

/*
 * Structure for reply to above request
 */

typedef struct {
	int kind;
	int magic_number;
} config_read_reply;


typedef struct {
	int kind;
	int magic_number;
	int how;                    /* How to end (not used) */
} kill_request;

#endif

#ifdef WIN32
/*char optarg[5][MAX_PATH_LEN];*/
int optind; 
#endif
#endif /*_SYSTEM_H*/

