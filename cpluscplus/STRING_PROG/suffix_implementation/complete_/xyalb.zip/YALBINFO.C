/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson,  Martin Loitz
 *
 * Institute of Operating Systems and Computer Networks
 * Technical University Braunschweig, Germany
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright notice
 * appears in all copies.  The Technical University of
 * Braunschweig makes no representations about the suitability
 * of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */

#include  "sysdef.h"
#include <stdio.h>

/***Modified*****
#include <yalb/lobalib.h>
#include <yalb/rexecbib.h>
**********************/
#ifdef LINUX
#include <socketbits.h>
#include <netdb.h>
#endif
#include "yalbinfo.h"
#include "rexecbib.h"

/* #define DEBUG */
#ifdef SUNOS
	#include <rpcsvc/rstat.h>   /**eqvt??**/
	#include <rpc/rpc.h>   /* for xdr_void */ /**eqvt??**/
#endif
#ifdef LINUX
	#include <rpcsvc/rstat.h>   /**eqvt??**/
	#include <rpc/rpc.h>   /* for xdr_void */ /**eqvt??**/
#endif
typedef struct loadtype {
	char   host[50];
	float  sload;
	float  avnrn0, avnrn1, avnrn2;
	int    pollrank;  /* Rank in receiving answer for broadcast.  */
	int    Y_pos;
	int    avail;
} load;

static load loadtab[MAXHOSTS];


#ifdef UNIX
static struct statstime statbuf;
#endif

static reply   get;

static char avenrun = 0;
static char rexc =  0;


/* Compare function for qsort ().  */
static int compare (l1, l2)
load *l1, *l2;
{
  float res;

  return (res = l1->sload - l2->sload) == 0 ? 0 :
    (res > 0 ? 1 : -1 );
}


#ifdef AVENRUN

/* Routine for receiving broadcast answers.  */
static bool_t results (resultsp, raddr)
caddr_t resultsp;
struct sockaddr_in *raddr;  /* Address of responding server.  */
{
  static int received = 0;
  char *hostname;
  struct hostent *host;
  int i;
#ifdef WIN32
  WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif

	
  host = gethostbyaddr ((char *)&raddr->sin_addr,
			    sizeof(raddr->sin_addr), AF_INET);
  if (!host)
    {
	    /* Unknown address. */
#ifdef DEBUG
	    puts ("Receiving unknown host");
#endif
	    return FALSE;
   }

  hostname = host->h_name;

#ifdef DEBUG
  printf ("Receiving %-8s", hostname);
#endif

  for (i = 0; i < get.number ; i++)
    if ( !strcmp (loadtab[i].host, hostname))
      {
	/* If we already received a value from this host,
	   we take this as timeout for the others.  */
	if (loadtab[i].pollrank)
	  {
	    puts ("** Avenrun Timeout **\n");
	    return TRUE;
	  }

	loadtab[i].pollrank = ++received;

#ifdef WIN32
	//
#endif
#ifdef UNIX
	loadtab[i].avnrn0 = (statbuf.avenrun [0]) / 256.0;
	loadtab[i].avnrn1 = (statbuf.avenrun [1]) / 256.0;
	loadtab[i].avnrn2 = (statbuf.avenrun [2]) / 256.0;
#endif


	break;
      }

#ifdef DEBUG
  if (i == get.number)   puts (" - not found");
  else printf (" - found (Rank %2d)\n", received);
#endif

  if (received == get.number)
    /* We got all the answers we wanted.  */
    return TRUE;

  /* Tell `clnt_broadcast' that we want more answers.  */
  return FALSE;
}

#endif

static void
get_top ()
{
  struct hostent *name;
#ifdef WIN32
  WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    	return;
	}
#endif

	
  name = gethostbyaddr((char *)&get.hostlist[0].sin_addr,
		       sizeof(get.hostlist[0].sin_addr), AF_INET);
  printf("YALB top-host: %s\n", name->h_name);
}


static void
get_all (argc, argv)
int argc;
char **argv;
{
  struct hostent *name;
  enum clnt_stat clnt_stat;

  int i;
#ifdef WIN32
  WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif
	
  /* Copy loaddata into `loadtab' structure.  */
  for (i = 0; i < get.number; i++)
    {
      /* Get YALB Index. */
      name = gethostbyaddr ((char *)&get.hostlist[i].sin_addr,
			    sizeof(get.hostlist[i].sin_addr), AF_INET);
      strcpy (loadtab[i].host, name->h_name);

#ifdef DEBUG
      printf ("Availability %-11s: %d\n", loadtab[i].host, get.avail[i]);
#endif

      loadtab[i].avail = get.avail[i];
	  
      if (get.avail[i] == HOST_NOT_AVAIL)
	loadtab[i].sload = 9998;   /* just for the sorting.  */
      else if (get.avail[i] == HOST_DOWN)
	loadtab[i].sload = 9999;
      else
	loadtab[i].sload = get.load[i];

      /* Set all polling rank values to 0 (= no values received).  */
      loadtab[i].pollrank = 0;

      loadtab[i].Y_pos = i;

#ifdef DEBUG
      printf ("%3d.  %-11s %9.6f\n",
	      i+1, loadtab[i].host, loadtab[i].sload);
#endif
    }

#ifdef AVENRUN
  if (avenrun)
    {
      /* Broadcast to get Avenrun from all hosts.  */
      clnt_stat = clnt_broadcast (100001, 3, RSTATPROC_STATS,
				  xdr_void, NULL, xdr_statstime, &statbuf, results);
      
#ifdef DEBUG
      puts ("Broadcast finished.");
#endif
      if (clnt_stat)
	if (clnt_stat == RPC_TIMEDOUT)
	  puts ("    *** Timeout -- sorry you had to wait so long\n");
	else
	  printf ("    *** Unknown broadcast error %d\n", clnt_stat);
    }
#endif  /* AVENRUN */

  /* Sort loadtab structure.  */
  qsort (loadtab, get.number, sizeof(load), compare);
      
  /* Print list.  */
  printf ("Rank  Host        				YALB Index");

#ifdef AVENRUN
  if (avenrun)
    printf ("        Avenrun        Polling");
#endif

  if (rexc)
    printf ("  Rexec");

  putchar ('\n');


  /*** Print index list **********************************************/

  for (i = 0; i < get.number; i++)
    {
      printf ("%3d.  %-40s", i+1, loadtab[i].host);

      /* Print YALB Index.  */

      if (get.avail[loadtab[i].Y_pos] == HOST_AVAIL)
	printf (" %8.3f", loadtab[i].sload);
      else if (get.avail[loadtab[i].Y_pos] == HOST_DOWN)
	/* Host is down.  */
	printf ("    DOWN ");
      else
	/* Index is not available.  */
	printf ("     NA  ");

#ifdef AVENRUN
      if (avenrun)
	/* Print Avenrun.  */
	if (loadtab[i].pollrank)
	  printf("   %6.3f %6.3f %6.3f    %2d ",
		 loadtab[i].avnrn0, loadtab[i].avnrn1, loadtab[i].avnrn2,
		 loadtab[i].pollrank);
	else
	  printf ("      NA     NA     NA     NA ");
#endif

      if (rexc)
	{
	  /* Execute command on remote hosts.  */
	      
	  int exec_pid;

	  printf ("    ");  fflush (stdout);

	  if (argc > 2+avenrun)
	    /* Execute specified command.  */
	    exec_pid = rexecv (argv[avenrun+2], &argv[avenrun+3],
			       (char *)&get.hostlist[loadtab[i].Y_pos], NORMAL_JOB);
	  else {
	    /* Execute command `hostname'.  */
	    char *args[2];

	    args[0] = (char *) malloc (strlen("hostname")+1);
	    strcpy (args[0], "hostname");
	    args[1] = (char *)0;

	    exec_pid = rexecv (args[0], &args[1],
			       (char *)&get.hostlist[loadtab[i].Y_pos], NORMAL_JOB);
	  }

	  /* Remote execution successful?  */
	  if (exec_pid < 0)
	    if (exec_pid == COULD_NOT_CONNECT)
	      printf ("Error: Could not connect\n");
	    else if (exec_pid == CONNECTION_CLOSED)
	      printf ("Error: Connection closed\n");
	    else
	      printf ("Rexec error: %d\n", exec_pid);

	  /* Remote job is executing, wait until it's finished.  */

	  if (rexec_wait () == 1)
	    {
	      exit_state exit_status;

	      while (get_exit_status (&exit_status) != 0)
		{

#ifdef DEBUG
		  printf ("Job # %d terminated. Kind: %s | exit-status: INT: %d - EXT: %d\n",
			  exit_status.job,
			  (exit_status.kind==0)?"INTERNAL":"EXTERNAL",
			  exit_status.data.errorcode,
			  exit_status.data.state.w_T.w_Retcode);
#endif

		  if (exit_status.kind == 0)
		    printf ("Internal rexec error %d\n", exit_status.data.errorcode);
		 /*changed on 9.8.99 if (exit_status.data.state.w_T.w_Retcode != 0)
		    printf ("External rexec error %d\n",
			    exit_status.data.state.w_T.w_Retcode);*/
		 if (exit_status.data.state != 0)
		    printf ("External rexec error %d\n",
			    exit_status.data.state);
		}
	    }
	}  /* if (rexc) */
      else
	putchar ('\n');
    }
}


#ifdef WIN32
void main (int argc, char **argv,char **envp)
#endif
#ifdef UNIX
main (argc, argv)
int argc;
char **argv;
#endif
{
  request want;
  int rval, dur;
#ifdef WIN32
  	time_t ltime;
  struct tm  *btp, *etp;
#endif
#ifdef UNIX
  struct timeval btp, etp;
#endif

  /* Type of request.  */
  want.kind = GET_ALL;
  want.hostlist[0] = (struct sockaddr_in *)0;

  /* Parse arguments.  */

  if (argc > 1)
    if ((argc == 2) && !strcmp (argv[1], "top"))
      {
	want.kind = GET_TOP;
	want.number = 1;  /* nur bei GET_TOP, immer 1 */
      }

    else if ((argc == 2) && !strcmp (argv[1], "-a"))
      avenrun++;

    else if ( !strcmp (argv[1], "-r"))
      rexc++;

    else if ((argc > 2) && !strcmp (argv[1], "-a") && !strcmp (argv[2], "-r"))
      {
	avenrun++;
	rexc++;
      }
    else
      {
	/* Wrong usage.  */
	puts ("Usage: yalbinfo [ -a ] [ -r [ <command> ] ]");
	puts ("       yalbinfo top");
	return 1;
      }

  /* Initialization for YALB Index.  */
  request_init ();

  if (rexc)
    /* Initialization of YALB Rexec.  */
    rexec_init (PARALLEL);

  /* Measure duration to get index.  */
  #ifdef WIN32
		time(&ltime);
		btp=gmtime(&ltime);
#endif
#ifdef UNIX
  gettimeofday (&btp, (struct timezone *)0);
#endif

  /* Get YALB Index.  */
  rval = get_hosts (&want, &get);

 #ifdef WIN32
		time(&ltime);
		etp=gmtime(&ltime);
		 /* Calculate duration. */

  dur = (etp->tm_sec - btp->tm_sec)*1000 /* + (etp->tm_usec - btp->tm_usec)/1000 */ ;

#endif
#ifdef UNIX
		gettimeofday (&etp, (struct timezone *)0);
		 /* Calculate duration. */

  dur = (etp.tv_sec - btp.tv_sec)*1000 + (etp.tv_usec - btp.tv_usec)/1000;

#endif

 
  /* printf ("  Kind of request: %s\n", want.kind==GET_TOP?"GET_TOP":"GET_ALL"); */
  /* printf ("  Number of hosts: %d\n", get.number); */

#ifdef IBR
    printf ("[Request duration: %d ms]\n", dur);
#endif
  if (rval)
    {
#ifdef IBR
      printf ("[Return value: %d]\n", rval);
#endif
      puts ("Sorry, YALB Index is not available.");

      /* Reset load system.  */
      reset_system ();
      exit (1);
    }

  /* Fetch and print request values.  */
  if (want.kind == GET_ALL)
    get_all (argc, argv);
  else
    get_top ();


  /* Reset load system.  */
  reset_system();

  if (rexc)
    rexec_close ();   /* Exit from rexec system.  */

  return 0;
}
