/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*SERVICE.C
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE. 
// 
// Copyright 1993 - 1998 Microsoft Corporation.  All Rights Reserved. 
// 
//  MODULE:   service.c 
// 
//  PURPOSE:  Implements functions required by all services 
//            windows. 
// 
//  FUNCTIONS: 
//    main(int argc, char **argv); 
//    service_ctrl(DWORD dwCtrlCode); 
//    service_main(DWORD dwArgc, LPTSTR *lpszArgv); 
//    CmdInstallService(); 
//    CmdRemoveService(); 
//    CmdDebugService(int argc, char **argv); 
//    ControlHandler ( DWORD dwCtrlType ); 
//    GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize ); 
// 
//  COMMENTS: 
// 
//  AUTHOR: Craig Link - Microsoft Developer Support 
*/ 


#include "system.h"

#ifdef WIN32 
#include <windows.h> 

#include <stdio.h> 
#include <stdlib.h> 
#include <process.h> 
#include <tchar.h> 
 
#include "lmanager.h" 
 

#ifdef WIN95 
#include <tlhelp32.h>
#define SERVICE_KEY "Software\\Microsoft\\Windows\\CurrentVersion\\RunServices" 
#endif
		
 
// internal variables 
SERVICE_STATUS          ssStatus;       // current status of the service 
SERVICE_STATUS_HANDLE   sshStatusHandle; 
DWORD                   dwErr = 0; 
BOOL                    bDebug = FALSE; 
TCHAR                   szErr[256]; 
 
// internal function prototypes 
VOID WINAPI service_ctrl(DWORD dwCtrlCode); 
VOID WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv); 
VOID CmdInstallService(); 
VOID CmdRemoveService(); 
VOID CmdDebugService(int argc, char **argv); 
BOOL WINAPI ControlHandler ( DWORD dwCtrlType ); 
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize ); 
const char *CmdLine=".\\lmanager -debug"; 
// 
//  FUNCTION: main 
// 
//  PURPOSE: entrypoint for service 
// 
//  PARAMETERS: 
//    argc - number of command line arguments 
//    argv - array of command line arguments 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
//    main() either performs the command line task, or 
//    call StartServiceCtrlDispatcher to register the 
//    main service thread.  When the this call returns, 
//    the service has stopped, so exit. 
// 
void _CRTAPI1 main(int argc, char **argv) 
{ 
    SERVICE_TABLE_ENTRY dispatchTable[] = 
    { 
        { TEXT(SZSERVICENAME), (LPSERVICE_MAIN_FUNCTION)service_main }, 
        { NULL, NULL } 
    }; 
 
    if ( (argc > 1) && 
         ((*argv[1] == '-') || (*argv[1] == '/')) ) 
    { 
        if ( _stricmp( "install", argv[1]+1 ) == 0 ) 
        { 
            CmdInstallService(); 
        } 
        else if ( _stricmp( "remove", argv[1]+1 ) == 0 ) 
        { 
            CmdRemoveService(); 
        } 
        else if ( _stricmp( "debug", argv[1]+1 ) == 0 ) 
        { 
            bDebug = TRUE; 
            CmdDebugService(argc, argv); 
        } 
        else 
        { 
            goto dispatch;
			/*bDebug = TRUE; 
            CmdDebugService(argc, argv);*/
        } 
        exit(0); 
    } 
 
    // if it doesn't match any of the above parameters 
    // the service control manager may be starting the service 
    // so we must call StartServiceCtrlDispatcher 
    dispatch: 
        // this is just to be friendly 
        printf( "%s -install          to install the service\n", SZAPPNAME ); 
        printf( "%s -remove           to remove the service\n", SZAPPNAME ); 
        printf( "%s -debug <params>   to run as a console app for debugging\n", SZAPPNAME ); 
        printf( "\nStartServiceCtrlDispatcher being called.\n" ); 
        printf( "This may take several seconds.  Please wait.\n" ); 
 
        if (!StartServiceCtrlDispatcher(dispatchTable)) 
            AddToMessageLog(TEXT("StartServiceCtrlDispatcher failed.")); 
} 
 
 
 
// 
//  FUNCTION: service_main 
// 
//  PURPOSE: To perform actual initialization of the service 
// 
//  PARAMETERS: 
//    dwArgc   - number of command line arguments 
//    lpszArgv - array of command line arguments 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
//    This routine performs the service initialization and then calls 
//    the user defined ServiceStart() routine to perform majority 
//    of the work. 
// 
void WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv) 
{ 
 
    // register our service control handler: 
    // 
    sshStatusHandle = RegisterServiceCtrlHandler( TEXT(SZSERVICENAME), service_ctrl); 
 
    if (!sshStatusHandle) 
        goto cleanup; 
 
    // SERVICE_STATUS members that don't change in example 
    // 
    ssStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS; 
    ssStatus.dwServiceSpecificExitCode = 0; 
 
 
    // report the status to the service control manager. 
    // 
    if (!ReportStatusToSCMgr( 
        SERVICE_START_PENDING, // service state 
        NO_ERROR,              // exit code 
        3000))                 // wait hint 
        goto cleanup; 
 
 
    ServiceStart( dwArgc, lpszArgv ); 
 
cleanup: 
 
    // try to report the stopped status to the service control manager. 
    // 
    if (sshStatusHandle) 
        (VOID)ReportStatusToSCMgr( 
                            SERVICE_STOPPED, 
                            dwErr, 
                            0); 
 
    return; 
} 
 
 
 
// 
//  FUNCTION: service_ctrl 
// 
//  PURPOSE: This function is called by the SCM whenever 
//           ControlService() is called on this service. 
// 
//  PARAMETERS: 
//    dwCtrlCode - type of control requested 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
// 
VOID WINAPI service_ctrl(DWORD dwCtrlCode) 
{ 
    // Handle the requested control code. 
    // 
    switch(dwCtrlCode) 
    { 
        // Stop the service. 
        // 
        // SERVICE_STOP_PENDING should be reported before 
        // setting the Stop Event - hServerStopEvent - in 
        // ServiceStop().  This avoids a race condition 
        // which may result in a 1053 - The Service did not respond... 
        // error. 
        case SERVICE_CONTROL_STOP: 
            ReportStatusToSCMgr(SERVICE_STOP_PENDING, NO_ERROR, 0); 
            ServiceStop(); 
            return; 
 
        // Update the service status. 
        // 
        case SERVICE_CONTROL_INTERROGATE: 
            break; 
 
        // invalid control code 
        // 
        default: 
            break; 
 
    } 
 
    ReportStatusToSCMgr(ssStatus.dwCurrentState, NO_ERROR, 0); 
} 
 
 
 
// 
//  FUNCTION: ReportStatusToSCMgr() 
// 
//  PURPOSE: Sets the current status of the service and 
//           reports it to the Service Control Manager 
// 
//  PARAMETERS: 
//    dwCurrentState - the state of the service 
//    dwWin32ExitCode - error code to report 
//    dwWaitHint - worst case estimate to next checkpoint 
// 
//  RETURN VALUE: 
//    TRUE  - success 
//    FALSE - failure 
// 
//  COMMENTS: 
// 
BOOL ReportStatusToSCMgr(DWORD dwCurrentState, 
                         DWORD dwWin32ExitCode, 
                         DWORD dwWaitHint) 
{ 
    static DWORD dwCheckPoint = 1; 
    BOOL fResult = TRUE; 
 
 
    if ( !bDebug ) // when debugging we don't report to the SCM 
    { 
        if (dwCurrentState == SERVICE_START_PENDING) 
            ssStatus.dwControlsAccepted = 0; 
        else 
            ssStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP; 
 
        ssStatus.dwCurrentState = dwCurrentState; 
        ssStatus.dwWin32ExitCode = dwWin32ExitCode; 
        ssStatus.dwWaitHint = dwWaitHint; 
 
        if ( ( dwCurrentState == SERVICE_RUNNING ) || 
             ( dwCurrentState == SERVICE_STOPPED ) ) 
            ssStatus.dwCheckPoint = 0; 
        else 
            ssStatus.dwCheckPoint = dwCheckPoint++; 
 
 
        // Report the status of the service to the service control manager. 
        // 
        if (!(fResult = SetServiceStatus( sshStatusHandle, &ssStatus))) { 
            AddToMessageLog(TEXT("SetServiceStatus")); 
        } 
    } 
    return fResult; 
} 
 
 
 
// 
//  FUNCTION: AddToMessageLog(LPTSTR lpszMsg) 
// 
//  PURPOSE: Allows any thread to log an error message 
// 
//  PARAMETERS: 
//    lpszMsg - text for message 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
// 
VOID AddToMessageLog(LPTSTR lpszMsg) 
{ 
    TCHAR   szMsg[256]; 
    HANDLE  hEventSource; 
    LPTSTR  lpszStrings[2]; 
 
 
    if ( !bDebug ) 
    { 
        dwErr = GetLastError(); 
 
        // Use event logging to log the error. 
        // 
        hEventSource = RegisterEventSource(NULL, TEXT(SZSERVICENAME)); 
 
        _stprintf(szMsg, TEXT("%s error: %d"), TEXT(SZSERVICENAME), dwErr); 
        lpszStrings[0] = szMsg; 
        lpszStrings[1] = lpszMsg; 
 
        if (hEventSource != NULL) { 
            ReportEvent(hEventSource, // handle of event source 
                EVENTLOG_ERROR_TYPE,  // event type 
                0,                    // event category 
                0,                    // event ID 
                NULL,                 // current user's SID 
                2,                    // strings in lpszStrings 
                0,                    // no bytes of raw data 
                lpszStrings,          // array of error strings 
                NULL);                // no raw data 
 
            (VOID) DeregisterEventSource(hEventSource); 
        } 
    } 
} 
 
 
 
///////////////////////////////added on 10.11.99///////////////////
////////////// AddService() - install a Win95 "service ////////////

#ifdef WIN95

 
BOOL AddService(const char* Name, const char *CmdLine) 
    { 
    HKEY    hKey; 
    LONG    Status; 
    BOOL    Result  = FALSE;    /* assume failure           */ 
 
    Status = RegCreateKey(HKEY_LOCAL_MACHINE, SERVICE_KEY, &hKey); 
 
    if(ERROR_SUCCESS == Status) 
        { 
        Status  = RegSetValueEx(hKey, Name, 0, REG_SZ, 
                    (CONST BYTE*)CmdLine, strlen(CmdLine)+1); 
        if(ERROR_SUCCESS == Status) 
            Result  = TRUE; 
        RegCloseKey(hKey); 
        } 
 
    return Result; 
    } 
 
 
/////////// StartWin95Service() - start .exe with no window, specific priority //////
 
 
#define NUM_ATTEMPTS_EXISTS     20 
#define SLEEP_TIME              500 
 
DWORD StartWin95Service(char* file_name) 
    { 
    PROCESS_INFORMATION piProcInfo; 
    STARTUPINFO         siStartInfo; 
    DWORD               dwPriority; 
    DWORD               dwResult = (DWORD)-1; 
    int                 ii; 
 
    /* Set priority */ 
   dwPriority = NORMAL_PRIORITY_CLASS; 
 
    /* Now create the child process.                    * 
     * Set up members of STARTUPINFO structure.         */ 
 
    siStartInfo.cb          = sizeof(STARTUPINFO); 
    siStartInfo.lpReserved  = NULL; 
    siStartInfo.lpReserved2 = NULL; 
    siStartInfo.cbReserved2 = 0; 
    siStartInfo.lpDesktop   = NULL; 
    siStartInfo.dwFlags     = STARTF_USESHOWWINDOW; 
 
    /* Create the process   */ 
    if(FALSE == CreateProcess(file_name, 
        NULL,                 // command line 
        NULL,                 // process security attributes 
        NULL,                 // primary thread security attributes 
        FALSE,                // handles are inherited 
        DETACHED_PROCESS | dwPriority, // creation flags 
        NULL,                 // use parent's environment 
        NULL,                 // use parent's current directory 
        &siStartInfo,         // STARTUPINFO pointer 
        &piProcInfo))         // receives PROCESS_INFORMATION 
        { 
        return -1; 
        } 
    else 
        { 
        /* Check if process has been started    */ 
        for(ii = 0; ii < NUM_ATTEMPTS_EXISTS; ii++) 
            { 
            GetExitCodeProcess(piProcInfo.hProcess, &dwResult); 
            if(dwResult == STILL_ACTIVE) 
                break; 
            else 
                Sleep(SLEEP_TIME); 
            } 
        if(dwResult == STILL_ACTIVE) 
            { 
             /* Set priority. 
              * For console apps dwCreationFlags in CreateProcess 
              * doesn't work so we need to do this again 
              * We might want to sleep here if the process sets its 
              * priority by itself  and we want to change it 
 
              */ 
            Sleep(2000); 
            SetPriorityClass(piProcInfo.hProcess, dwPriority); 
            dwResult = piProcInfo.dwProcessId; 
            } 
        else 
            dwResult    = (DWORD)-1; 
        } 
    return dwResult; 
    } 
 
 
/* RegisterService() - mark a process as a Win95 "service" 
 */ 
BOOL RegisterService (DWORD AppProcessId) 
    { 
    BOOL    Result  = FALSE;        /* assume failure */ 
    int     nstat; 
    HMODULE hKernelLib; 
    typedef DWORD (WINAPI*ExRegSrvProc) (DWORD dwProcessId, DWORD dwType); 
    ExRegSrvProc RegSrvProc; 
 
    hKernelLib = GetModuleHandle("KERNEL32.DLL"); 
    if(NULL != hKernelLib) 
        { 
        RegSrvProc = (ExRegSrvProc)GetProcAddress(hKernelLib, 
                     "RegisterServiceProcess"); 
        if(NULL != RegSrvProc) 
            { 
            /* 0x00000001 == RSP_SIMPLE_SERVICE */ 
            nstat = RegSrvProc(AppProcessId, 0x00000001); 
            if(1 == nstat) 
                Result  = TRUE; 
            } 
        } 
    return Result; 
    } 
 
 
 
/*
    if(argv[1][1] == 's') 
        { 
        
        dwProcID = StartWin95Service(argv[2]); 
        RegisterService(dwProcID); 
        } 
 
  */ 

void CmdRemoveService() 
 { 
	DWORD           dwProcID; 
    HANDLE          hProcess, hProcessSnap, hModuleSnap; 
    PROCESSENTRY32  pe32; 
    MODULEENTRY32   me32; 
    BOOL            bModuleFound = FALSE; 
 
    //    strupr(argv[2]); 
        /* Take snapshot of all processes currently in the system   */ 
        hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0); 
        pe32.dwSize = sizeof(PROCESSENTRY32); 
        if (Process32First(hProcessSnap, &pe32)) 
 
            { 
            do  { 
                hModuleSnap = CreateToolhelp32Snapshot( 
                             TH32CS_SNAPMODULE, pe32.th32ProcessID); 
                me32.dwSize = sizeof(MODULEENTRY32); 
                Module32First(hModuleSnap, &me32); 
                do { 
                    if(strcmp(me32.szExePath, SZSERVICENAME) == 0) 
                        { 
                        bModuleFound = TRUE; 
                        break; 
                        } 
                   } 
                   while (Module32Next(hModuleSnap, &me32)); 
                CloseHandle (hModuleSnap); 
                if(bModuleFound) 
                    break; 
                } 
                while (Process32Next(hProcessSnap, &pe32)); 
            } 
        CloseHandle (hModuleSnap); 
 
        if(bModuleFound) 
            { 
            hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, 
                                 pe32.th32ProcessID); 
            TerminateProcess(hProcess, -1); 
            printf("Process terminated"); 
            } 
        else 
            printf("Process not found"); 
} 
 
#endif
 
 
 
/////////////////////////////////////////////////////////////////// 
// 
//  The following code handles service installation and removal 
// 
 
 
// 
//  FUNCTION: CmdInstallService() 
// 
//  PURPOSE: Installs the service 
// 
//  PARAMETERS: 
//    none 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
// 
void CmdInstallService() 
{ 
    SC_HANDLE   schService; 
    SC_HANDLE   schSCManager; 
 
    TCHAR szPath[512]; 
 
    if ( GetModuleFileName( NULL, szPath, 512 ) == 0 ) 
    { 
        _tprintf(TEXT("Unable to install %s - %s\n"), TEXT(SZSERVICEDISPLAYNAME), GetLastErrorText(szErr, 256)); 
        return; 
    } 
 #ifdef WIN95
	if (AddService(SZSERVICENAME,CmdLine)==TRUE)
		 { 
            _tprintf(TEXT("%s installed.\n"), TEXT(SZSERVICEDISPLAYNAME) ); 
		}    
        else 
        { 
            _tprintf(TEXT("CreateService failed \n")); 
        } 
 
       
#else
    schSCManager = OpenSCManager( 
                        NULL,                   // machine (NULL == local) 
                        NULL,                   // database (NULL == default) 
                        SC_MANAGER_ALL_ACCESS   // access required 
                        ); 
    if ( schSCManager ) 
    { 
        schService = CreateService( 
            schSCManager,               // SCManager database 
            TEXT(SZSERVICENAME),        // name of service 
            TEXT(SZSERVICEDISPLAYNAME), // name to display 
            SERVICE_ALL_ACCESS,         // desired access 
            SERVICE_WIN32_OWN_PROCESS,  // service type 
            SERVICE_DEMAND_START,       // start type 
            SERVICE_ERROR_NORMAL,       // error control type 
            szPath,                     // service's binary 
            NULL,                       // no load ordering group 
            NULL,                       // no tag identifier 
            TEXT(SZDEPENDENCIES),       // dependencies 
            NULL,                       // LocalSystem account 
            NULL);                      // no password 
 
        if ( schService ) 
        { 
            _tprintf(TEXT("%s installed.\n"), TEXT(SZSERVICEDISPLAYNAME) ); 
            CloseServiceHandle(schService); 
        } 
        else 
        { 
            _tprintf(TEXT("CreateService failed - %s\n"), GetLastErrorText(szErr, 256)); 
        } 
 
        CloseServiceHandle(schSCManager); 
    } 
    else 
        _tprintf(TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256)); 
#endif
} 
 
 
#ifdef WINNT
 
// 
//  FUNCTION: CmdRemoveService() 
// 
//  PURPOSE: Stops and removes the service 
// 
//  PARAMETERS: 
//    none 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
// 
void CmdRemoveService() 
{ 
    SC_HANDLE   schService; 
    SC_HANDLE   schSCManager; 
 
    schSCManager = OpenSCManager( 
                        NULL,                   // machine (NULL == local) 
                        NULL,                   // database (NULL == default) 
                        SC_MANAGER_ALL_ACCESS   // access required 
                        ); 
    if ( schSCManager ) 
    { 
        schService = OpenService(schSCManager, TEXT(SZSERVICENAME), SERVICE_ALL_ACCESS); 
 
        if (schService) 
        { 
            // try to stop the service 
            if ( ControlService( schService, SERVICE_CONTROL_STOP, &ssStatus ) ) 
            { 
                _tprintf(TEXT("Stopping %s."), TEXT(SZSERVICEDISPLAYNAME)); 
                Sleep( 1000 ); 
 
                while( QueryServiceStatus( schService, &ssStatus ) ) 
                { 
                    if ( ssStatus.dwCurrentState == SERVICE_STOP_PENDING ) 
                    { 
                        _tprintf(TEXT(".")); 
                        Sleep( 1000 ); 
                    } 
                    else 
                        break; 
                } 
 
                if ( ssStatus.dwCurrentState == SERVICE_STOPPED ) 
                    _tprintf(TEXT("\n%s stopped.\n"), TEXT(SZSERVICEDISPLAYNAME) ); 
                else 
                    _tprintf(TEXT("\n%s failed to stop.\n"), TEXT(SZSERVICEDISPLAYNAME) ); 
 
            } 
 
            // now remove the service 
            if( DeleteService(schService) ) 
                _tprintf(TEXT("%s removed.\n"), TEXT(SZSERVICEDISPLAYNAME) ); 
            else 
                _tprintf(TEXT("DeleteService failed - %s\n"), GetLastErrorText(szErr,256)); 
 
 
            CloseServiceHandle(schService); 
        } 
        else 
            _tprintf(TEXT("OpenService failed - %s\n"), GetLastErrorText(szErr,256)); 
 
        CloseServiceHandle(schSCManager); 
    } 
    else 
        _tprintf(TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256)); 
} 
 
 #endif
 
 
 
/////////////////////////////////////////////////////////////////// 
// 
//  The following code is for running the service as a console app 
// 
 
 
// 
//  FUNCTION: CmdDebugService(int argc, char ** argv) 
// 
//  PURPOSE: Runs the service as a console application 
// 
//  PARAMETERS: 
//    argc - number of command line arguments 
//    argv - array of command line arguments 
// 
//  RETURN VALUE: 
//    none 
// 
//  COMMENTS: 
// 
void CmdDebugService(int argc, char ** argv) 
{ 
    DWORD dwArgc; 
    LPTSTR *lpszArgv; 
 
#ifdef UNICODE 
    lpszArgv = CommandLineToArgvW(GetCommandLineW(), &(dwArgc) ); 
#else 
    dwArgc   = (DWORD) argc; 
    lpszArgv = argv; 
#endif 
 
    _tprintf(TEXT("Debugging %s.\n"), TEXT(SZSERVICEDISPLAYNAME)); 
 
    SetConsoleCtrlHandler( ControlHandler, TRUE ); 
 
    ServiceStart( dwArgc, lpszArgv ); 
} 
 
 
// 
//  FUNCTION: ControlHandler ( DWORD dwCtrlType ) 
// 
//  PURPOSE: Handled console control events 
// 
//  PARAMETERS: 
//    dwCtrlType - type of control event 
// 
//  RETURN VALUE: 
//    True - handled 
//    False - unhandled 
// 
//  COMMENTS: 
// 
BOOL WINAPI ControlHandler ( DWORD dwCtrlType ) 
{ 
    switch( dwCtrlType ) 
    { 
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate 
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode 
            _tprintf(TEXT("Stopping %s.\n"), TEXT(SZSERVICEDISPLAYNAME)); 
            ServiceStop(); 
            return TRUE; 
            break; 
 
    } 
    return FALSE; 
} 
 
// 
//  FUNCTION: GetLastErrorText 
// 
//  PURPOSE: copies error message text to string 
// 
//  PARAMETERS: 
//    lpszBuf - destination buffer 
//    dwSize - size of buffer 
// 
//  RETURN VALUE: 
//    destination buffer 
// 
//  COMMENTS: 
// 
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize ) 
{ 
    DWORD dwRet; 
    LPTSTR lpszTemp = NULL; 
 
    dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY, 
                           NULL, 
                           GetLastError(), 
                           LANG_NEUTRAL, 
                           (LPTSTR)&lpszTemp, 
                           0, 
                           NULL ); 
 
    // supplied buffer is not long enough 
    if ( !dwRet || ( (long)dwSize < (long)dwRet+14 ) ) 
        lpszBuf[0] = TEXT('\0'); 
    else 
    { 
        lpszTemp[lstrlen(lpszTemp)-2] = TEXT('\0');  //remove cr and newline character 
        _stprintf( lpszBuf, TEXT("%s (0x%x)"), lpszTemp, GetLastError() ); 
    } 
 
    if ( lpszTemp ) 
        LocalFree((HLOCAL) lpszTemp ); 
 
    return lpszBuf; 
} 

#endif /*WIN32*/
