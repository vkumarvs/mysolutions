/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: lobalib.h,v 1.1 1993/12/15 08:17:00 carlsson Exp $
 * $Log: lobalib.h,v $
 * Revision 1.1  1993/12/15  08:17:00  carlsson
 * Added a new kind of request (GET_FASTEST).
 *
 * Revision 1.0  1993/12/02  15:11:06  stille
 * Initial revision
 */

/*
 * Library for the loadbalancing system, used by the requesting application
 */

/*#include "system.h"*/
#ifdef LINUX
#include <stdio.h>
#include <netinet/in.h>
#endif
#ifdef WIN32  
	#include "win32.h"
        #include <stdlib.h>
	#include <stdio.h>
#endif
#define LOBALIB_H
/*
 * Message structure for request of application
 */

typedef struct {
  int kind;                                /* Kind of request */
  int number;                              /* Number of host requested */
  struct sockaddr_in *hostlist[MAXHOSTS];  /* Optional list of wanted hosts */
} request;

/*
 * The following kinds of requests are implemented
 */

#define GET_ALL 0                         /* Get a complete list of all hosts with load index */
#define GET_TOP 1                         /* Get only one top-host (no load-index returned) */
#define GET_FASTEST 2                     /* Get the fastest host */
#define GET_OPT 3                    /* Get the optimum host */
/*
 * Message structure for reply of load manager
 */

typedef struct {
  int number;                            /* Number of hosts in subsequent hostlist */
  struct sockaddr_in hostlist[MAXHOSTS]; /* List of hosts found by the system */
  float load[MAXHOSTS];                  /* Current load index of hosts */
  int avail[MAXHOSTS];                   /* Availability of hosts */
} reply;

/*
 * Procedure to init Loadbalancing requests (open sockets etc)
 */

int request_init (/* no params */);


/*
 * Procedure to request hosts from local load-manager. Returns number
 * of host available is successful, error-code otherwise
 */

int get_hosts(/* request *what , reply *available_hosts */);

/*
 * Return codes of get_hosts()
 */

#define NOHOSTAVAILABLE -1   /* None of the requested hosts is available */
#define ERRORINHOSTLIST -2   /* Error in Host-List */
#define MANAGERNOTPRESENT -3 /* Load-Manager is not present on local site */
#define NOINIT -4            /* No previous/sucessful call of request_init */
#define ILLEGAL_REQUEST -6   /* No legal request was made */
#ifndef FATAL
#define FATAL		-7   /* Fatal error */
#endif
/*
 * Reset the connection to the load-manager
 */

void reset_system (/* no params */);




