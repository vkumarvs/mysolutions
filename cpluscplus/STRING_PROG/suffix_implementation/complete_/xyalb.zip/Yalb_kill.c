/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_kill.c,v 1.4 1994/03/09 15:11:27 carlsson Exp $
 * $Log: yalb_kill.c,v $
 * Revision 1.4  1994/03/09  15:11:27  carlsson
 * Added call to `permission()' to check that only  root can run the program.
 *
 * Revision 1.3  1994/03/01  08:39:25  carlsson
 * VERBOSE-mode introduced.
 *
 * Revision 1.2  1994/02/25  09:50:48  carlsson
 * Added parameters.
 *
 * Revision 1.1  1994/02/02  11:52:04  carlsson
 * Added error messages.
 *
 * Revision 1.0  1993/12/21  10:55:47  carlsson
 * Initial revision
 */
#include "system.h"

#include <sys/types.h>
#ifndef WIN32
#include <sys/socket.h>
#include <netdb.h>
#endif
#include <stdio.h>

#ifdef UNIX
extern void bcopy(char *, char *, int);
extern int sendto (int , __const __ptr_t, size_t , int , __CONST_SOCKADDR_ARG , socklen_t );
/*changed 9.8.99 extern int sendto(int, char *, int, int, struct sockaddr *, int);*/
extern int socket(int, int, int);
extern int close(int);
extern int gethostname(char *, int);
/*changed 9.8.99 extern int  strncpy(char *, char *, int );*/
extern char * strncpy(char *, const char *, size_t);
extern int strcasecmp();
/*changed 9.8.99 extern int fprintf();*/
#endif

#ifdef WIN32
extern int _stricmp();
#define strcasecmp _stricmp
#endif


extern int fprintf(FILE *, const char *, ...);
extern void permission(void);

#define ERR_ARGS -3
#define ERR_GET_HOST -2
#define ERR_KILL_SEND -1
#define OK 0

static char program[] = "yalb_kill";
static char global_hostname[MAXNAMELENGTH];
static int global_all = FALSE;

static int yalb_kill(char *in_host_name)
{
	static struct servent *get_ports = NULL;
	static struct sockaddr_in ldaemon;
	static rpc_message request;
	static int ldaemon_sock;
	struct hostent *local_host_ent;

	char local_host_name[MAXNAMELENGTH];

#ifdef WIN32
	WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    		return;
	}
#endif

	
	get_ports = getservbyname(DAEMON_SERVICE, "udp");

	ldaemon.sin_family = AF_INET;
	ldaemon.sin_port = get_ports->s_port;

	if( !in_host_name ) {
		if( gethostname(local_host_name, MAXNAMELENGTH) ) {
			return( ERR_GET_HOST );
		}
		local_host_ent = gethostbyname(local_host_name);
	}
	else {
		local_host_ent = gethostbyname(in_host_name);
	}

#ifdef WIN32
	memcpy((char *)&ldaemon.sin_addr,local_host_ent->h_addr_list[0],  local_host_ent->h_length);
#else 
	bcopy(local_host_ent->h_addr_list[0], (char *)&ldaemon.sin_addr, local_host_ent->h_length);
#endif
	if( !in_host_name ) {
		/* changed on 11.9.99 ldaemon.sin_addr.s_addr = (ldaemon.sin_addr.s_addr & BROADCAST_MASK) | ~BROADCAST_MASK;*/
	}
	
	ldaemon_sock = socket(AF_INET, SOCK_DGRAM, 0);
	
	request.kind = KILL_REQUEST;
	request.magic_number = MAGIC;
	
	
	if( sendto(ldaemon_sock, (char *)&request, sizeof request, 0, (struct sockaddr *)&ldaemon, sizeof ldaemon) < 0 ) {
#ifdef VERBOSE
		fprintf(stderr,"%s: can't send kill signal to ldaemon\n");
#endif
		close(ldaemon_sock);
		return( ERR_KILL_SEND );
	}
	close(ldaemon_sock);
	return( OK );
}




static int get_opts(int argc, char *argv[])
{
	int argp = 1;
#ifdef WIN32
		WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    		return;
	}
#endif

	if( gethostname(global_hostname, MAXNAMELENGTH) ) {
		return( ERR_GET_HOST );
	}

	global_all = FALSE;

	while( argv[argp] ) {

if( (strcasecmp("-host", argv[argp]) == 0 || strcasecmp("-h", argv[argp]) == 0) &&
		    argv[argp + 1] ) {
		argp++;
			strncpy(global_hostname, argv[argp], MAXNAMELENGTH);
		}
		else 
if( strcasecmp("-all", argv[argp]) == 0 ) {
				global_all = TRUE;
		}
		else {
			return( ERR_ARGS );
		}

		argp++;
	}

        return( OK );
}

static void err(int ret){
	switch( ret ) {
	      case ERR_GET_HOST:
		fprintf(stderr, "%s: Can't get information about local host.\n", program);
		break;
	      case ERR_KILL_SEND:
		fprintf(stderr, "%s: Can't send kill request.\n", program);
		break;
	      case ERR_ARGS:
		fprintf(stderr, "usage: %s [-all] [-host <hostname>] [-h <hostname>]\n", program);
		break;
	}
	exit(-1);
}

void main(int argc, char *argv[])
{
	int ret;

		permission();

	if( (ret = get_opts(argc, argv)) != OK ) {
                err(ret);
        }

	if( global_all ) {
		yalb_kill((char *)NULL);
	}
	else {
		yalb_kill(global_hostname);
	}
}



