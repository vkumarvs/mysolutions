/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */

/*
 * Copyright (c) 1994
 *c
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */


#define __USE_BSD
#include "remote.h"
#include "rexecbib.h"
#include "system.h"

#include "yalb_stats_db.h"
#include <stdio.h>
#ifdef LINUX
#include <signal.h>
#include <linux/socket.h>
#include <fcntl.h>
#endif
#ifdef WIN32
#include <signal.h>
#endif

#define MAX_DIR_LEN 255                  /* Maximum length of directory name */
#define MAX_BUF_LEN 4096                 /* Size of i/o buffer */
#define MAX_WIDTH 64                     /* Width used for select */
#define MAX_JOBS 50                        /* Maximum number of jobs that can be handled by rexec function */
#define TRUE 1
#define FALSE 0

/* Default values for certain symbols... */

#ifndef REXEC_TIMEOUT
#define REXEC_TIMEOUT 50                  
/* Timeout (in seconds) for waiting on an accept-call */
#endif /* REXEC_TIMEOUT */

#define CLOSE(x) { FD_CLR(job[x].manager, &readfds);shutdown(job[x].manager,2);close(job[x].manager);job[x].manager = -1; }

/*
 * Global variables visible to all functions of this module
 */

extern char **environ;                   /* Pointer to current environment */
 
struct /*job*/{                             /* Data to be stored for each remote job */
#ifdef WIN95
	SOCKET manager;
#else
	int manager;                           /* Sockets for communication with rexec manager */
#endif
	int io;                                /* Socket for io resulted from accept on io_sock */
  int exit_kind;                         /* Kind of exit-status (INTERNAL / EXECUTION / FALSE) */
  union {
    int errorcode;                          /* Errormessage to be sent to application */
#ifdef SUNOS
	union wait state;                       /* Exit status from wait3() */
#else
	int  state;                       /* Exit status from wait3() */
#endif
  } data;
  #define j_err data.errorcode
#define j_stat data.state
 
} job[MAX_JOBS];

int remain = 0;                          /* Number of bytes still to be written */
char buf[MAX_BUF_LEN];                   /* I/O buffer */
int new_job;                                /* Index of free entry in manager[] */
struct servent *serv;                    /* To get service from /etc/services */
unsigned short rexec_port;                      /* Port of rexec-manager */
fd_set readfds;                          /* Mask for selecting on input sockets */
fd_set writefds;                         /* Mask for selecting on stdout, stderr */
int initialized = FALSE;                 /* Flag whether system was initialized */
int io_sock;                             /* Socket for i/o with remote site */
unsigned short our_port;                        /* Number of local i/o-port associated with io_sock */
notify notification;                     /* Notification structure sent by rexec-manager */
exec_data request;                       /* Execution data for rexec-manager */
int exit_seen = FALSE;                   /* Flag whether remote job is finished (INTERACTIVE only) */
int rexec_mask;                          /* Mask used for blocking signals during manipulation of data structures */
struct timeval timeout;                  /* Timeout-value for waiting for an accept on io_sock */
int first;                               /* Indicates first execution of command */
#ifdef WIN32
LPCTSTR ROOT="/";
#endif
/*
 * Init the internal request data-structure 
 */


init_request()
{

  /*
   * Create our request for execution
   */
  
  request.job = new_job;
  request.port = our_port; 
#ifdef WIN32
	request.proc_nr = _getpid();
	getuid(&request.ruid);
	getgid(&request.rgid);
#endif
#ifdef UNIX
	request.ruid = getuid();
	request.euid = geteuid();
	request.rgid = getgid();
	request.egid = getegid();
	request.ngroups = getgroups(sizeof(request.groups) / sizeof(long), request.groups);
#endif
 
  request.umask = umask(0);
  umask (request.umask);

}


/*
 * Contact rexec-manager and send request 
 */

int contact(our_where)
struct sockaddr_in *our_where;                       /* Whom shall we contact ? */

{
  int ret;
  int count;
  int length = sizeof (*our_where);                   /* Length of internet-address */

  /*
   * Init the exit-status of this job
   */
	int on=TRUE;


  job[new_job].exit_kind = FALSE;
  
  /*
   * Open socket for communication with rexec-manager. If no more
   * sockets available, return error-code
   */

 if ((job[new_job].manager = socket(AF_INET, SOCK_STREAM, 0)) < 0) {


/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/

#ifdef UNIX
	  sigsetmask(rexec_mask);
#endif
    return NO_RESOURCES;
  }

 request.sock_nr = job[new_job].manager;


  FD_SET(job[new_job].manager, &readfds);
  
  /*
   * Try to connect to foreign host. If not successful, return
   * error-code.
   */
  
  our_where->sin_port = rexec_port;
  our_where->sin_family =AF_INET;
   while ((ret = connect(job[new_job].manager, (struct sockaddr *) our_where, sizeof (*our_where))) && errno == EINTR);
  

  if (ret) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX

    sigsetmask(rexec_mask);
#endif
    return COULD_NOT_CONNECT;
  }

  /*
   * Get notification from remote execution manager
   */
  
  while ((ret = recv(job[new_job].manager, &notification, sizeof (notification), 0)) < 0 && errno == EINTR);
  
  if (ret < 0) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    return CONNECTION_CLOSED;
  }

  if ((notification.kind != EXECUTION_OK) || (notification.magic_number != MAGIC)) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    return NO_RESOURCES;
  }
  
  /*
   * Mark sockets as asynchronous and claim the SIGIO to ourselves 
   */
  
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
  fcntl(job[new_job].manager, F_SETOWN, getpid ());
  fcntl(job[new_job].manager, F_SETFL, O_ASYNC);
#endif
  
    FD_SET(job[new_job].manager, &readfds);
  
  /*
   * Job successfully done...
   */
  
  return TRUE;

}

/*
 * Send request for execution to rexec-manager and wait for the remote
 * i/o-sockets to connect...
 */

int send_request (our_request)
exec_data *our_request;

{
  fd_set manager_fds;
  int ret; 
  int err;
  struct sockaddr_in dummy;                       /* We don't care who is connected to our io-socket (as we know it ?!) */
  int length = sizeof (struct sockaddr_in);                   /* Length of internet-address */

  FD_ZERO(&manager_fds);
  FD_SET(io_sock,&manager_fds);


  while ((ret = send(job[new_job].manager, (char *)&request, request.length, 0)) < 0 && errno == EINTR);

  /*
   * If transmission was not successful, return error-code. We could
   * probably distinguish between the various errno's returned by
   * send... 
   */
  
  if (ret < 0) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    return CONNECTION_CLOSED;
  }
  
  /*
   * Now we must wait for the remote execution manager to authenticate
   * our request. Since he simply closes down connection if the
   * authentication fails, we are in trouble because in the next step,
   * we wait for our remote child to connect to us, which will never
   * happen in this case. But the failed authentication should not happen 
   * if this library is used. The only reason for us to hang here is
   * that the local loaddaemon is down. Should this happen?
   * But we are careful and wait for REXEC_TIMEOUT seconds until we give up
   * and return an error-code...
   */
  
  /*
   * Init timeout-Value
   */
  
  timeout.tv_sec = REXEC_TIMEOUT;
  timeout.tv_usec = 0;

  /*
   * Wait for io_sock to become readable...
   */
   while ((ret = select(MAX_WIDTH, &manager_fds, (fd_set *)0, (fd_set *)0, NULL /*13.12 &timeout*/)) < 0 && errno == EINTR);
  
/*printf("Reached here-I\n"); */
  /*
   * Check whether a timeout has occured...
   */
  
  if (ret == 0 || !FD_ISSET(io_sock, &manager_fds)) {
    static stats_timeout timeout_info;
	  
    timeout_info.count = 1;
    stats_write(STATS_TYPE_REXEC_TIMEOUT, (stats_info)&timeout_info);

    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    return CONNECTION_CLOSED;
  }

  /*
   * ...or the remote host is unreachable
   */
  
  if (ret < 0) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    perror("Selecting: ");
    return COULD_NOT_CONNECT;
  }


  while ((job[new_job].io = accept (io_sock, &dummy, (int *)&length)) < 0 && errno == EINTR);
  
  if (job[new_job].io < 0) {
    CLOSE (new_job);
/* No equivalent in in WIN32
#ifdef WIN32
#endif
*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    perror("Accepting");
    return CONNECTION_CLOSED;
  }
  
  /*
   * The whole i/o is handled asynchronously...
   */
/*#ifdef WIN32
	err = WSAAsyncSelect(job[new_job].io, sigWnd,0, FD_READ|FD_WRITE|FD_CLOSE);
	if (err == SOCKET_ERROR) {
		fprintf(stderr,"Windows Sockets error %d: WSAAsyncSelect failure.\n",WSAGetLastError());
		exit(-1);
}

#endif*/
#ifdef UNIX
  fcntl(job[new_job].io, F_SETOWN, getpid ());
  fcntl(0, F_SETFL, O_ASYNC);
#endif

  /*
   * Mark stdin-socket for asynchronous i/o. (INTERACTIVE mode only)
   */
 
  if (initialized == INTERACTIVE) {
/*#ifdef WIN32
  err = WSAAsyncSelect(GetStdHandle(STD_INPUT_HANDLE), sigWnd,0, FD_READ|FD_WRITE|FD_CLOSE);
	if (err == SOCKET_ERROR) {
		fprintf(stderr,"Windows Sockets error %d: WSAAsyncSelect failure.\n",WSAGetLastError());
		exit(-1);
	}
#endif*/

#ifdef UNIX
	fcntl(0, F_SETOWN, getpid ());
     fcntl(0, F_SETFL, O_ASYNC);

#endif
   
    FD_SET(0, &readfds);
    fflush (stdout);
  }

  /*
   * Add new io-socket to the read-file-descriptor set used to select
   * on io-sockets
   */

  FD_SET(job[new_job].io, &readfds);

  /*
   * Reinstall old signal-mask 
   */
/*#ifdef WIN32
  //No eqvt
#endif*/

#ifdef UNIX
  sigsetmask(rexec_mask);
#endif
  
  /*
   * Job successfully done...
   */
  
  return TRUE;

}

/*
 * Handle the asynchronous i/o sockets
 */

#ifdef WIN32
 BOOL WINAPI handle_sigio (DWORD CtrlEvent)
{
  static fd_set fd_read;                 // Temporary read filedescriptor-set 
  static fd_set fd_write;                // Temporary write filedescriptor-set 
  static int size=0;                       // Actual size of read buffer 
  static int written;                    // Number of written bytes 
  static int count;
  static struct timeval poll = 
  {(long)0, (long)0};                    // We only poll on selects since one of them must be successful 
  static rexec_reply rexec_code;         // Exit-code from rexec-manager
  static int exit_received;              //Received any exit-status?  

  fd_read = readfds;
  /* Select on given read filedescriptors. We only poll on this
  // because if no socket would be readable, we'd just simply quit
   // this routine and wait for the next SIGIO, wouldn't we?
   */

  while (select( MAX_WIDTH, &fd_read, (fd_set *)0, (fd_set *)0, &poll) < 0 && errno == EINTR);
  
  // Check remote io-sockets for readability
   
  
  for (count = 0; count < MAX_JOBS; count++) {
    if (job[count].manager >= 0 && job[count].io >=0 && FD_ISSET(job[count].io, &fd_read))
    {
      /* Now we write the previously received buffer to our stdout. We
       // loop on this... We'll see if this causes any trouble...*/
       
      
      do {
	
	remain = 0;
	fd_write = writefds;
	while (select( MAX_WIDTH, (fd_set *)0, &fd_write, (fd_set *)0, &poll) < 0 && errno == EINTR);

	if (FD_ISSET(1, &fd_write)) {


 

		
		while ((size = recv (job[count].io, buf, MAX_BUF_LEN, 0)) < 0 && errno == EINTR);
	   remain = size;
	  if (size >=0 ){
	    
	    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),(buf+(size - remain)),remain,&written,NULL);
	   if (written < 0) {
	      if(errno != EINTR) {
		perror("writing to stdout");
		exit(1);
	      }
	    }
	    else
	      remain -= written;
	  }
	    
	}
	else
	  break;
      } while (remain > 0);
    }
  }

  /*
   * If we are in interactive mode, we must redirect our stdin to our
   * remote child. Let's go...
   */
 
  /*start of  commented on 29.10.99 */
  if(initialized == INTERACTIVE) { 
    if (FD_ISSET(0, &fd_read) && !exit_seen) {
       while ((size = _read (GetStdHandle(STD_INPUT_HANDLE), buf, MAX_BUF_LEN, 0)) < 0 && errno == EINTR);
      	  remain = size;
      
      if (size == 0) {
	FD_CLR(job[0].io, &readfds);
	shutdown(job[0].io,2);
	close(job[0].io);
      }
      
      /* Now we write the previously received buffer to the remote io-socket. We
       // loop on this... We'll see if this causes any trouble...*/
       
      
      while (remain > 0) {
	WriteFile(job[0].io,(buf+(size - remain)),remain,&written,NULL);
			if (written > 0) {
	  remain -= written;
	}
	else
	{
	  if(errno == EPIPE) {
	    fprintf(stderr,"\n***Connection closed.\n");
	    break;
	  }
	}
      }
    }
  } 

  /*
   * Check whether any exit-status is available from rexec-manager
   */
  
  exit_received = FALSE;
  
  for (count = 0; count < MAX_JOBS; count++) {
    if (job[count].manager >= 0 && FD_ISSET(job[count].manager, &fd_read))
    {
      size = recv(job[count].manager, (char *)&rexec_code, sizeof (rexec_reply),0);
      
      /*
       * Check correctness of message...
       */
    if ((rexec_code.kind != EXEC_ERROR && rexec_code.kind != EXIT_STATUS) ||
	  rexec_code.magic_number != MAGIC)
	continue;
      /*
       * We received an internal error from rexec-manager
       */
      
  	if (rexec_code.kind == EXEC_ERROR) {
	
	job[count].j_err = rexec_code.r_error;
	job[count].exit_kind = INTERNAL;
	FD_CLR(job[count].manager, &readfds);
	shutdown(job[count].manager,2);
	close(job[count].manager);
	if (FD_ISSET(job[count].io, &readfds) && job[count].io > 0) {
	  FD_CLR(job[count].io, &readfds);
	  shutdown(job[count].io,2);
	  close(job[count].io);
	}
	exit_received = TRUE;
	continue;
      }
      
      /*
       * The remote execution exited with a call to exit()
       */
      
    if (rexec_code.kind == EXIT_STATUS) {
	
	job[count].j_stat = rexec_code.r_status;
	job[count].exit_kind = EXECUTION;
	FD_CLR(job[count].manager, &readfds);
	shutdown(job[count].manager,2);
	close(job[count].manager);
	FD_CLR(job[count].io, &readfds);
	shutdown(job[count].io,2);
	close(job[count].io);
	exit_received = TRUE;
	continue;
	
      }
    }
  }

  /*
   * When we received an exit-message, we inform the
   * rexec_wait-routine that a job has ended.
   */
  
  if(exit_received) 
    exit_seen = TRUE;
  return TRUE;
}
#endif

#ifdef UNIX
void handle_sigio ()
{
  static fd_set fd_read;                 /* Temporary read filedescriptor-set */
  static fd_set fd_write;                /* Temporary write filedescriptor-set */
  static int size;                       /* Actual size of read buffer */
  static int written;                    /* Number of written bytes */
  static int count;
  static struct timeval poll = 
  {(long)0, (long)0};                    /* We only poll on selects since one of them must be successful */
  static rexec_reply rexec_code;         /* Exit-code from rexec-manager */
  static int exit_received;              /* Received any exit-status?  */
  
  /*
   * Init local file descriptor sets with global values
   */

  fd_read = readfds;

  /*
   * Select on given read filedescriptors. We only poll on this
   * because if no socket would be readable, we'd just simply quit
   * this routine and wait for the next SIGIO, wouldn't we?
   */

  while (select( MAX_WIDTH, &fd_read, (fd_set *)0, (fd_set *)0, &poll) < 0 && errno == EINTR);
  
  /*
   * Check remote io-sockets for readability
   */
  
  for (count = 0; count < MAX_JOBS; count++) {
    if (job[count].manager >= 0 && job[count].io >=0 && FD_ISSET(job[count].io, &fd_read))
    {
      /*
       * Now we write the previously received buffer to our stdout. We
       * loop on this... We'll see if this causes any trouble...
       */
      
      do {
	
	remain = 0;
	fd_write = writefds;
	while (select( MAX_WIDTH, (fd_set *)0, &fd_write, (fd_set *)0, &poll) < 0 && errno == EINTR);

	if (FD_ISSET(1, &fd_write)) {

	  while ((size = recv (job[count].io, buf, MAX_BUF_LEN, 0)) < 0 && errno == EINTR);
	  remain = size;
	  if (size >=0 ){
	    
	    written = write(1, (buf+(size - remain)), remain);
	    if (written < 0) {
	      if(errno != EINTR) {
		perror("writing to stdout");
		exit(1);
	      }
	    }
	    else
	      remain -= written;
	  }
	    
	}
	else
	  break;
      } while (remain > 0);
    }
  }

  /*
   * If we are in interactive mode, we must redirect our stdin to our
   * remote child. Let's go...
   */
 
  if(initialized == INTERACTIVE) { 

    if (FD_ISSET(0, &fd_read) && !exit_seen) {
      
      	#ifdef WIN32
	while ((size = read (0, buf, MAX_BUF_LEN, 0)) < 0 && errno == EINTR);
	#endif
      	#ifdef UNIX
	while ((size = read (0, buf, MAX_BUF_LEN)) < 0 && errno == EINTR);
	#endif
      remain = size;
      
      if (size == 0) {
	FD_CLR(job[0].io, &readfds);
	shutdown(job[0].io,2);
	close(job[0].io);
      }
      
      /*
       * Now we write the previously received buffer to the remote io-socket. We
       * loop on this... We'll see if this causes any trouble...
       */
      
      while (remain > 0) {
	written = write(job[0].io, (buf+(size - remain)), remain);
	if (written > 0) {
	  remain -= written;
	}
	else
	{
	  if(errno == EPIPE) {
	    fprintf(stderr,"\n***Connection closed.\n");
	    break;
	  }
	}
      }
    }
  }

  /*
   * Check whether any exit-status is available from rexec-manager
   */
  
  exit_received = FALSE;
  
  for (count = 0; count < MAX_JOBS; count++) {
    if (job[count].manager >= 0 && FD_ISSET(job[count].manager, &fd_read))
    {
      size = recv(job[count].manager, (char *)&rexec_code, sizeof (rexec_reply),0);
      
      /*
       * Check correctness of message...
       */
      
      if ((rexec_code.kind != EXEC_ERROR && rexec_code.kind != EXIT_STATUS) ||
	  rexec_code.magic_number != MAGIC)
	continue;
      
      /*
       * We received an internal error from rexec-manager
       */
      
      if (rexec_code.kind == EXEC_ERROR) {
	
	job[count].j_err = rexec_code.r_error;
	job[count].exit_kind = INTERNAL;
	FD_CLR(job[count].manager, &readfds);
	shutdown(job[count].manager,2);
	close(job[count].manager);
	if (FD_ISSET(job[count].io, &readfds) && job[count].io > 0) {
	  FD_CLR(job[count].io, &readfds);
	  shutdown(job[count].io,2);
	  close(job[count].io);
	}
	exit_received = TRUE;
	continue;
      }
      
      /*
       * The remote execution exited with a call to exit()
       */
      
      if (rexec_code.kind == EXIT_STATUS) {

	job[count].j_stat = rexec_code.r_status;
	job[count].exit_kind = EXECUTION;
	FD_CLR(job[count].manager, &readfds);
	shutdown(job[count].manager,2);
	close(job[count].manager);
	FD_CLR(job[count].io, &readfds);
	shutdown(job[count].io,2);
	close(job[count].io);
	exit_received = TRUE;
	continue;
	
      }
    }
  }

  /*
   * When we received an exit-message, we inform the
   * rexec_wait-routine that a job has ended.
   */
  
  if(exit_received) 
    exit_seen = TRUE;
}
#endif
/*
 * Pass a given signal to our remote child
 */

#ifdef WIN32
 BOOL WINAPI send_signal  (DWORD sig)
{
  int count;
  char sig_char;                     /* We have to encode the signal in a single byte (oob-data!) */
  int mask;

  /*
   * Block SIGIO to avoid any i/o during handling of the associated
   * signals. 
   */

  
  sig_char = (char)sig;

  /*
   * In INTERACTIVE mode, we send the signal to our only child
   */

  if (initialized == INTERACTIVE) {
    send(job[0].manager, &sig_char, sizeof (char), MSG_OOB);
  }
  else {
    /*
     * In PARALLEL mode, we send the signal to all our remote children
     */
    
    for (count = 0; count < MAX_JOBS; count++) {
      if (job[count].manager >=  0) 
	send(job[count].manager, &sig_char, sizeof (char), MSG_OOB);
    }
  }




  /*
   * If we received a signal that terminates or stops a process, we
   * want to take the same actions as our remote chlidren. We do this
   * by reinstalling the default signal handler and sending 
   * ourselves the previously catched signal. We must remove the
   * non-blocking i/o-mode from stdout-socket. Otherwise the shell
   * would be nasty and do a logout. In case of SIGQUIT we must be
   * careful because this signal causes a coredump. Since we do not
   * want to overwrite it, we chdir to the root-directory which is
   * hopefully not writeable to our process.
   */
	if(sig == SIGTERM)
    SetCurrentDirectory(ROOT);

signal (sig, SIG_DFL);
  if( sig != SIGTERM ) {
	  GenerateConsoleCtrlEvent(sig,0);
 
  }
  return;
  
}  
#endif
#ifdef UNIX
void send_signal (sig)
long sig;
{
  int count;
  char sig_char;                     /* We have to encode the signal in a single byte (oob-data!) */
  int mask;

  /*
   * Block SIGIO to avoid any i/o during handling of the associated
   * signals. 
   */

  mask = sigblock(~0);
  sig_char = (char)sig;

  /*
   * In INTERACTIVE mode, we send the signal to our only child
   */

  if (initialized == INTERACTIVE) {
    send(job[0].manager, &sig_char, sizeof (char), MSG_OOB);
  }
  else {
    /*
     * In PARALLEL mode, we send the signal to all our remote children
     */
    
    for (count = 0; count < MAX_JOBS; count++) {
      if (job[count].manager >=  0) 
	send(job[count].manager, &sig_char, sizeof (char), MSG_OOB);
    }
  }


  /*
   * If we received a SIGCONT, we reinstall the send_sig() as
   * signal-handler for SIGTSTP, SIGTTIN and SIGTTOU and reissue
   * non-blocking i/o for stdout.
   */
  
  if(sig == SIGCONT) {

    signal (SIGTSTP, send_signal);
    signal (SIGTTOU, send_signal);
    signal (SIGTTIN, send_signal);

    sigsetmask(mask);

    return;
  }
 /*
   * If we received a SIGWINCH, we quit...
   */
 if(sig == SIGWINCH) {
	 
    sigsetmask(mask);

    return;
  }

  /*
   * If we received a signal that terminates or stops a process, we
   * want to take the same actions as our remote chlidren. We do this
   * by reinstalling the default signal handler and sending 
   * ourselves the previously catched signal. We must remove the
   * non-blocking i/o-mode from stdout-socket. Otherwise the shell
   * would be nasty and do a logout. In case of SIGQUIT we must be
   * careful because this signal causes a coredump. Since we do not
   * want to overwrite it, we chdir to the root-directory which is
   * hopefully not writeable to our process.
   */

  if(sig == SIGQUIT)
    chdir("/");
  sigsetmask(mask);
  signal (sig, SIG_DFL);
  if( sig != SIGKILL ) {
	   kill (getpid(), sig);
  }
  return;
}
#endif

 
 
/*
 * Init the rexec-environment. 
 */

int rexec_init (flag)
int flag;
 
{
  int count = 0;
  struct sockaddr_in name;
 
  if (initialized)
    return ALREADY_INITED;
  
 /*repalcedon 15.9.99  setpgid(0, getpid()); */
#ifdef WIN32
  /**eqvt?**/
#endif
#ifdef UNIX
  setpgid(0,getpid());
#endif

  /*
   * Init data-structures
   */
  
  for (count = 0; count < MAX_JOBS; count++)
#ifdef WIN32
	    job[count].manager = NULL;
#endif
#ifdef UNIX
  job[count].manager = -1;
#endif

  FD_ZERO(&readfds);
  
  request.kind = REQUEST_FOR_EXEC;
  request.magic_number = MAGIC;
  
  /*
   * Install signal-handler for signal passing
   */
#ifdef WIN32
  /*SetConsoleCtrlHandler(send_signal,SIGINT);*/ 
  SetConsoleCtrlHandler(send_signal,SIGTERM);
#endif
#ifdef UNIX
  signal (SIGHUP, send_signal);
  signal (SIGQUIT, send_signal);
  signal (SIGTSTP, send_signal);
  signal (SIGCONT, send_signal);
  signal (SIGTTOU, send_signal);
  signal (SIGTTIN, send_signal);
  signal (SIGWINCH, send_signal);
  signal (SIGINT, send_signal); 
  signal (SIGTERM, send_signal);
#endif
  
  /*
   * Ignore SIGPIPE because we don't want to die when remote site
   * does not exist
   */

#ifdef UNIX
  signal (SIGPIPE, SIG_IGN);
#endif  
  /*
   * Get port for rexec-service
   */
 
  serv = getservbyname(REMA_SERVICE, "tcp");
  rexec_port = serv->s_port;
  
  /*
   * Handler for asynchronous i/o
   */
#ifdef WIN32 
 SetConsoleCtrlHandler(handle_sigio,TRUE);
#endif
#ifdef UNIX
  signal (SIGIO, handle_sigio);
#endif  
  
  /*
   * Open socket for accepting i/o with remote site and bind a name to
   * it. 
   */

  /* XXX (schoenfr): checking error codes is a nice idea... */
   if ((io_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
      perror ("cannot fetch socket; reason");
	  return FATAL;
  }
  
  name.sin_family = AF_INET;
  name.sin_port = 1025;
  name.sin_addr.s_addr = INADDR_ANY;
 
  /*
   * Get any port number > 1024 for our socket
   */
  
while (bind(io_sock, (struct sockaddr FAR *)&name, sizeof name) < 0){ 
    name.sin_port++;
	}
    
  /*
   * Now we have our port number 
   */
  
  our_port = name.sin_port;
  
  /*
   * Mark io-socket as receiving connections
   */
#if 0
  listen(io_sock);
#else
  /* XXX (schoenfr): better specify backlog - oh my dear... */
  if (listen(io_sock, 10) < 0)
  {
      perror ("cannot listen; reason");
      return FATAL;
  }
#endif

  /*
   * Add stdout-deskriptor to writefds to be able to select on it. 
   */
  
  FD_SET(1, &writefds);
  
  first=TRUE;

  /*
   * Set init-flag 
   */
  
  initialized = flag;
  
  return 0;
  
}

 
/*
 * Execute a given file remotely. Returns (positive) Job number or
 * (negative) error number in PARALLEL mode resp. zero or (negative)
 * error number in INTERACTIVE mode .
 */
 
int rexec (file, args, where, jobkind)
char *file;
char *args;
struct sockaddr_in *where;
int jobkind;
 
{
  int count;                                      /* Counter */
  int ret;                                        /* Return-value of functions */
  char cwd[MAX_DIR_LEN];                          /* Name of current workdir */
  char *cp;                                       /* For filling variable part of request */
  char *argpointer[MAX_ARGS];                     /* Pointer to arguments */
  int help = 0;
  char buf[3000];                                 /* Buffer for arguments of bin-file */


  if (!initialized)
    return NO_INIT;

  if(first){
    exit_seen = FALSE;
    first = FALSE;
  }

  /*
   * To avoid trouble in parallel mode, we block all signals when we
   * manipulate internal data-structures...
   */
 /*#ifdef WIN32 
  //no eqvt
#endif*/

#ifdef UNIX
  rexec_mask = sigblock (~0); 
#endif

  /*
   * Find free entry in manager-table
   */
  
#ifdef WIN32
  for(new_job = 0; job[new_job].manager >= 0 && new_job < MAX_JOBS; new_job++);
#endif
#ifdef UNIX
for(new_job = 0; job[new_job].manager !=NULL && new_job < MAX_JOBS; new_job++);
#endif

  /*
   * If no further space in manager-table, return error-code
   */
  
  if (new_job >= MAX_JOBS)
    return NO_MORE_JOBS;
  
  init_request();

  request.jobkind = jobkind;

  cp = request.buf;
  
  /*
   * Add current work-directory to request
   */
  
#ifdef WIN32 
  GetCurrentDirectory(cwd,sizeof cwd);
#endif
#ifdef UNIX
  getcwd (cwd, sizeof cwd);
#endif
  
  strcpy(cp, cwd);
  
  /*
   * Add file to be executed to request
   */
  
  cp += strlen(cp) + 1;
  
  strcpy(cp, file);
  
  cp += strlen(file) + 1;
  
  /*
   * Align pointer to next longword
   */
  
  cp = ALIGN(cp, char *);
  
  /*
   * Count number of arguments given
   */
  
  ret = strlen (args);
  
  count = 1;
  
  argpointer[0] = file;
  
  while(help < ret) {
 
    while (args[help] == ' ')
      help++;
    
    if(args[help] == '`') {
      strcpy(buf, (args+help+1));
      buf[strlen(buf)-1] = '\0';
    }
    else
      if(sscanf((args+help), "%s", buf) != 1)
	break;
    
    argpointer[count] = (char *) malloc(strlen(buf)+1);
    sprintf(argpointer[count], "%s", buf);
    help += strlen(argpointer[count]) + 1;
    count++;
  }
  
  argpointer[count] = (char *)0;
  
  /*
   * Add number of arguments and the arguments themselves to request
   */
  
  *(long *)cp = (long) (count);
  cp += sizeof(long);
  
  for (count = 0; argpointer[count]; count++) {
    strcpy(cp, argpointer[count]);
    cp += strlen(cp) + 1;
    free(argpointer[count]);
  }
  
  /*
   * Align pointer to next longword
   */
  
  cp = ALIGN(cp, char *);
  
  /*
   * Add environment
   */
  
  for (count = 0; environ[count]; count++);
  
  *(long *)cp = (long) count;
  
  cp += sizeof(long);
  
  for (count = 0; environ[count]; count++) {
    strcpy(cp, environ[count]);
    cp += strlen(cp) + 1;
  }
  
  /*
   * Contact rexec-manager
   */
  
  if ((ret = contact(where)) < 0)
    return ret;

  /*
   * Determine length of our message
   */
  
  request.length = cp - ((char *)&request);

  /*
   * Send request to rexec-manager
   */
  
  if ((ret = send_request(&request)) < 0)
    return ret;


  /*
   * If we are in PARALLEL mode, we just return the number of the
   * current job to our client. Any exit will be reported to him by th
   * return of rexec_wait()
   */

  if (initialized == PARALLEL)
    return new_job;
#ifdef WIN32
 
  handle_sigio(CTRL_BREAK_EVENT);
  while (!exit_seen);
#endif
#ifdef UNIX
while (!exit_seen && sigpause(0));
#endif
 return TRUE;
}

 
/*
 * Execute a given file remotely. Returns (positive) Job number or
 * (negative) error number in PARALLEL mode resp. zero or (negative)
 * error number in INTERACTIVE mode .
 */
 
int rexecv (file, args, where, jobkind)
char *file;
char **args;
struct sockaddr_in *where;
int jobkind;
 
{
  int count;                                      /* Counter */
  int ret;                                        /* Return-value of functions */
  char cwd[MAX_DIR_LEN];                          /* Name of current workdir */
  char *cp;                                       /* For filling variable part of request */
  int length = sizeof (*where);                   /* Length of internet-address */
  struct sockaddr_in dummy;                       /* We don't care who is connected to our io-socket (as we know it ?!) */
  char *argpointer[MAX_ARGS];                     /* Pointer to arguments */
  int help = 0;
  
  if (!initialized)
    return NO_INIT;

  if(first){
    exit_seen = FALSE;
    first = FALSE;
  }

  /*
   * To avoid trouble in parallel mode, we block all signals when we
   * manipulate internal data-structures...
   */
 /* #ifdef WIN32 
  //no eqvt
#endif*/

#ifdef UNIX
  rexec_mask = sigblock (~0); 
#endif


  /*
   * Find free entry in manager-table
   */
  
#ifdef WIN32
	for(new_job = 0; job[new_job].manager !=NULL && new_job < MAX_JOBS; new_job++);
#endif
#ifdef UNIX
  for(new_job = 0; job[new_job].manager >= 0 && new_job < MAX_JOBS; new_job++);
#endif
  /*
   * If no further space in manager-table, return error-code
   */
  
  if (new_job >= MAX_JOBS) {
/*#ifdef WIN32 
  //no eqvt
#endif*/
#ifdef UNIX
    sigsetmask(rexec_mask);
#endif
    return NO_MORE_JOBS;
  }
  
  /*
   * Init request structure
   */
  
  init_request();

  request.jobkind = jobkind;

  cp = request.buf;
  
  /*
   * Add current work-directory to request
   */
  
 #ifdef UNIX
	getcwd (cwd, sizeof cwd);
#endif
 #ifdef WIN32
GetCurrentDirectory(sizeof cwd,cwd);
#endif
  
 strcpy(cp, cwd);
  
  /*
   * Add file to be executed to request
   */
  
  cp += strlen(cp) + 1;
  
  strcpy(cp, file);
  
  cp += strlen(cp) + 1;
  
  /*
   * Align pointer to next longword
   */
  
  cp = ALIGN(cp, char *);
  
  /*
   * Count number of arguments given
   */
  
  for (count = 0; args[count]; count++);
 
  /*
   * Add number of arguments and the arguments themselves to request
   */
  
  *(long *)cp = (long) (count + 1);
  cp += sizeof(long);
  
  /*
   * The first parameter given to exec() is always the filename...
   */
  
  strcpy(cp, file);
  cp += strlen(cp) + 1;
 
  for (count = 0; args[count]; count++) {
    strcpy(cp, args[count]);
    cp += strlen(cp) + 1;
  }
  
  /*
   * Align pointer to next longword
   */
  
  cp = ALIGN(cp, char *);
  
  /*
   * Add environment
   */
  
  for (count = 0; environ[count]; count++);
  
  *(long *)cp = (long) count;
  
  cp += sizeof(long);
  
  for (count = 0; environ[count]; count++) {
    strcpy(cp, environ[count]);
    cp += strlen(cp) + 1;
  }
  
  /*
   * Contact rexec-manager
   */
  
  if ((ret = contact(where)) < 0)
    return ret;

  /*
   * Determine length of our message
   */
  
  request.length = cp - ((char *)&request);
  /*
   * Send request to rexec-manager
   */
#ifdef WIN32
  // fprintf(stderr,"Rexecv: Reached the stage to send request to Rexecmanager\n"); /*added on 29.8.99*/  
#endif
#ifdef UNIX
  syslog(LOG_ERR,"Rexecv: Reached the stage to send request to Rexecmanager\n"); /*added on 29.8.99*/  
 #endif
  if ((ret = send_request(&request)) < 0)
    return ret;

#ifdef WIN32
  //fprintf(stderr,"Rexecv: Reached the stage after service of request by Rexecmanager\n"); /*added on 29.8.99*/  

#endif
#ifdef UNIX
 syslog(LOG_ERR,"Rexecv: Reached the stage after service of request by Rexecmanager\n"); /*added on 29.8.99*/  
  #endif
																					 
 /*
   * If we are in PARALLEL mode, we just return the number of the
   * current job to our client. Any exit will be reported to him by th
   * return of rexec_wait()
   */

  if (initialized == PARALLEL)
    return new_job;
#ifdef WIN32
  //fprintf(stderr,"Before handle_SIGIO\n");
  handle_sigio(CTRL_BREAK_EVENT);
  while (!exit_seen);//5.12
/*if (SetEvent(CTRL_BREAK_EVENT))
	while (!exit_seen);
else{ 	fprintf(stderr,"Error in setting event\n"); exit(-1);}
*/
#endif
#ifdef UNIX
while (!exit_seen  && sigpause(0));
#endif

  return TRUE;

}

/*
 * This function should be called when exiting the rexec-system. It
 * closes all sockets
 */

int rexec_close()

{
  int count;
  int pending = FALSE;          /* Indicates whether jobs were still pending on call */

  if (!initialized)
    return NO_INIT;

  /*
   * If there are jobs pending (this is only possible in PARALLEL mode
   * since rexec() resp. rexecv() block in INTERACTIVE mode) we kill
   * them because we want a controlled exit for our rexec-manager(s).
   * We need to call send_signal() only once because SIGKILL will be
   * sent to all our remote children (see send_signal())
   */

  for (count=0; count < MAX_JOBS; count++) {

    if (job[count].manager >= 0 && !job[count].exit_kind) {
#ifdef WIN32
		send_signal(SIGTERM);
#endif
#ifdef UNIX
		send_signal(SIGKILL);
#endif
      pending = TRUE;
      break;
    }
  }

  /*
   * Reinstall default signal-handler
   */

#ifdef UNIX
  signal (SIGHUP, SIG_DFL);
  signal (SIGQUIT, SIG_DFL);
  signal (SIGTSTP, SIG_DFL);
  signal (SIGCONT, SIG_DFL);
  signal (SIGTTOU, SIG_DFL);
  signal (SIGTTIN, SIG_DFL);
  signal (SIGWINCH, SIG_DFL);
  signal (SIGPIPE, SIG_DFL);
#endif
signal (SIGINT, SIG_DFL); 
signal (SIGTERM, SIG_DFL);

  /*
   * Remove FASYNC-Flag for stdin.
   */

#ifdef UNIX
  count = fcntl (0, F_GETFL);
  /***removed on 3.8.99 
   *count &= ~FASYNC;
   ****/
  count &= ~O_ASYNC; /*added on 13.9.99*/
  fcntl (0, F_SETFL, count);
#endif

  fflush (stdout);
  
  close(io_sock);

  /*
   * Now mark the system as not initialized
   */
  
  initialized = FALSE;

  return pending;
  
}


int get_exit_status (exit_status)
exit_state *exit_status;

{
  int count;
  int further;
  int exit_mask;

  if (!initialized)
    return NO_INIT;
/*#ifdef WIN32 
  // no eqvt
#endif*/
#ifdef UNIX
  exit_mask = sigblock(~0);
#endif

  for (count = 0; count < MAX_JOBS; count++) {

    if (job[count].exit_kind)  {

      exit_status->kind = job[count].exit_kind;
      exit_status->job = count;

      if (job[count].exit_kind == INTERNAL)
	exit_status->data.errorcode = job[count].j_err;
      else
	exit_status->data.state = job[count].j_stat;
      
      /*
       * Mark exit status as submitted
       */
      
      job[count].exit_kind = FALSE;

      /*
       * Now we mark this table entry as free
       */
      
      job[count].manager = -1;
      
      /*
       * Check whether any further exit status is available. This is
       * used to asure that rexec_wait() will not block when called
       * again. Remember that i/o is handled asynchronously!
       * Of course this is only valid in PARALLEL mode...
       */
      
      exit_seen = FALSE;

      for (further = 0; further < MAX_JOBS; further++) 
	if (job[further].exit_kind) {
	  exit_seen = TRUE;
	  break;
	}
/*#ifdef WIN32 
  // no eqvt
#endif*/
#ifdef UNIX
      sigsetmask(exit_mask);
#endif
      return TRUE;
    }
  }
/*#ifdef WIN32 
  // no eqvt
#endif*/
#ifdef UNIX
  sigsetmask(exit_mask);
#endif
  return FALSE;
}

/*
 * Wait for a remote process to exit (PARALLEL mode only)
 */
int rexec_wait()

{
  int flag = FALSE;              /* Indicates whether a job is still pending */
  int count;
  
  if (!initialized)
    return NO_INIT;
  /*
   * See whether any jobs are pending. If not, return NO_JOBS_PENDING
   * error-code. 
   */

  flag = FALSE;

  for (count = 0; count < MAX_JOBS; count++) {
    if (job[count].manager >= 0){
      flag = TRUE;
      break;
    }
  }

  if (!flag)
    return NO_JOBS_PENDING;
#ifdef WIN32
  while (!exit_seen );
#endif
#ifdef UNIX
while (!exit_seen && sigpause(0) < 0 );
#endif

  return TRUE;
  
}
