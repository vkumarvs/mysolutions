/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: loadmanager.c,v 1.5 1994/03/09 14:40:52 carlsson Exp $
 * $Log: loadmanager.c,v $
 * Revision 1.5  1994/03/09  14:40:52  carlsson
 * Added VERBOSE-mode.
 * Introduced the availability "categories" HOST_DOWN, HOST_AVAIL, and
 * HOST_NOT_AVAIL.
 *
 * Revision 1.4  1994/03/01  20:59:04  carlsson
 * Added loadpolling for the entry GET_ALL_HOSTS.
 *
 * Revision 1.3  1994/03/01  20:31:40  carlsson
 * Fixed bug in fill_in_dummy().
 * Added call to gettimeofday() to set the global variable `incoming'
 * in poll_for_load.
 *
 * Revision 1.2  1993/12/21  11:56:42  carlsson
 * Fixed bug?
 *
 * Revision 1.1  1993/12/21  09:54:44  carlsson
 *
 * New constant MAX_MISSING_UPDATES added. Multiplied with the
 * constant UPDATE it describes the minimum
 * timeinterval within which a host must send its load information. If
 * this isn't done the host is considered as down.
 *
 * The fields alpha, is_dummy, is_dead and clients was added to the
 * structure load_indices to be able to sort the list of hosts according
 * to their alpha values, to mark hosts as not configured, to mark hosts
 * as down and to store the number of clients for a swap server
 * respectively.
 *
 * The following static variables where added:
 *      time_out      - Can take the values TRUE or FALSE and is used 
 *                      in handle_SIGALTM() and poll_for_load() to cause
 *                      a timeout when receiving answers from a load
 *                      request broadcast.
 *      idle_host     - Contains the maximum load a host may have to
 *                      be considerd idle.
 *      swap_validity - Contains the swap validity in percent.
 *      minimum_top   - Contains the minimum number of hosts that must
 *                      be in the top-list in order
 *                      to select a host from the top-list for the 
 *                      strategy TOPLIST.
 *      improvment    - Percentage by which the load index of selected
 *                      host must be lower than local index
 *      strat         - The host selection strategy: TOPHOST or TOPLIST.
 *      loadpolling   - TRUE or FALSE, depeneding on if loadpolling 
 *                      should be performed or not.
 *      poll_timeout  - Timeout when waiting for responses to broadcasted
 *                      load polling request.
 *
 * The following new functions where added:
 *      handle_SIGALRM()
 *      readsysconfig()         - Reads system configuration.
 *      next_host()             - Simulates a cirkular list.
 *      is_empty()              - Checks if the host-list is empty.
 *      get_host()              - Gets a host from the host-list.
 *      remove_host()           - Removes a host from the host-list.
 *      insert_host()           - Inserts a host in the host-list in 
 *                                sorted order.
 *      new_dummy()             - Creates a new dummy host and inserts 
 *                                it in the host-list.
 *      readhostconfig()        - Reads host configuration.
 *      fill_in_dummy()         - Fills in a dummy entry in the host-list
 *                                with its configuration.
 *      insert_top()            - Inserts a host in the top-list.
 *      remove_top()            - Removes a host from the top-list.
 *      new_host()              - Creates a new host entry and inserts 
 *                                it in the host-list.
 *      is_up()                 - Checks if a host is up (or down).
 *      handle_SIG_CONFIG_READ()- Installed as signalhandler for 
 *                                SIG_CONFIG_READ (SIGUSR1).
 *                                Calls readsysconfig().
 *
 * The following functions where changed:
 *      poll_for_load()         - The possibility to use loadpolling added.
 *                                Statistics added.
 *      main()                  - Hard coded names in calls to getservbyname
 *                                changed to the
 *                                constants DAEMON_SERVICE and LOMA_SERVICE.
 *                              - The possibility to choose between the
 *                                two strategies
 *                                TOPLIST and TOPHOST added.
 *                              - The possibility to get the host with the
 *                                smallest alpha added.
 *                                The message is GET_FASTEST_HOST.
 *
 * Revision 1.0  1993/12/02  14:52:58  stille
 * Initial revision
 */

#include <stdio.h>
#include "system.h"
#ifdef LINUX
#include <linux/socket.h>
#include <signal.h>
#include <string.h>
#include <netdb.h>
#endif
#ifdef WIN32
#include <signal.h>
#endif
#include "yalb_config_db.h"
#include "yalb_stats_db.h"

#define MAXWIDTH 30		/* Maximum number of sockets to listen to */
#define MAXLOAD 42		/* Maximum value of load index */
#define TRUE 1
#define FALSE 0
#define SWAPLOAD(x) ((x->swap_serv->load * swap_validity) / 100)
#define inline  /*added on  5.9.99*/
#ifndef VERBOSE
#define VERBOSE
#endif
char myname[] = "loadmanager";

/*
 * Internal structure for storing load-indices
 */

typedef struct load_indices
{
  struct sockaddr_in host;	/* Internet-address of host (key) */
  float load;			/* Load-index of host */
  float alpha;			/* The speed of the host */
  int is_dummy;			/* TRUE if the host is a dummy swap server */
  int is_dead;			/* TRUE if the host is down */
  int clients;			/* Number of clients for a swap server */
  int avail;			/* Availability of host */
  int is_top;			/* Flag to determine whether host is top */
#ifdef WIN32
  struct tm timestamp;	/* Timestamp of last update (might be used to indicate dead hosts) */
#endif
  
#ifdef UNIX
  struct timeval timestamp;	/* Timestamp of last update (might be used to indicate dead hosts) */
#endif

  struct load_indices *next_host;	/* Sorted by host-numbers */
  struct load_indices *next_top;	/* Next top-host */
  struct load_indices *prev_top;	/* Previous top-host */
  struct load_indices *swap_serv;	/* Swap-server of host (NIL=none) */
  struct load_indices *next_selected;	/*pointer to next node in the selectd host_list*/	
}
load_indices;

load_indices *top;		/* Pointer to first top-host */
load_indices *host_list = NULL;	/* Pointer to list of load-indices sorted by internet-addresses */
load_indices *help;		/* Pointer to examined list element */
load_indices *local_host = NULL;	/* Pointer to local-host-entry in host_list */
load_indices swap_dummy;	/* Default swap-server with load = 0.0 (used when no swap-server is needed) */
rpc_message appl_reply;		/* Reply-message to be sent to application */
rpc_message load;		/* Buffer for incoming load-indices */
int daemon;			/* Socket to communicate with load daemon */
struct sockaddr_in remote;	/* Broadcast-address of load-daemon */
int namelength = sizeof (struct sockaddr_in);	/* Length of host-address */
int top_hosts = 0;		/* Number of hosts in top-list */
int number_of_hosts = 0;	/* Total number of hosts */
struct sockaddr_in host;	/* Originator of load-index internet-address */

#ifdef WIN32
struct sockaddr_in from;	/* Address of Unix-domain-socket requesting application */
struct tm *incoming;	/* Timestamp for incoming messages */
#endif

#ifdef UNIX
struct sockaddr_un from;	/* Address of Unix-domain-socket requesting application */
struct timeval incoming;	/* Timestamp for incoming messages */
#endif
int fromlen = sizeof from;	/* Length of above address (for recvfrom) */
int application;		/* Socket for listening to requests */
char host_name[MAXNAMELENGTH];		/* Name of local host  */
struct sockaddr_in local_inaddr;	/* Address of local host */

static int time_out;		/* Timeout for load polling broadcast */

static float idle_host;		/* Limit for considering host idle */
static int swap_validity;	/* Load of swap-server is added at this percentage */
static int minimum_top;		/* Minimum number of top-hosts when top-list is to be considered */
static int improvment;		/* Percentage by which the load index of selected host must be lower than local index */
static strategy strat;		/* Host selection strategy */
static int loadpolling;		/* TRUE if loadpolling is to be perfirmed */
static int poll_timeout;	/* Timeout-interval for polling in *microseconds* */


void
print_host_list ()
{
  struct hostent *name;
  int count = 0;
  for (help = host_list; help != NULL && count < number_of_hosts; count++, help = help->next_host)
  {
    name = gethostbyaddr ((char *) &help->host.sin_addr, sizeof (help->host.sin_addr), AF_INET);
    printf ("Client name: %s, alpha: %f, load: %f\n", name->h_name, help->alpha, help->load);
    if (help->is_dummy)
    {
      printf (" is dummy\n");
    }
    if (help->is_top)
    {
      printf (" is top\n");
    }

    if (help->swap_serv != &swap_dummy)
    {
      name = gethostbyaddr ((char *) &help->swap_serv->host.sin_addr, sizeof (help->host.sin_addr), AF_INET);
      printf (" server name: %s\n", name->h_name);
    }

  }
  if (local_host)
  {
    name = gethostbyaddr ((char *) &local_host->host.sin_addr, sizeof (local_host->host.sin_addr), AF_INET);
    printf ("local host name: %s\n", name->h_name);
  }
}

/*
 * Inserts host into host-list
 */


void
handle_SIGALRM (void)
{
  time_out = TRUE;
  #ifdef UNIX
   signal (SIGALRM, handle_SIGALRM);
   #endif
}

void
readsysconfig (void)
{
  system_config local_system_config;
  int linenr;

  switch (open_config (&linenr))
  {
  case ERR_CFDB_OPEN:
    fprintf (stderr, "Cant open configuration file\n");
    exit (-1);
    break;
  case OK_CFDB:
    break;
  default:
    fprintf (stderr, "Error at line %d in configuration file", linenr);
    exit (-1);
    break;
  }

  if (read_system_config (&local_system_config) != OK_CFDB)
  {
    fprintf (stderr, "Cant read system configuration.\n");
    exit (-1);
  }

  /* For each configuration parameter check if it has value. If not use the default value */

  if (!is_missval (TYPE_IDLE_HOST, (void *) &local_system_config.idle_host))
  {
    idle_host = local_system_config.idle_host;
  }
  else
  {
    idle_host = DEFAULT_IDLE_HOST;
  }

  if (!is_missval (TYPE_SWAP_VALIDITY, (void *) &local_system_config.swap_validity))
  {
    swap_validity = local_system_config.swap_validity;
  }
  else
  {
    swap_validity = DEFAULT_SWAP_VALIDITY;
  }

  if (!is_missval (TYPE_LOADPOLLING, (void *) &local_system_config.loadpolling))
  {
    loadpolling = local_system_config.loadpolling;
  }
  else
  {
    loadpolling = DEFAULT_LOADPOLLING;
  }

  if (!is_missval (TYPE_STRATEGY, (void *) &local_system_config.strategy))
  {
    strat = local_system_config.strategy;
  }
  else
  {
    strat = DEFAULT_STRATEGY;
  }

  if (!is_missval (TYPE_IMPROVMENT, (void *) &local_system_config.improvment))
  {
    improvment = local_system_config.improvment;
  }
  else
  {
    improvment = DEFAULT_IMPROVMENT;
  }

  if (!is_missval (TYPE_MINIMUM_TOP, (void *) &local_system_config.minimum_top))
  {
    minimum_top = local_system_config.minimum_top;
  }
  else
  {
    minimum_top = DEFAULT_MINIMUM_TOP;
  }
/*
   if( !is_missval(TYPE_TIMEOUT, (void *)&local_system_config.timeout ) ) {
   timeout = local_system_config.timeout;
   }
   else {
   timeout = DEFAULT_TIMEOUT;
   }
 */
  if (!is_missval (TYPE_POLL_TIMEOUT, (void *) &local_system_config.poll_timeout))
  {
    poll_timeout = local_system_config.poll_timeout;
  }
  else
  {
    poll_timeout = DEFAULT_POLL_TIMEOUT;
  }

  if (local_system_config.statistics == TRUE)
  {
    stats_on ();
  }
  else
  {
    stats_off ();
  }

  close_config ();

  if (loadpolling)
  {

#ifdef UNIX
    signal (SIGALRM, handle_SIGALRM);
#endif
  }
  else
  {
	  
#ifdef UNIX
    /*signal (SIGALRM, SIG_DFL);*/
    signal (SIGALRM, SIG_IGN);
#endif
  }


}

/*
 * Insert a host in the top-list
 */
inline void
insert_top (load_indices * host)
{
  host->next_top = top;
  if (top)
  {				/* Top-list not empty */
    top->prev_top = host;
  }
  top = host;
  host->prev_top = NULL;
  host->is_top = TRUE;
  top_hosts++;
}

/*
 * Remove a host from the top-list
 */
inline void
remove_top (load_indices * host)
{
  if (top == host)
  {				/* First element in list */
    top = host->next_top;
    if (top)
    {
      top->prev_top = NULL;
    }
    host->next_top = host->prev_top = NULL;
    host->is_top = FALSE;
    top_hosts--;
  }
  else
  {				/* Element inside list */
    if (host->next_top)
    {				/* Not last element in top-list */
      host->next_top->prev_top = host->prev_top;
    }
    host->prev_top->next_top = host->next_top;
    host->next_top = host->prev_top = NULL;
    host->is_top = FALSE;
    top_hosts--;

  }
}


/*
 * Simulate a circular list
 */
load_indices *
next_host (load_indices * in_host)
{
  return (in_host->next_host ? in_host->next_host : host_list);
}

/*
 * Check if host-list is empty
 */
int
is_empty (load_indices * list)
{
  return (list == NULL ? TRUE : FALSE);
}

/*
 * Get a specified host from host-list
 */
load_indices *
get_host (struct hostent * in_host_ent)
{
  load_indices *local_list = host_list;
#ifdef VERBOSE
  fprintf (stderr, "get_host\n");
#endif
  while (!is_empty (local_list))
  {

#ifdef WIN32
	  if (memcmp (&local_list->host.sin_addr, in_host_ent->h_addr_list[0], in_host_ent->h_length) == 0)
#endif
		  
#ifdef UNIX 
	  if (memcmp (&local_list->host.sin_addr, in_host_ent->h_addr_list[0], in_host_ent->h_length) == 0)
	 /*if (bcmp (local_list->host.sin_addr, in_host_ent->h_addr_list[0], in_host_ent->h_length) == 0)*/
	 /*if (bcmp (local_list->host.sin_addr, in_host_ent->h_addr, in_host_ent->h_length) == 0)*/
#endif
	 {
      return (local_list);
    }
    else
    {
      local_list = local_list->next_host;
    }
  }

  return ((load_indices *) NULL);
}

/*
 * Remove a specified host
 */
void
remove_host (load_indices ** in_out_list, load_indices * in_host)
{

  if (is_empty (*in_out_list))
  {
    ;
  }
  else if (*in_out_list == in_host)
  {
    number_of_hosts--;
#ifdef VERBOSE
    fprintf (stderr, "number_of_hosts = %d\n", number_of_hosts);
#endif
    *in_out_list = in_host->next_host;

  
    in_host->next_host = NULL;
    if (in_host->is_top)
    {
      remove_top (in_host);
    }

    if (in_host->swap_serv != &swap_dummy)
    {
      if (--(in_host->swap_serv->clients) == 0 && in_host->swap_serv->is_dummy)
      {
	remove_host (&host_list, (in_host)->swap_serv);
	free ((in_host)->swap_serv);
      }
    }
  }
  else
  {
    remove_host (&(*in_out_list)->next_host, in_host);
  }
}

/*
 * Insert a host in the host-list
 */
void
insert_host (load_indices ** in_out_list, load_indices * in_host)
{
  if (is_empty (*in_out_list))
  {
    number_of_hosts++;
#ifdef VERBOSE
    fprintf (stderr, "number_of_hosts = %d\n", number_of_hosts);
#endif
    *in_out_list = in_host;

    in_host->next_host = NULL;
  }
  else if (in_host->alpha < (*in_out_list)->alpha)
  {
    number_of_hosts++;
#ifdef VERBOSE
    fprintf (stderr, "number_of_hosts = %d\n", number_of_hosts);
#endif
    in_host->next_host = *in_out_list;
    *in_out_list = in_host;
  }
  else
  {
    insert_host (&(*in_out_list)->next_host, in_host);
  }
}

/*
 * Create a new dummy swap server
 */
load_indices *
new_dummy (struct hostent *in_host_ent)
{
  load_indices *new;
  new = (load_indices *) malloc (sizeof (load_indices));
#ifdef WIN32
  memcpy ((char *) &new->host.sin_addr,in_host_ent->h_addr_list[0],  in_host_ent->h_length);
#endif
  
#ifdef UNIX
  bcopy (in_host_ent->h_addr_list[0], (char *) &new->host.sin_addr, in_host_ent->h_length);
#endif
 
#ifdef WIN32
  if (memcmp (&new->host.sin_addr, &local_inaddr.sin_addr, sizeof (local_inaddr.sin_addr)) == 0)
#endif
	  
#ifdef UNIX
	  if (bcmp (&new->host.sin_addr, &local_inaddr.sin_addr, sizeof (local_inaddr.sin_addr)) == 0)
#endif
	  {
    local_host = new;
  }

  new->next_host = NULL;
  new->next_top = NULL;
  new->prev_top = NULL;
  new->swap_serv = &swap_dummy;
  new->is_top = FALSE;
  new->is_dummy = TRUE;
  new->is_dead = FALSE;

  new->avail = FALSE;

  new->alpha = 0.0;
  new->clients = 0;
  new->load = 0.0;

  insert_host (&host_list, new);

  return (new);
}

/*
 * Read the host configuration for a specified host
 */
void
readhostconfig (load_indices * new, char *host_name)
{
  host_config local_host_config;
  struct hostent *local_swap_ent;
  int ret;

  if (open_config ((int *) NULL) != OK_CFDB)
  {
#ifdef VERBOSE
    printf ("readhostconfig: cant open db\n");
#endif
  }

  ret = read_host_config (&local_host_config, host_name);
  (void) close_config ();

  if (ret == OK_CFDB && !is_missval (TYPE_ALPHA, (void *) &local_host_config.alpha))
  {
    new->alpha = local_host_config.alpha;
  }
  else
  {
    new->alpha = DEFAULT_ALPHA;
  }

  if (ret == OK_CFDB && !is_missval (TYPE_SWAP_SERVER, (void *) &local_host_config.swap_server))
  {
    local_swap_ent = gethostbyname (local_host_config.swap_server);
    if (local_swap_ent)
    {
      if ((new->swap_serv = get_host (local_swap_ent)))
      {
	;
      }
      else
      {
	new->swap_serv = new_dummy (local_swap_ent);
      }
      new->swap_serv->clients++;
    }
    else
    {
      new->swap_serv = &swap_dummy;
    }
  }
  else
  {
    new->swap_serv = &swap_dummy;
  }
}

/*
 * Fill in the configuration for a dummy swap server
 */
void
fill_in_dummy (load_indices * in_out_host)
{
  struct hostent *local_host_ent;
  local_host_ent = gethostbyaddr ((const char *)&in_out_host->host.sin_addr, sizeof (in_out_host->host.sin_addr), AF_INET);

  remove_host (&host_list, in_out_host);
  readhostconfig (in_out_host, local_host_ent->h_name);

  in_out_host->is_dummy = FALSE;
  in_out_host->avail = TRUE;
  in_out_host->is_dead = FALSE;

  insert_host (&host_list, in_out_host);
}

/* 
 * Create a new host entry and insert it in the host-list
 */
load_indices *
new_host (struct hostent *in_host_ent)
{

  load_indices *new;

#ifdef VERBOSE
  fprintf (stderr, "Host = %s\n", in_host_ent->h_name);
#endif
  new = (load_indices *) malloc (sizeof (load_indices));
#ifdef WIN32
  memcpy ((char *) &new->host.sin_addr,in_host_ent->h_addr_list[0], in_host_ent->h_length);
#endif
  
#ifdef UNIX
  bcopy (in_host_ent->h_addr_list[0], (char *) &new->host.sin_addr, in_host_ent->h_length);
#endif
#ifdef WIN32
  if (memcmp (&new->host.sin_addr, &local_inaddr.sin_addr, sizeof (local_inaddr.sin_addr)) == 0)
#endif
	  
#ifdef UNIX 
 if (bcmp (&new->host.sin_addr, &local_inaddr.sin_addr, sizeof (local_inaddr.sin_addr)) == 0)
#endif
  {
    local_host = new;
  }

  new->next_host = NULL;
  new->next_top = NULL;
  new->prev_top = NULL;
  new->swap_serv = &swap_dummy;
  new->is_top = FALSE;
  new->is_dummy = FALSE;
  new->is_dead = FALSE;

  /* 20.02.94 */
  new->avail = TRUE;

  readhostconfig (new, in_host_ent->h_name);

  new->clients = 0;

  insert_host (&host_list, new);

  return (new);
}


void
insert_into_lists ()

{
  int count = 0;
  static load_indices *help;

  for (help = host_list;
       (help) && (help->host.sin_addr.s_addr != host.sin_addr.s_addr) && (count < number_of_hosts);
       count++, help = help->next_host);


  if (count == number_of_hosts)
  {
    help = new_host (gethostbyaddr ((const char *)&host.sin_addr, sizeof (host.sin_addr), AF_INET));
  }
  else if (help->is_dummy)
  {
    fill_in_dummy (help);
  }
  else if (help->is_dead)
  {
    help->is_dead = FALSE;
  }
  /*
   * Update pointers of top-list etc.
   */

  /* Host was not in top-list and is now top */

  if ((!help->is_top) && ((load.data_load + SWAPLOAD (help)) < idle_host && load.data_avail))
  {
    insert_top (help);
  }

  else if ((help->is_top) && ((load.data_load + SWAPLOAD (help)) >= idle_host || !load.data_avail))
  {
    /* Host was on top-list and is no longer idle */
    remove_top (help);
  }

  /*
   * Update loadinfo and timestamp
   */

  help->load = load.data_load;
  help->avail = load.data_avail;
#ifdef WIN32
  help->timestamp = *incoming;
#endif
  
#ifdef UNIX
  help->timestamp = incoming;
#endif
}


#ifdef WIN32
inline int
is_up (load_indices * host, struct tm *timestamp)
#endif

#ifdef UNIX 
inline int
is_up (load_indices * host, struct timeval *timestamp)
#endif
{
  if (host == local_host)
  {
    /*
     * The local host is always up
     */
    return (TRUE);
  }
  else if (host->is_dummy || host->is_dead)
  {
    /*
     * A dummy swap server or a down host is always down
     */
    return (FALSE);
  }
  else 
#ifdef WIN32
	  if (timestamp->tm_sec - host->timestamp.tm_sec 
	   < MAX_MISSING_UPDATES * UPDATE)
  #endif
	   
#ifdef UNIX
	   if (timestamp->tv_sec - host->timestamp.tv_sec 
	   < MAX_MISSING_UPDATES * UPDATE)
#endif
	   {
    /*
     * If the host has sent a load update the last
     * MAX_MISSING_UPDATES * UPDATE seconds
     * is considered to be up
     */
    return (TRUE);
  }
  else
  {
    /*
     * Otherwise the host is considered down
     */
    if (host->is_top)
    {
      remove_top (host);
    }
    host->is_dead = TRUE;
    return (FALSE);
  }
}


/*
 * Polls for load indices. Uses timeout-value to stop waiting for
 * incoming load-indices. Updates the top-list and the list of
 * load-indices per host
 */

void
poll_for_load ()
{
  static rpc_message poll =
  {LOAD_POLL, MAGIC};		/* Poll for new load-infos */
  static int pollength = sizeof (rpc_message);	/* Length of poll message */
  static fd_set l_readfds;	/* Local set of sockets to listen to */
#ifdef WIN32
  static struct tm *previous_poll;
  static struct tm  *current_poll;
  time_t ltime;
#endif
  
#ifdef UNIX
  static struct timeval previous_poll;
  static struct timeval current_poll;
#endif
  static stats_poll_timeout poll_timeout_info;
  static int first_run = TRUE;
	fprintf (stderr,"entered in poll_for_load\n"); /*5.9.99*/
  /*
   * When we come up, we need the complete load-information
   */

  if (first_run)
  {
    /*
     * The first run is a broadcast force when the system is comming up
     */

#ifdef WIN32
		time(&ltime);
		previous_poll=gmtime(&ltime);
#endif
#ifdef UNIX
    gettimeofday (&previous_poll, (struct timezone *) 0);
   
#endif
 poll.kind = BROADCAST_FORCE;

    /*
     * Send poll to all load-daemon in the system
     */

fprintf (stderr,"sent request for forced broadcast\n"); /*5.9.99*/

    if (sendto (daemon, (char *) &poll, pollength, 0, (struct sockaddr *) &remote, sizeof (struct sockaddr_in)) < 0)
    {
#ifdef WIN32
	fprintf(stderr,"Load-Manager: Error in sending forced broadcast: %d \n", GetLastError());
#endif
	
#ifdef UNIX
      syslog (LOG_ERR, "Load-Manager: Error in sending forced broadcast: %m");
#endif
    }

    first_run = FALSE;
  }
  else if (loadpolling)
  {
    /*
     * Only poll for load if the configuration says so (loadpolling == TRUE)
     */
#ifdef WIN32
		time(&ltime);
		current_poll=gmtime(&ltime);
#endif
		
#ifdef UNIX
    gettimeofday (&current_poll, (struct timezone *) 0);
#endif

#ifdef WIN32
    if ((current_poll->tm_sec - previous_poll->tm_sec) >= UPDATE)
#else
		if ((current_poll.tv_sec - previous_poll.tv_sec) >= UPDATE)
#endif
		{
      /*
       * Only send a load broadcast request if it was not
       * done the within the last UPDATE seconds
       */
      previous_poll = current_poll;
      /*
       * Send poll to all load-daemon in the system
       */

      if (sendto (daemon, (char *) &poll, pollength, 0, (struct sockaddr *) &remote, sizeof (struct sockaddr_in)) < 0)
      {
#ifdef WIN32
	fprintf(stderr,"Load-Manager: Error sending poll for load: %d \n", GetLastError());
#endif
	
#ifdef UNIX
      syslog (LOG_ERR, "Load-Manager: Error sending poll for load: %m");
#endif
	  }

      /*
       * Wait poll_timeout msec for incoming load-info. Set timer for poll_timeout msec
       */


      time_out = FALSE;
#ifdef WIN32
	  SetTimer(NULL,0,poll_timeout,GenerateConsoleCtrlEvent(SIGTERM,_getpid()));
#endif
	  
#ifdef UNIX
      ualarm (poll_timeout, 0);
#endif
      poll_timeout_info.answers = 0;
      while (!time_out)
      {

	/*
	 * Init filedescriptor-sets for select (add daemon socket to l_readfds)
	 */

	FD_ZERO (&l_readfds);
	FD_SET (daemon, &l_readfds);

	/*
	 * Select on daemon socket (blocks at most poll_timeout microseconds)
	 * because we get a timeout-event after poll_timeout mircoseconds
	 */

	select (MAXWIDTH, &l_readfds, (fd_set *) 0, (fd_set *) 0, (struct timeval *) 0);

	/*
	 * Examine socket
	 */

	if (FD_ISSET (daemon, &l_readfds) && !time_out)
	{


	  /*
	   * Get load-message
	   */

	  if (recvfrom (daemon, (char *) &load, sizeof (rpc_message), 0, (struct sockaddr *) &host, &namelength) < 0)
	  {
	    perror ("examining polled socket");
	    continue;
	  }

	  /* 01.03.94 */
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#endif
		
#ifdef UNIX
	  gettimeofday (&incoming, (struct timezone *) 0);
#endif
	  /*
	   * Check magic number and kind of message (poor authentication !)
	   */

	  if ((load.kind == LOAD_BROADCAST) && (load.magic_number == MAGIC))
	  {

	fprintf (stderr,"Loadmanager:LOAD_BROADCAST info received:will insert load in the list\n"); /*5.9.99*/
	    /*
	     * Message seems to be OK. Update local load-info structure
	     */

	    poll_timeout_info.answers++;
	    insert_into_lists ();

	  }
	}
      }
    }
    /*
     * Write statistics
     */
    poll_timeout_info.poll_timeout = poll_timeout;
    stats_write (STATS_TYPE_POLL_TIMEOUT, (stats_info *) & poll_timeout_info);
  }
}



/*
 * Sends an error-message to calling application
 */

void
reply_error (code)

     int code;

{
  /*
   * Set appropriate message-type and error-code and send
   * error-message back to application
   */

  appl_reply.kind = APPLICATION_ERROR;
  appl_reply.data_error = code;

  if (sendto (application, (char *) &appl_reply, sizeof (rpc_message), 0, (struct sockaddr *) &from, fromlen) < 0)
  {
#ifdef WIN32
	fprintf(stderr,"Load-Manager: Error in replying to application: %d \n", GetLastError());
#endif

#ifdef UNIX
      syslog (LOG_ERR, "Load-Manager: Error in replying to application: %m");
#endif
  }

}



void
handle_SIG_CONFIG_READ (void)
{
  readsysconfig ();
}


/*  
The response is an IP packet. We must decode the IP header to locate  
the ICMP data  
*/ 

/* The IP header */ 
typedef struct iphdr { 
unsigned int h_len:4;          /* length of the header */
unsigned int version:4;        /* Version of IP */
unsigned char tos;             /* Type of service */
unsigned short total_len;      /* total length of the packet */
unsigned short ident;          /* unique identifier */
unsigned short frag_and_flags; /* flags */
unsigned char  ttl;  
unsigned char proto;           /* protocol (TCP, UDP etc) */
unsigned short checksum;       /* IP checksum */
 unsigned int sourceIP; 
unsigned int destIP; 
 }IpHeader; 
 

#ifdef UNIX 
#define BYTE int
#define USHORT unsigned short
#define ULONG unsigned long
#endif
typedef struct _ihdr { 
  BYTE i_type; 
  BYTE i_code; 
  USHORT i_cksum; 
  USHORT i_id; 
  USHORT i_seq; 
#ifdef WIN32
    ULONG timestamp; 
#endif
#ifdef UNIX
    time_t timestamp; 
#endif
}IcmpHeader; 

#define ICMP_ECHO 8 
#define ICMP_ECHOREPLY 0 
#define ICMP_MIN 8 /* minimum 8 byte icmp packet (just header) */
#define DEF_PACKET_SIZE 32 
#define WT_NET 2 /*weightage given to network response time*/

int  decode_resp(char *buf, int bytes,struct sockaddr_in *from) { 
 
IpHeader *iphdr; 
IcmpHeader *icmphdr; 
unsigned short iphdrlen; 
 
iphdr = (IpHeader *)buf; 
 
iphdrlen = (iphdr->h_len) * 4 ; /* number of 32-bit words *4 = bytes */
 
if (bytes  < iphdrlen + ICMP_MIN) { 
printf("Too few bytes from %s\n",inet_ntoa(from->sin_addr)); 
} 
 
icmphdr = (IcmpHeader*)(buf + iphdrlen); 
 
if (icmphdr->i_type != ICMP_ECHOREPLY) { 
fprintf(stderr,"non-echo type %d recvd\n",icmphdr->i_type); 
return; 
} 
#ifdef WIN32
if (icmphdr->i_id != (USHORT)GetCurrentProcessId()) { 
#endif
#ifdef UNIX
if (icmphdr->i_id != getpid()) { 
#endif
fprintf(stderr,"someone else's packet!\n"); 
return ; 
} 
#ifdef WIN32
 return (GetTickCount()-icmphdr->timestamp); 
#endif
#ifdef UNIX
 return (60*(time(NULL)-icmphdr->timestamp)); 
#endif

} 
 
 
USHORT checksum(USHORT *buffer, int size) { 
 
  unsigned long cksum=0; 
 
  while(size >1) { 
cksum+=*buffer++; 
size -=sizeof(USHORT); 
  } 
   
  if(size ) { 
cksum += *(UCHAR*)buffer; 
  } 
 
  cksum = (cksum >> 16) + (cksum & 0xffff); 
  cksum += (cksum >>16); 
  return (USHORT)(~cksum); 
} 

/*  
Helper function to fill in various stuff in our ICMP request. 
*/ 
void fill_icmp_data(char * icmp_data, int datasize){ 
 
  IcmpHeader *icmp_hdr; 
  char *datapart; 
 
  icmp_hdr = (IcmpHeader*)icmp_data; 
 
  icmp_hdr->i_type = ICMP_ECHO; 
  icmp_hdr->i_code = 0; 
  #ifdef WIN32
	icmp_hdr->i_id = (USHORT)GetCurrentProcessId(); 
#endif
  #ifdef UNIX
	icmp_hdr->i_id = getpid();
#endif
  icmp_hdr->i_cksum = 0; 
  icmp_hdr->i_seq = 0; 
   
  datapart = icmp_data + sizeof(IcmpHeader); 
  /* 
  // Place some junk in the buffer. 
  */ 
  memset(datapart,'E', datasize - sizeof(IcmpHeader)); 
 
} 



int getNetDelay(struct sockaddr_in dest){

 SOCKET sockRaw; 
  struct sockaddr_in from; 
  int bread,datasize; 
  int fromlen = sizeof(from); 
  int timeout = 1000; 
  char dest_ip; 
  char *icmp_data; 
  char recvbuf; 
USHORT seq_no = 0; 
 
 
 #ifdef WIN32
	sockRaw = socket (AF_INET,   SOCK_RAW,   IPPROTO_ICMP,    NULL, 0,0); 
 #endif
#ifdef UNIX
	sockRaw = socket (AF_INET,   SOCK_RAW,   IPPROTO_ICMP); 
 #endif
 
  dest_ip = inet_ntoa(dest.sin_addr); 
 
 datasize = DEF_PACKET_SIZE; 
 
   datasize += sizeof(IcmpHeader);   
 
  icmp_data = malloc(sizeof(char)*1024); 
  recvbuf = malloc(sizeof(char)*1024); 
 
  memset(icmp_data,0, sizeof(char)*1024); 
  fill_icmp_data(icmp_data,datasize); 
 
  while(1) { 
int bwrote; 
 
((IcmpHeader*)icmp_data)->i_cksum = 0; 
#ifdef WIN32
((IcmpHeader*)icmp_data)->timestamp = GetTickCount(); 
#endif
#ifdef UNIX
((IcmpHeader*)icmp_data)->timestamp = time(NULL);
#endif

 
((IcmpHeader*)icmp_data)->i_seq = seq_no++; 
((IcmpHeader*)icmp_data)->i_cksum = checksum((USHORT*)icmp_data,  datasize); 
 
bwrote = sendto(sockRaw,icmp_data,datasize,0,(struct sockaddr*)&dest, 
sizeof(dest)); 

bread = recvfrom(sockRaw,recvbuf,1024,0,(struct sockaddr*)&from, 
 &fromlen); 
return decode_resp(recvbuf,bread,&from); 
} 
}

 

#ifdef WIN32
HANDLE  hServerStopEvent = NULL; 

VOID ServiceStop() 
{ 
    if ( hServerStopEvent ) 
        SetEvent(hServerStopEvent); 
} 
#endif



#ifdef WIN32
VOID ServiceStart (DWORD argc, LPTSTR *argv) 
#endif
#ifdef UNIX
int main (int argc, char *argv[])
#endif
{
  struct hostent *local_address;	/* Internet-Address of local host  */
  int ldaemon;			/* Port of load-daemon */
  struct servent *get_ports;	/* Structure to get port of load-daemon 
				   and load-manager */
#ifdef WIN32
  struct sockaddr_in requested;	/* UNIX domain socket name */
   int on = TRUE;                   /* Flag used to set in_socket into SO_REUSEADDR-mode */
	WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/
	time_t ltime;
#endif
  
#ifdef UNIX
  struct sockaddr_un requested;	/* UNIX domain socket name */
#endif
   struct sockaddr_in local;	/* Address of local socket */
  fd_set readfds;		/* Descriptor-set for reading 
				   (used by select) */
  rpc_message appl_request;	/* Buffer for incoming requests */
  long index;			/* Randomized index in top-list */
  int length = sizeof (host_name);	/* Length of local hostname  */
  int lmanager;			/* Port of load-manager */
  #ifdef WIN32
int lapplication; /*aded on 4.12 to replace AF_UNIX*/
#endif
  int count;
  int ret;			/* Return-Value of system-calls */
#ifdef MEASUREMENTS
#ifdef UNIX
  struct timeval m_time =
  {(long) 20, (long) 0};	/* Timeout-interval during measurements */
#endif
#endif /* MEASUREMENTS */

  /*
   * Initialize system
   */
#ifdef WIN32
 	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    		return;
	}
  fprintf(stderr,"Load-Manager: starting up.\n");
#endif
#ifdef UNIX
  OPENLOG (myname);
#endif
  /*
   * Get host name and Internet-Address
   */

  if (gethostname (host_name, length) != 0)
    exit (1);

  if (!(local_address = gethostbyname (host_name)))
    exit (1);

  /*
   * We determine the local internet-address and store it for quick reply
   * to APPLICATION_REQUEST in case that the local host is top.
   */

#ifdef WIN32
  memcpy ((char *) &local_inaddr.sin_addr,(char *) local_address->h_addr_list[0], local_address->h_length);
#else
  bcopy ((char *) local_address->h_addr_list[0], (char *) &local_inaddr.sin_addr, local_address->h_length);
#endif
  local_inaddr.sin_family = AF_INET;

  /*
   * Init default swap-server's load with 0. This dummy is used to
   * avoid checking the swap_serv pointer of each host_list entry
   * before returning its load. 
   */

  swap_dummy.load = 0.0;

  /*
   * Read hosts from configuration file
   */
  readsysconfig ();

  /*
   * Install signal handler for SIG_CONFIG_READ (SIG_CONFIG_READ
   * is defined in system.h)
   */

#ifdef WIN32
	SetConsoleCtrlHandler(SIG_CONFIG_READ, handle_SIG_CONFIG_READ);
#else
	signal (SIG_CONFIG_READ, handle_SIG_CONFIG_READ);
#endif
  /*
   * Get port number for services "ldaemon" and "lmanager"
   */

  get_ports = getservbyname (DAEMON_SERVICE, "udp");

  ldaemon = get_ports->s_port;

  get_ports = getservbyname (LOMA_SERVICE, "udp");

  lmanager = get_ports->s_port;

  #ifdef WIN32
	get_ports = getservbyname ("application","udp");

  lapplication=get_ports->s_port;
#endif

  /*
   * Open Internet-Domain-Socket for polling/receiving load info 
   */

  daemon = socket (AF_INET, SOCK_DGRAM, 0);

  if (daemon < 0)
  {
#ifdef WIN32
		fprintf(stderr,"Load-Manager: Error opening socket: %d \n", GetLastError());
#else
      syslog (LOG_ERR, "Load-Manager: Error opening socket: %m");
#endif
	  exit (1);
  }

  /*
   * Bind name to manager-socket
   */

  local.sin_family = AF_INET;
  local.sin_port = lmanager;
  local.sin_addr.s_addr = INADDR_ANY;
	#ifdef WIN32
		setsockopt(daemon, SOL_SOCKET, SO_REUSEADDR, &on, sizeof (on));
	#endif
	
   if (bind (daemon, (struct sockaddr FAR *) &local, sizeof local) < 0)
  {
#ifdef WIN32
	fprintf(stderr,"Load-Manager: Error binding local socket: %d \n", GetLastError());
#else
      syslog (LOG_ERR, "Load-Manager: Error binding local socket: %m");
#endif
	  exit (1);
  }

  /*
   * Change directory
   */
#ifdef WIN32
  if (CreateDirectory(YALB_PATH,NULL)==TRUE && GetLastError()!=ERROR_ALREADY_EXISTS){
	   fprintf(stderr,"Load-Manager:Failure in Creating directory : %d \n", GetLastError());
		exit(-1);
  }
  	if (!SetCurrentDirectory(YALB_PATH) )
			exit(-1);
#endif

#ifdef UNIX  
  if (mkdir(YALB_PATH,0755) < 0 && errno != EEXIST) {
    syslog(LOG_ERR, "Load-Manager: YALB-directory not creatable! : %m");
    exit(-1);
	}
  if (chdir(YALB_PATH) < 0) {
    syslog(LOG_ERR, "Load-Manager: YALB-directory not accessable! : %m");
    exit(-1);
  }
#endif
  /*
   * Get broadcast address 
   */

#ifdef WIN32
  memcpy ((char *) &remote.sin_addr,(char *) local_address->h_addr_list[0],  local_address->h_length);
#else
  bcopy ((char *) local_address->h_addr_list[0], (char *) &remote.sin_addr, local_address->h_length);
#endif
  remote.sin_family = AF_INET;
  remote.sin_port = ldaemon;

  /* Local hack !! */
  /*changed on 6.9.99 remote.sin_addr.s_addr = (remote.sin_addr.s_addr & BROADCAST_MASK) | ~BROADCAST_MASK;*/

  /*
   * Open UNIX domain socket 
   */
#ifdef WIN32
  application = socket (PF_INET, SOCK_DGRAM, 0);
#else 
  application = socket (AF_UNIX, SOCK_DGRAM, 0);
#endif
  
  if (application < 0)
  {
#ifdef WIN32
		fprintf(stderr,"Load-Manager: Error opening application socket: %d \n", GetLastError());
#else
      syslog (LOG_ERR, "Load-Manager: Error opening application socket: %m");
#endif
	  exit (1);
  }

  /*
   * Bind name to socket
   */


#ifdef WIN32
  requested.sin_family = AF_INET;
  requested.sin_port = lapplication;/*4.12*/
  requested.sin_addr.s_addr = INADDR_ANY;  
	setsockopt(application, SOL_SOCKET, SO_REUSEADDR, &on, sizeof (on));
#endif
  
#ifdef UNIX
	unlink (UNIX_SOCKET);
	requested.sun_family = AF_UNIX;
	strcpy (requested.sun_path, UNIX_SOCKET);
	unlink (UNIX_SOCKET);
#endif

#ifdef WIN32
  if (bind (application, (struct sockaddr *) &requested, sizeof requested) < 0)
#endif
#ifdef UNIX
  if (bind (application, (struct sockaddr *) &requested, strlen(UNIX_SOCKET)+3) < 0)
#endif
  {
#ifdef WIN32
		fprintf(stderr,"Load-Manager: Error binding application socket: %d \n", GetLastError());
#endif
#ifdef UNIX
      syslog (LOG_ERR, "Load-Manager: Error binding application socket: %m");
#endif
	  exit (1);
  }

  /*
   * Init random number generator and local reply-time
   */
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
		srand((int) incoming->tm_sec);
#endif
#ifdef UNIX
	gettimeofday (&incoming, (struct timezone *) 0);
	srandom ((int) incoming.tv_usec);
#endif
  

  /*
   * Force update of load information
   */

  poll_for_load ();

  /*
   * Init reply-header with magic number
   */

  appl_reply.magic_number = MAGIC;


  /*
   * Listen to sockets for incoming packages (main loop)
   */

for (;;)
  {
#ifdef MEASUREMENTS
    do
    {

      /*
       * Init filedescriptor-sets for select (add both sockets to readfds)
       */

      FD_ZERO (&readfds);
      FD_SET (application, &readfds);
      FD_SET (daemon, &readfds);


      ret = select (MAXWIDTH, &readfds, (fd_set *) 0, (fd_set *) 0, &m_time);

    } while ((errno == EINTR) && (ret <= 0));
#else
    do
    {

      /*
       * Init filedescriptor-sets for select (add both sockets to readfds)
       */

      FD_ZERO (&readfds);
      FD_SET (application, &readfds);
      FD_SET (daemon, &readfds);

      /*
       * Select on both sockets (blocks indefinitely)
       */

      ret = select (MAXWIDTH, &readfds, (fd_set *) 0, (fd_set *) 0,
 		    (struct timeval *) 0);

    } while ((errno == EINTR) && (ret < 0));

#endif /* MEASUREMENTS */



    if (errno != EINTR && ret < 0)
    {
 #ifdef WIN32
				fprintf(stderr,"Load-Manager: Error in select: %d \n", GetLastError());
#endif
#ifdef UNIX
      syslog (LOG_ERR, "Load-Manager: Error in select: %m");
#endif
	  continue;
    }

#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#endif
#ifdef UNIX
    gettimeofday (&incoming, (struct timezone *) 0);
#endif

    /*
     * Check whether new load-infos arrived
     */

    if (FD_ISSET (daemon, &readfds))
    {

      /*
       * Get request-message
       */

      recvfrom (daemon, (char *) &load, sizeof (rpc_message), 
		0, (struct sockaddr *) &host, &namelength);
 
	fprintf (stderr, "Load manager: got a message from loaddaemon:\n");

      if ((load.kind == LOAD_BROADCAST) && (load.magic_number == MAGIC))
      {
	/*
	 * Message seems to be OK. Update local load-info structure
	 */
	fprintf (stderr, "Load manager: it was a broadcast message--updating loadlists\n");

	insert_into_lists ();

      }

      else if ((load.kind == CONFIG_READ_HOST) && (load.magic_number == MAGIC))
      {
	/*
	 * Request to read new host configuration
	 */
	load_indices *host;
	struct hostent *local_host_ent;
	fprintf (stderr, "Load manager: it was a request to read a new host configuration\n");
#ifdef VERBOSE
	fprintf (stderr, "Reading host config\n");
#endif
	local_host_ent = gethostbyaddr (&load.data.addr, sizeof (load.data.addr), AF_INET);

	host = get_host (local_host_ent);
	if (host && !host->is_dummy)
	{
	  remove_host (&host_list, host);
	  readhostconfig (host, local_host_ent->h_name);
	  insert_host (&host_list, host);
	}
      }
  }

    /*
     * Examine request-socket
     */

    if (FD_ISSET (application, &readfds))
    {
      /*
       * Get request-message
       */

      do
      {
	ret = recvfrom (application, (char *) &appl_request, 
			sizeof (rpc_message), 0, (struct sockaddr *) &from,
			&fromlen);
	fprintf (stderr, "Load manager: Got an application messages\n");
      } while ((errno == EINTR) && (ret < 0));

      if (ret < 0)
      {
#ifdef WIN32
		fprintf(stderr,"Load-Manager: Error in receiving data from application: %d \n", GetLastError());
#endif
#ifdef UNIX
		syslog (LOG_ERR, "Load-Manager: Error in receiving data from application: %m");
#endif
	  continue;
      }

      /*
       * Check magic number and kind of message (poor authentication !)
       */

      if (appl_request.magic_number == MAGIC)
      {

	if (appl_request.kind == APPLICATION_REQUEST)
	{
fprintf(stderr,"Received req for List of hosts\n");
	  /*
	   * Message seems to be OK. Check number of hosts requested 
	   */

	  if (appl_request.data_number <= 0)
	  {
	    reply_error (INVALID_NUMBER);
	  }
	  else
	  {
	    /*
	     * Poll for load
	     * XXX (schoenfr): don't poll. this makes loitz@ibr.cs.tu-bs.de
	     * unhappy.
	     * XXX: better - configure -loadpolling NO
	     */
	     poll_for_load ();

	    if (appl_request.data_hostlist[0].sin_addr.s_addr == ENDOFHOSTLIST 
		&& appl_request.data_number == 1)
	    {


	      /*
	       * Local host is idle, so return our own address to
	       * application if last return is older than LOCAL_REPLY sec.
	       */

 	fprintf (stderr, "Load manager: just befor using local_host\n");
	      if (local_host->avail 
		  && ((local_host->load + SWAPLOAD (local_host)) < idle_host))
	      {
#ifdef VERBOSE
		printf ("local host idle\n");
#endif
		appl_reply.kind = APPLICATION_REPLY;
		appl_reply.data_number = 1;
		appl_reply.data_hostlist[0] = local_inaddr;
		appl_reply.data_factor[0] = local_host->load + SWAPLOAD (local_host);

		sendto (application, (char *) &appl_reply,
			sizeof (rpc_message), 0, (struct sockaddr *) &from, 
			fromlen);
	      }

	      /*
	       * Simple case: No hosts are given and one host is requested
		*/
	       

	      else
	      {
		load_indices *selected_host = (load_indices *) 0;

		do
		{
		  switch (strat)
		  {
		  case TOPHOST:
		    {
		      /*
		       * Use strategy TOPHOST
		       */

		      float temp_load;

		      /*
		       * List of load-indices is updated because of periodic
		       * broadcast of loaddaemons. Now get requested host. We
		       * search for the fastest Host in the system.
		       */

		      for (help = host_list, count = 0, temp_load = MAXLOAD;
			   count < number_of_hosts; 
			   help = help->next_host, count++)
		      {
			if (temp_load >= help->load + SWAPLOAD (help)
			    && help->avail
			    && !help->is_dummy
			    && !help->is_dead)
			{
			  temp_load = help->load + SWAPLOAD (help);
			  selected_host = help;
			}
		      }
		      if (!selected_host)
		      {
			selected_host = local_host;
		      }

		    }
		    break;
		  case TOPLIST:
		    /*
		     * Use strategy TOPLIST
		     */
		    if (top_hosts >= minimum_top)
		    {		/* There are idle hosts */
		      /* Init pointer with beginning of top-list */
		      selected_host = top;
		      /* Find indexed member of top-list */
#ifdef WIN32
			   index = (rand () % (long) top_hosts);
#endif
#ifdef UNIX
		      index = (random () % (long) top_hosts);
#endif
			  for (; index > 0; index--)
		      {
			selected_host = selected_host->next_top;
		      }
		    }
		    else
		    {		/* No or not enough idle hosts available */
		      /*
		       * We get a random index and search the
		       * corresponding host in the hostlist. If his load
		       * is less than (local_load - THRESHOLD / 100), we
		       * return this host. Otherwise, we search the whole
		       * list for an appropriate host. If none is
		       * available, we have to execute locally, alas! 
		       */

		      /* Init pointer with beginning of host-list */

		      selected_host = host_list;

		      /* Find indexed member of host-list */

		      for (index = (rand () % number_of_hosts); 
			   index > 0; index--)
		      {
			selected_host = selected_host->next_host;
		      }
		      /*
		       * Did we find an appropriate host?
		       */
		      if (selected_host->is_dead 
			  || selected_host->is_dummy
			  || !selected_host->avail
			  || selected_host->load >= 
			     (float) (1 - (float) (improvment / 100.0)) 
			     * (local_host->load + SWAPLOAD (local_host)))
		      {
#ifdef VERBOSE
			printf ("no appropriate\n");
#endif
			/*
			 * If not, search for another
			 */
#ifdef VERBOSE
			printf (
			  "dead = %d, dummy = %d, avail = %d, load = %f\n",
				selected_host->is_dead,
				selected_host->is_dummy,
				selected_host->avail, selected_host->load);
#endif
			for (count = 0; (selected_host->is_dead ||
					 selected_host->is_dummy ||
					 !selected_host->avail ||
					 selected_host->load >=
				 (float) (1 - (float) (improvment / 100.0)) 
				 * (local_host->load + SWAPLOAD (local_host)))
			     && count < number_of_hosts;
			     selected_host = next_host (selected_host),
			     count++)
			{
#ifdef VERBOSE
			  printf ("count = %d ", count);
#endif
			}
			if (count == number_of_hosts)
			{
#ifdef VERBOSE
			  printf ("local host selected\n");
#endif
			  selected_host = local_host;
			}
			else
			{
#ifdef VERBOSE
			  printf ("local host NOT selected\n");
#endif
			}
		      }
		    }
		    break;
		  }		/* switch */

		  /*
		   * Repeat until we find a host that is up
		   */
		}
#ifdef WIN32
		while (!is_up (selected_host, incoming));
#endif
#ifdef UNIX
	while (!is_up (selected_host, &incoming));
#endif
		/*
		 * Send reply to calling application
		 */
		appl_reply.kind = APPLICATION_REPLY;
		appl_reply.data_number = 1;
		appl_reply.data_hostlist[0] = selected_host->host;
		appl_reply.data_factor[0] = selected_host->load + 
		    				SWAPLOAD (selected_host);

		sendto (application, (char *) &appl_reply, 
			sizeof (rpc_message), 0, (struct sockaddr *) &from, 
			fromlen);

		if (selected_host->is_top)
		{
		  remove_top (selected_host);
		}
		selected_host->avail = FALSE;

	      }			/* else */
	    }			/* if */
	  }			/* else */
	}			/* if */
	if (appl_request.kind == GET_FASTEST_HOST)
	{
	  /*
	   * Get the host with the smallest alpha
	   */
	  for (help = host_list; help; help = help->next_host)
	  {
	    if (help->avail && !help->is_dummy && !help->is_dead)
	      break;
	  }
	  if (!help)
	  {
	    /*
	     * If no host found, use the local host
	     */
	    help = local_host;
	  }

	  appl_reply.kind = APPLICATION_REPLY;
	  appl_reply.data_number = 1;
	  appl_reply.data_hostlist[0] = help->host;
	  appl_reply.data_factor[0] = help->load + SWAPLOAD (help);

	  sendto (application, (char *) &appl_reply, sizeof (rpc_message), 
		  0, (struct sockaddr *) &from, fromlen);

	}
	else if (appl_request.kind == PING)
	{
fprintf(stderr,"Received PING from application\n");
	  appl_reply.kind = PING_REPLY;
	  sendto (application, (char *) &appl_reply, sizeof (rpc_message), 
		  0, (struct sockaddr *) &from, fromlen);

	}

	else if (appl_request.kind == GET_ALL_HOSTS)
	{

	  /*
	   * Message seems to be OK. 
	   */

	  /*
	   * Poll for load
	   * XXX (schoenfr): don't poll. this makes loitz@ibr.cs.tu-bs.de
	   * unhappy.
	   * XXX: better - configure -loadpolling NO
	   */
	  poll_for_load ();


	  /* Init pointer with beginning of host-list */

	  index = 0;

	  appl_reply.kind = APPLICATION_REPLY;

	  for (help = host_list; help && index < number_of_hosts;
	       help = help->next_host)
	  {

	    appl_reply.data_hostlist[index] = help->host;
	    appl_reply.data_factor[index] = help->load + SWAPLOAD (help);

	    /*
	     * If last update of loadinfo for the considered host is too
	     * long ago, we presume that he is down...
	     */
#ifdef WIN32
	    if (!is_up (help, incoming))
#endif
#ifdef UNIX
			 if (!is_up (help, &incoming))
#endif
	    {
	      appl_reply.data.message.avail[index] = HOST_DOWN;
	    }
	    else if (!help->avail)
	    {
	      appl_reply.data.message.avail[index] = HOST_NOT_AVAIL;
	    }
	    else
	    {
	      appl_reply.data.message.avail[index] = HOST_AVAIL;
	    }

	    index++;
	  }


	  appl_reply.data_number = index;

	  /*
	   * Send reply to calling application
	   */

	  sendto (application, (char *) &appl_reply, sizeof (rpc_message), 
		  0, (struct sockaddr *) &from, fromlen);
	}
	/*The following case is added on 18.11.99 to illustrate ease of accommodating new strategies*/
	else if (appl_request.kind == GET_OPT_HOST)
	{
	  /*
	   * Get the optimum host
	   */

		/*Idea here is to put load on the local host unless it is loaded such that scheduling it on other host 
		may have better response time (taking into account network delay). We assume that network delay is function of 
		total network traffick. We also take care of that probability of loads being transfered to the 
		same lightly loaded node is minimum*/
		poll_for_load ();
                /*#ifdef UNIX
                signal(SIGALRM,SIG_IGN);
                #endif */
                        if (local_host->avail
		  && ((local_host->load + SWAPLOAD (local_host)) < idle_host))
	      {

				/*Note we are avoiding polling at this time*/

#ifdef VERBOSE
		printf ("local host idle, and hence job is run locally\n");
#endif
		appl_reply.kind = APPLICATION_REPLY;
		appl_reply.data_number = 1;
		appl_reply.data_hostlist[0] = local_inaddr;
		appl_reply.data_factor[0] = local_host->load + SWAPLOAD (local_host);

		sendto (application, (char *) &appl_reply,
			sizeof (rpc_message), 0, (struct sockaddr *) &from, 
			fromlen);
	      }

	      /*
	       * Simple case: No hosts are given and one host is requested
		*/
	       

	      else
	      {
		float temp_cmpl_time;
		struct load_indices *begin_selected_host;
		struct load_indices *selected_host = (load_indices *) 0;
		int num_selected_host=0;
				int netdelay=0;
			   
			   
				/*get network response time*/
			   
				if (number_of_hosts >2){ /*2-server means only local host is available--1 for itself other for its swapserver*/
					for (help = host_list, count = 0;count < number_of_hosts;help = help->next_host, count++){
						if (memcmp (&help->host.sin_addr, &local_inaddr, sizeof(struct sockaddr_in)) != 0)
							break;
					}

					netdelay=getNetDelay(help->host);
			   }
			   

			     /*poll_for_load ();*/

		      /*
		       * List of load-indices is updated because of periodic
		       * broadcast of loaddaemons. Now get one or a list of hosts with expected
			   * response time around  a small band.
		       */
				
			for (help = host_list, count = 0, temp_cmpl_time = MAXLOAD; count < number_of_hosts; help = help->next_host, count++) {
			if (temp_cmpl_time >= (help->load + SWAPLOAD (help))/help->alpha && help->avail && !help->is_dummy && !help->is_dead) {
			  temp_cmpl_time = (help->load + SWAPLOAD (help))/help->alpha;
			  selected_host = help;
			}
		      }

			if (local_host->avail && ((local_host->load + SWAPLOAD (local_host))/local_host->alpha < temp_cmpl_time+ WT_NET*netdelay)) {

			
#ifdef VERBOSE
		printf ("Here, it is advisable to run job locally as transfer may take long time due to network traffick\n");
#endif
		appl_reply.kind = APPLICATION_REPLY;
		appl_reply.data_number = 1;
		appl_reply.data_hostlist[0] = local_inaddr;
		appl_reply.data_factor[0] = local_host->load + SWAPLOAD (local_host);

		sendto (application, (char *) &appl_reply,
			sizeof (rpc_message), 0, (struct sockaddr *) &from,fromlen);
	      		continue; /*added on 11.12 **?? */
		}

			  /* Choose set of candidate receiver*/

			
	{
		int first_time=1;
		begin_selected_host=NULL;
		for (help = host_list, count = 0; count < number_of_hosts && (memcmp(&help->host.sin_addr,&local_host->host.sin_addr,4)!=0); help = help->next_host, count++) {
			if (temp_cmpl_time+netdelay >= (help->load + SWAPLOAD (help))/help->alpha && help->avail && !help->is_dummy && !help->is_dead) {
			num_selected_host++;
			  if (first_time) {
				begin_selected_host=help;
			  	selected_host= help;
				first_time=0;
			}
			else{
			  selected_host->next_selected=help;
			   selected_host=selected_host->next_selected;
			}
			}
	 	}
	 	if (selected_host!=NULL) selected_host->next_selected=NULL;
		selected_host=begin_selected_host;
	}

		     

	if (!selected_host) {
		appl_reply.kind = APPLICATION_REPLY;
		appl_reply.data_number = 1;
		appl_reply.data_hostlist[0] = local_inaddr;
		appl_reply.data_factor[0] = local_host->load + SWAPLOAD (local_host);

		sendto (application, (char *) &appl_reply,
			sizeof (rpc_message), 0, (struct sockaddr *) &from,fromlen);
	      		continue; /*added on 11.12 **?? */
			
	}
			 
		      {		
		      /*
		       *  Now we want to get a hst from the list of low loaded hosts (selected_host).
			   * To minimize the sam host being chosen by a number of heavy-loaded hosts 
			   * simultaneously, we select a random host from this list.
			   */

		       /* Find indexed member of host-list */

		      for (index = (rand () % num_selected_host); 
			   index > 0; index--)
		      {
			selected_host = selected_host->next_selected;
		      }
		      /*
		       * Did we find an appropriate host?
		       */
		      if (selected_host->is_dead || selected_host->is_dummy || !selected_host->avail || selected_host->load >= (float) (1 - (float) (improvment / 100.0)) * (local_host->load + SWAPLOAD (local_host))) {
#ifdef VERBOSE
			printf ("no appropriate\n");
#endif
			/*
			 * If not, search for another
			 */
#ifdef VERBOSE
			printf ( "dead = %d, dummy = %d, avail = %d, load = %f\n", selected_host->is_dead, selected_host->is_dummy, selected_host->avail, selected_host->load);
#endif
			for (count = 0 /*5.12*/; count < num_selected_host && (selected_host->is_dead || selected_host->is_dummy || !selected_host->avail || selected_host->load >= (float) (1 - (float) (improvment / 100.0)) * (local_host->load + SWAPLOAD (local_host))); selected_host = selected_host->next_selected, count++)
			{
#ifdef VERBOSE
			  printf ("count = %d ", count);
#endif
			}
			if (count == num_selected_host)
			{
#ifdef VERBOSE
			  printf ("local host selected\n");
#endif
			  selected_host = local_host;
			}
			else
			{
#ifdef VERBOSE
			  printf ("local host NOT selected\n");
#endif
			}
		      }
		    }
		   appl_reply.kind = APPLICATION_REPLY;
	  appl_reply.data_number = 1;
	  appl_reply.data_hostlist[0] = selected_host->host;
	  appl_reply.data_factor[0] = selected_host->load + SWAPLOAD (selected_host);

	  sendto (application, (char *) &appl_reply, sizeof (rpc_message), 
		  0, (struct sockaddr *) &from, fromlen);

	}
    /*#ifdef UNIX
    if (loadpolling) signal (SIGALRM, handle_SIGALRM);
else
	signal(SIGALRM,SIG_IGN);
        #endif*/
      } /*END OF GET_OPT_HOST*/
	 
	}
      
    }

    /*
     * Requests on both sockets served, so loop again
     */

  }				/* for(;;) */

  /*
   * Never reached
   */
  exit (0);
}