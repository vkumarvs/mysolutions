/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_stats_display.h,v 1.1 1994/03/07 10:32:20 carlsson Exp $
 * $Log: yalb_stats_display.h,v $
 * Revision 1.1  1994/03/07  10:32:20  carlsson
 * Added the fields `execute' and `send' in the structure `host_stats'.
 * Added declaration of funktion `stats_display_count()'.
 *
 * Revision 1.0  1993/12/21  10:58:47  carlsson
 * Initial revision
 *
 */

#ifndef _YALB_STATS_DISPLAY_H
#define _YALB_STATS_DISPLAY_H
#include <sys/time.h> /* **?? 11.12*/
/*#include <stdio.h>

#include "yalb_stats_db.h"*/

#define CTRL_STDI_PREV_HOST 2
#define CTRL_STDI_NEXT_HOST 1
#define OK_STDI 0
#define ERR_STDI_INIT -1

#define LIMIT_CONFLICTS1 2
#define LIMIT_CONFLICTS2 5

#define TRUE 1
#define FALSE 0

typedef struct host_stats {
	char hostname[50];
	int timeouts;
	int auth_timeouts;
	int rexec_timeouts;
	int conflicts1;
	int conflicts2;
	int execute;
	int send;
} host_stats;

typedef host_stats total_stats;

typedef FILE * display_info;

typedef struct timeint {
#ifdef WIN32
	struct tm begin;
	struct tm end;
#endif
#ifdef UNIX
	struct timeval begin;
	struct timeval end;
#endif
} timeint;

typedef struct poll_timeout_host_list {
	char hostname[50];
	int count;
	int answers;
	struct poll_timeout_host_list *next;
} poll_timeout_host_list;

typedef struct poll_timeout_list {
	long int timeout;
	struct poll_timeout_list *next;
	poll_timeout_host_list *first;
} poll_timeout_list;


extern int stats_display_init(display_info in_display_info);
extern int stats_display_host(host_stats *in_host_stats);
extern int stats_display_total(total_stats *in_total_stats);
extern int stats_display_timeint(struct timeint *in_timeint);
extern int stats_display_poll_timeout(poll_timeout_list *pt_list);
extern void stats_display_count(int count);


#endif
