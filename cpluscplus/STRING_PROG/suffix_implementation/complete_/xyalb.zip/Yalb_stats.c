/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_stats.c,v 1.3 1994/03/11 14:36:33 carlsson Exp $
 * $Log: yalb_stats.c,v $
 * Revision 1.3  1994/03/11  14:36:33  carlsson
 * Added call to `permission()'.
 *
 * Revision 1.2  1994/03/01  08:45:28  carlsson
 * Introduced #ifdef VERBOSE.
 *
 * Revision 1.1  1994/02/28  18:40:32  carlsson
 * Added information about exported and executed jobs and timeintervall 
 * for monitoring.
 *
 * Revision 1.0  1993/12/21  10:56:18  carlsson
 * Initial revision
 */

#include <stdio.h>
#include "system.h" /*added on 16.9.99*/
#include "yalb_config_db.h"

/*following header was commented out on 20.9.99 */
#include "yalb_stats_db.h"
#include "yalb_stats_display.h"


#ifdef UNIX
extern int gethostname ();
extern void bcopy (char *, char *, int);
extern int getopt (int, char **, char *);
#endif
/*changed 9.8.99 extern int fprintf ();*/
extern int fprintf (FILE *, const char *, ...);
extern int sleep ();


#define ABS(x) ( (x) < 0 ? (-(x)) : (x) )
#define CONFLICT1 2
#define CONFLICT2 5

#define OK_ST 0
#define ERR_ST_ARGS -1
#define ERR_ST_OPEN -2

static char program[] = "yalb_stats";
static char *global_filename = NULL;
static int opt_clear = FALSE;
static int do_show_poll = 0;


typedef struct host_stats_list
  {
    struct timeval timestamp;
    host_stats stats;
    struct host_stats_list *rest_of_list;
  }
host_stats_list;


static int 
get_opts (int argc, char *argv[])
{
  int c;
#ifdef WIN32
	extern char optarg[][MAX_PATH];
#endif
#ifdef UNIX
  extern char *optarg;
#endif
  extern int optind;

  opt_clear = FALSE;
#ifdef WIN32
  optind=0;
  	while ((optind<argc) && (c = argv[optind++][0])  )
		if (c=='-') { c=argv[optind-1][1]; 
	
#endif
#ifdef UNIX
  while ((c = getopt (argc, argv, "cp")) != -1){
#endif
  
      switch (c)
	{
	case 'c':
	  opt_clear = TRUE;
	  break;
	case 'p':
	  do_show_poll = 1;
	  break;
	case '?':
	  return (ERR_ST_ARGS);
	  break;
	}
    }
  if (argc - optind == 1)
    {
      global_filename = argv[optind];
    }
  else if (argc - optind > 1)
    {
      return (ERR_ST_ARGS);
    }

  return (OK_ST);
}



static void usage (void)
{
  fprintf (stderr, "usage: %s [-c] [-p] [<filename>].\n", program);
  exit (0);
}



static int 
is_empty (host_stats_list * head)
{
  return (head == NULL ? TRUE : FALSE);
}


static void 
insert_host (host_stats_list ** head, host_stats_list * host)
{
  if (*head == NULL)
    {
      *head = host;
    }
  else if (strcmp ((*head)->stats.hostname, host->stats.hostname) > 0)
    {
      host->rest_of_list = *head;
      *head = host;
    }
  else
    {
      insert_host (&((*head)->rest_of_list), host);
    }
}


static void 
init_host (host_stats_list ** head, host_stats_list * host, char *hostname)
{
  host->timestamp.tv_sec = 0;
  host->timestamp.tv_usec = 0;
  strcpy (host->stats.hostname, hostname);
  host->stats.timeouts = 0;
  host->stats.auth_timeouts = 0;
  host->stats.rexec_timeouts = 0;
  host->stats.conflicts1 = 0;
  host->stats.conflicts2 = 0;
  host->stats.execute = 0;
  host->stats.send = 0;

  host->rest_of_list = NULL;

  insert_host (head, host);
}


static host_stats_list *
get_host (host_stats_list ** head, char *hostname)
{
  host_stats_list *hlp = *head;

  while (!is_empty (hlp))
    {
      if (strcmp (hlp->stats.hostname, hostname) == 0)
	{
	  return (hlp);
	}
      hlp = hlp->rest_of_list;
    }

  hlp = (host_stats_list *) malloc (sizeof (host_stats_list));

  init_host (head, hlp, hostname);

  return (hlp);
}


static int 
is_conflict (struct timeval *t1, struct timeval *t2, int level)
{
    return (ABS ((t1->tv_sec + 0.000001 * t1->tv_usec) 
		 - (t2->tv_sec + 0.000001 * t2->tv_usec)) < level
	    ? TRUE : FALSE);
}


static void 
err (int type)
{
  switch (type)
    {
    case ERR_ST_ARGS:
      usage ();
      exit (-1);
      break;
    case ERR_ST_OPEN:
      fprintf (stderr, "%s: Can't open %s for output.\n", 
	       program, global_filename);
      exit (-1);
      break;
    default:
      fprintf (stderr, "Error\n");
      exit (-1);
      break;
    }
}

void 
insert_poll_timeout_host (poll_timeout_host_list ** pth_list, 
			  stats_poll_timeout * poll_timeout, char *hostname)
{
  poll_timeout_host_list *hlp;

  if (*pth_list == NULL)
    {
      *pth_list = (poll_timeout_host_list *) 
	  		malloc (sizeof (poll_timeout_host_list));
      strcpy ((*pth_list)->hostname, hostname);
      (*pth_list)->count = 1;
      (*pth_list)->next = NULL;
      (*pth_list)->answers = poll_timeout->answers;
    }
  else if (strcmp ((*pth_list)->hostname, hostname) == 0)
    {
      ((*pth_list)->count)++;
      (*pth_list)->answers += poll_timeout->answers;
    }
  else if (strcmp ((*pth_list)->hostname, hostname) > 0)
    {
      hlp = (poll_timeout_host_list *) 
	    	malloc (sizeof (poll_timeout_host_list));
      strcpy (hlp->hostname, hostname);
      hlp->count = 1;
      hlp->next = *pth_list;
      hlp->answers = poll_timeout->answers;
      *pth_list = hlp;
    }
  else
    {
      insert_poll_timeout_host (&(*pth_list)->next, poll_timeout, hostname);
    }
}




void 
insert_poll_timeout (poll_timeout_list ** pt_list, 
		     stats_poll_timeout * poll_timeout, char *hostname)
{
  if (*pt_list == NULL)
    {
      *pt_list = (poll_timeout_list *) malloc (sizeof (poll_timeout_list));
      (*pt_list)->timeout = poll_timeout->poll_timeout;
      (*pt_list)->first = NULL;
      insert_poll_timeout_host (&(*pt_list)->first, poll_timeout, hostname);
      (*pt_list)->next = NULL;
    }
  else if ((*pt_list)->timeout == poll_timeout->poll_timeout)
    {
      insert_poll_timeout_host (&(*pt_list)->first, poll_timeout, hostname);
    }
  else
    {
      insert_poll_timeout (&(*pt_list)->next, poll_timeout, hostname);
    }
}



void 
main (int argc, char *argv[])
{
  FILE *out_fp = NULL;
  int ret;

  int type;
  struct timeval timestamp;
  host_stats_list *current_host;
  host_stats_list *sending_host;

  stats_info stats = NULL;

   stats_job_begin *job_begin = (stats_job_begin *)&stats;
   stats_job_end *job_end = (stats_job_end *)&stats;
   stats_timeout *timeout = (stats_timeout *)&stats;
   stats_not_avail *not_avail = (stats_not_avail *)&stats;
   stats_poll_timeout *poll_timeout = (stats_poll_timeout *)&stats;

  host_stats_list *head = NULL;
  host_stats_list *hlp = NULL;

  poll_timeout_list *pt_list = NULL;

  char hostname[MAX_NAME_LEN];

  timeint period;
  static int first = TRUE;

  host_config buf;
  int count;
#ifdef WIN32
  WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif

  if ((ret = get_opts (argc, argv)) != OK_ST)
    {
      err (ret);
    }

#if 0
  {				/* start of test */
    int i;
	
	
    stats_on ();

    for (i = 0; i < 5; i++)
      {
	if (gethostname (job_begin->hostname, MAX_NAME_LEN))
	  {
#ifdef VERBOSE
	    fprintf (stderr, "%s: Can't get hostname\n", program);
#endif
	    exit (1);
	  }
	strcpy (job_begin->from, "achill");
	job_begin->proc_nr = i;
	strcpy (job_begin->command, "make");
	stats_write (STATS_TYPE_JOB_BEGIN, &stats);

	if (gethostname (job_end->hostname, MAX_NAME_LEN))
	  {
#ifdef VERBOSE
	    fprintf (stderr, "%s: Can't get hostname\n", program);
#endif
	    exit (1);
	  }
	job_end->proc_nr = i;
	stats_write (STATS_TYPE_JOB_END, &stats);

	sleep (i);
      }
    if (gethostname (timeout->hostname, MAX_NAME_LEN))
      {
#ifdef VERBOSE
	fprintf (stderr, "%s: Can't get hostname\n", program);
#endif
	exit (1);
      }
    timeout->count = 2;
    stats_write (STATS_TYPE_TIMEOUT, &stats);
    timeout->count++;
    stats_write (STATS_TYPE_AUTH_TIMEOUT, &stats);
    timeout->count++;
    stats_write (STATS_TYPE_REXEC_TIMEOUT, &stats);

    for (i = 0; i < 5; i++)
      {
	strcpy (job_begin->hostname, "helios");
	strcpy (job_begin->from, "pan");
	job_begin->proc_nr = i + 7;
	strcpy (job_begin->command, "make");
	stats_write (STATS_TYPE_JOB_BEGIN, &stats);

	if (gethostname (job_end->hostname, MAX_NAME_LEN))
	  {
#ifdef VERBOSE
	    fprintf (stderr, "%s: Can't get hostname\n", program);
#endif
	    exit (1);
	  }
	job_end->proc_nr = i + 7;
	stats_write (STATS_TYPE_JOB_END, &stats);

	sleep (i);
      }


    if (gethostname (job_begin->hostname, MAX_NAME_LEN))
      {
#ifdef VERBOSE
	fprintf (stderr, "%s: Can't get hostname\n", program);
#endif
	exit (1);
      }
    strcpy (job_begin->from, "bal");
    job_begin->proc_nr = 10;
    strcpy (job_begin->command, "make");
    stats_write (STATS_TYPE_JOB_BEGIN, &stats);

  }				/* end of test */
#endif
  if (opt_clear)
    {
	permission ();
      stats_clear ();
    }
  else
    {
      while (stats_read (&type, &timestamp, hostname, &stats) == OK_STDB)
	{
	  if (first)
	    {
	      first = FALSE;
#ifdef WIN32
		  memcpy ((char *) &period.begin,(char *) &timestamp, sizeof (struct timeval));
#endif
#ifdef UNIX
		  bcopy ((char *) &timestamp, (char *) &period.begin,sizeof (struct timeval));
#endif
	    }
#ifdef WIN32
	   memcpy((char *) &period.end,(char *) &timestamp,  
		 sizeof (struct timeval));
#endif
#ifdef UNIX
	   bcopy ((char *) &timestamp, (char *) &period.end, 
		 sizeof (struct timeval));
#endif
	  switch (type)
	    {
	    case STATS_TYPE_JOB_BEGIN:
	      current_host = get_host (&head, hostname);
	      sending_host = get_host (&head, 
				       ((stats_job_begin *) stats)->from);
	      current_host->stats.execute++;
	      sending_host->stats.send++;

	      if (current_host->timestamp.tv_sec == 0)
		{
		  ;
		}
	      else if (is_conflict (&current_host->timestamp, &timestamp, 
				    LIMIT_CONFLICTS1))
		{
		  current_host->stats.conflicts1++;
		}
	      else if (is_conflict (&current_host->timestamp, &timestamp, 
				    LIMIT_CONFLICTS2))
		{
		  current_host->stats.conflicts2++;
		}
	      current_host->timestamp = timestamp;
	      break;
	    case STATS_TYPE_JOB_END:
	      break;
	    case STATS_TYPE_AUTH_TIMEOUT:
	      current_host = get_host (&head, hostname);
	      current_host->stats.auth_timeouts += 
		  ((stats_timeout *) stats)->count;
	      break;
	    case STATS_TYPE_REXEC_TIMEOUT:
	      current_host = get_host (&head, hostname);
	      current_host->stats.rexec_timeouts += 
		  ((stats_timeout *) stats)->count;
	      break;
	    case STATS_TYPE_TIMEOUT:
	      current_host = get_host (&head, hostname);
	      current_host->stats.timeouts +=
		  ((stats_timeout *) stats)->count;
	      break;
	    case STATS_TYPE_NOT_AVAIL:
	      break;
	    case STATS_TYPE_POLL_TIMEOUT:
	      insert_poll_timeout (&pt_list, 
				   (stats_poll_timeout *) stats, hostname);
	      break;
	    default:
#ifdef VERBOSE
	      fprintf (stderr, "%s: Unknown type: %d.\n", program, type);
#endif
	      break;
	    }
	}

      if (!first)
	{
	  if (global_filename != NULL)
	    {
	      if ((out_fp = fopen (global_filename, "w")) == NULL)
		{
		  err (ERR_ST_OPEN);
		}
	    }

	  stats_display_init (out_fp);

	  count = 0;
	  if (open_config ((int *) NULL) == OK_CFDB)
	    {
	      while (read_host_config (&buf, NULL) == OK_CFDB)
		{
		  if (buf.choose)
		    {
		      count++;
		    }
		}
	    }
	  (void) close_config ();

	  hlp = head;
	  while (!is_empty (hlp))
	    {
	      stats_display_host (&hlp->stats);
	      hlp = hlp->rest_of_list;
	    }
	  if (do_show_poll)
	      stats_display_poll_timeout (pt_list);
	  stats_display_timeint (&period);
	  stats_display_count (count);
	}
      else
	{
	  fprintf (stderr, "No statistics available\n");
	}
    }
}
