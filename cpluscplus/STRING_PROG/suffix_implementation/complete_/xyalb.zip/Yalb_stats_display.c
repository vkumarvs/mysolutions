/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_stats_display.c,v 1.1 1994/03/01 08:56:07 carlsson Exp $
 * $Log: yalb_stats_display.c,v $
 * Revision 1.1  1994/03/01  08:56:07  carlsson
 * Added stats_display_count(), that writes the number of configured hosts.
 * Added the columns `exported jobs' and `executed jobs' in the table.
 * Changed stats_display_timeint().
 *
 * Revision 1.0  1993/12/21  10:58:13  carlsson
 * Initial revision
 */

#include <stdio.h>
#include <ctype.h>
#include "sysdef.h"
#include "yalb_stats_display.h"
/*changed 9.8.99 extern int fprintf();*/
extern int fprintf(FILE *, const char *, ...);

#define HFW 10
#define CFW 9
#define TFW 9

static int initialized = FALSE;
static int first_host = TRUE;
static FILE *display_fp = NULL;

static char *line = "-------------------------------------------------------------------------------\n";


static void stats_display_line(void)
{
	fprintf(display_fp, line);
}


static void stats_display_header()
{
	static char *format = 
		"%-*.*s %*.*s %*.*s %*.*s %*.*s %*.*s %*.*s %*.*s\n";
	fprintf(display_fp, "\n\n");
	fprintf(display_fp, format, HFW, HFW, "", CFW, CFW, 
		"exported", CFW, CFW, "executed", CFW, CFW, 
		"2 second", CFW, CFW, "5 second", TFW, TFW, 
		"", TFW, TFW, "auth", TFW, TFW, "rexec");
	fprintf(display_fp, format, HFW, HFW, "host", CFW, CFW,
		"jobs", CFW, CFW, "jobs", CFW, CFW, 
		"conflicts", CFW, CFW, "conflicts", TFW, TFW, 
		"timeouts", TFW, TFW, "timeouts", TFW, TFW, "timeouts");
	stats_display_line();
}


int stats_display_init(display_info in_display_info)
{
	display_fp = (in_display_info == NULL ? stdout : in_display_info);
	initialized = TRUE;
	return( OK_STDI );
}


int stats_display_host(host_stats *in_host_stats)
{
	static char *format = "%-*.*s %*d %*d %*d %*d %*d %*d %*d\n";

	/* XXX (schoenfr): don't print garbled entries: */
	if (! isalpha(in_host_stats->hostname[0]))
	    return OK_STDI;

	if( initialized ) {
		if( first_host ) {
			first_host = FALSE;
			stats_display_header();
		}
		fprintf(display_fp, format, HFW, HFW, 
			in_host_stats->hostname, CFW,
			in_host_stats->send, CFW,
			in_host_stats->execute, CFW, 
			in_host_stats->conflicts1, CFW,
			in_host_stats->conflicts2, TFW, 
			in_host_stats->timeouts, TFW, 
			in_host_stats->auth_timeouts, TFW,
			in_host_stats->rexec_timeouts);
		return( OK_STDI );
	}
	else {
		return( ERR_STDI_INIT );
	}
}

int stats_display_total(total_stats *in_total_stats)
{
	static char *format = "%-*.*s %*d %*d %*d %*d %*d\n";

	if( initialized ) {
		if( !first_host ) {
			stats_display_line();
			fprintf(display_fp, format,  HFW, HFW, "Total",
				CFW, in_total_stats->conflicts1, CFW,
				in_total_stats->conflicts2, TFW, 
				in_total_stats->timeouts, TFW, 
				in_total_stats->auth_timeouts, TFW, 
				in_total_stats->rexec_timeouts);
		}
		first_host = TRUE;
		return( OK_STDI );
	}
	else {
		return( ERR_STDI_INIT );
	}
}
	
	  
int stats_display_timeint(struct timeint *in_timeint)
{
	char *format = "\nStatistics calculated from: %s to: %s\n";
	char from[64], to[64];
	
#ifdef WIN32
	strftime(from, 64, "%Y-%m-%d", &in_timeint->begin);
	strftime(to, 64, "%Y-%m-%d", &in_timeint->end);
#endif
#ifdef UNIX
	strftime(from, 64, "%Y-%m-%d", localtime(&in_timeint->begin));
	strftime(to, 64, "%Y-%m-%d", localtime(&in_timeint->end));
#endif
	fprintf(display_fp, format, from, to);

	return( OK_STDI );
}


int stats_display_poll_timeout(poll_timeout_list *pt_list)
{
	poll_timeout_host_list *hlp;

	while( pt_list != NULL ) {
		fprintf(display_fp, 
	"\nWith polling timeout set to %ld milliseconds has:\n", 
			pt_list->timeout);
		hlp = pt_list->first;
		while( hlp ) {
			fprintf(display_fp,
  "  %s performed %d load pollings and receives %.1f answers in average.\n", 
				hlp->hostname, hlp->count, 
				(float)hlp->answers / (float)hlp->count);
			hlp = hlp->next;
		}
		pt_list = pt_list->next;
	}
	return( OK_STDI );
}


void stats_display_count(int count)
{
	fprintf(display_fp, "\nNumber of configured hosts: %d\n", count);
}
