/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */


/*
 * $Id: rexecmanager.c,v 1.2 1994/02/28 19:21:27 carlsson Exp $
 * $Log: rexecmanager.c,v $
 * Revision 1.2  1994/02/28  19:21:27  carlsson
 * Looking for bugs that appears to be caused bu gcc!
 *
 * Revision 1.1  1993/12/21  10:34:27  carlsson
 * The global variable long_jobs was added. It contains the number 
 * of long jobs executing at host and is a pointer to shared memory.
 * The field long_job was added to the table procs. If it is TRUE, 
 * the corresponding process is a long job.
 *
 * The following functions were added:
 * 	readsysconfig()		- Read the system configuration.
 * 	handle_SIG_CONFIG_READ()- Handler for the signal SIG_CONFIG_READ
 *							(SIGUSR1).
 *
 * The following functions were changed:
 * 	handle_SIGCHLD()	- Statistics is written when a job ends.
 * 				  If the job was a long job the counter 
 *				  long_jobs is decreased.
 * 	main()			- The hardcoded names in call to 
 *				  getservbyname was changed to REMA_SERVICE
 *				  and DAEMON_SERVICE respectively.
 * 				  The new field jobkind in the 
 *				  REQUEST_FOR_EXEC message is checked. If 
 *				  it is true the job is marked as a long job
 * 				  and the counter long_jobs in shared memory
 *				  is increased.
 * 				  Statistics (timeouts and started jobs) 
 *				  were added.
 *
 * Revision 1.0  1993/12/02  14:55:37  stille
 * Initial revision
 */
#include "system.h"
#include "remote.h"
#ifdef UNIX
#include <stdio.h>
#include <sys/wait.h>
#endif
#ifdef LINUX
#include <linux/socket.h>
#include <signal.h>
#include <fcntl.h>
#endif
#ifdef WIN32
#include <signal.h>
#endif

#include "yalb_stats_db.h"
#include "yalb_config_db.h"

#define TRUE 1
#define FALSE 0
#define SHORT_LIVED 3                      /* Age in seconds up to which a process is considered short-lived */

/* Default values for certain symbols ... */

#ifndef MAX_TRIES
#define MAX_TRIES 3              /* Number of tries to get an authentication */
#endif /* !MAX_TRIES */

#ifndef AUTH_TIMEOUT
#define AUTH_TIMEOUT 1000000     /* Timeout for authentication from loaddaemon (in usec) */
#endif /* !AUTH_TIMEOUT */

#ifndef DATA_TIMEOUT
#define DATA_TIMEOUT 2000000     /* Timeout for getting execution-data from remote site (in usec) */
#endif /* !DATA_TIMEOUT */

#ifndef MAX_SOCKS
#define MAX_SOCKS 0x500             /* Maximum number of sockets for rexec-manager */
#define MAXWIDTH  0x500
#else 
#define MAXWIDTH MAX_SOCKS
#endif /* !MAX_SOCKS */

#ifndef MAX_CONNECTS
#define MAX_CONNECTS 15                    /* Maximum number of connections for rexec-manager */
#endif /* !MAX_CONNECTS */

#define REFUSE   shutdown (socks[last].socket,2); close (socks[last].socket); socks[last].socket = -1; imported--;

/*
 * Global variables
 */

extern char **environ;         /* Current environment */
int timeout;                   /* Indicates that a timeout occurs */
int last = 0;                  /* First free index in socks data-structure */
int imported = 0;              /* Number of imported jobs */
fd_set exceptfds;              /* Sockets on whichh to look for oob-data */
rexec_reply result;            /* Result to be sent to client */
notify notification;           /* Notification for remote master */
float *terminated;             /* Number of terminated jobs since last update of load-information */
int *temp_imported;            /* Number of jobs imported since last update of load-information */
int *long_jobs;                 /* Number of executing long jobs in shared mem */
char myname[] = "Rexec-manager";
#ifdef PROTOCOL
struct sockaddr_in from;         /* Who requested connection? */
char *file;                      /* Name of the file to be executed */
#endif

/*
 * Data needed for identifying processes is kept in a per-socket
 * data-structure
 */

struct {
	int proc_id;                   /* Number of associated process */
#ifdef WIN32
	time_t started;
	time_t ended;          /* Time the imported job was terminated */
#endif
#ifdef UNIX
	struct timeval started;        /* Time the imported job was started */
	struct timeval ended;          /* Time the imported job was terminated */
#endif
	int long_job;                  /* TRUE if the process is a long job */
} procs[MAX_SOCKS];

/*
 * Contains active sockets
 */

struct {
	int socket;                 /* Active socket */
	struct sockaddr_in host;    /* For which host are we executing */
} socks[MAX_CONNECTS];

int sockslastsocket;

#ifdef WIN32
void handle_SIGCHLD(PROCESS_INFORMATION pi);
int ForkAndExec(int sock, char **argvv, int *sockpid, char *pwd) 
{ 
  char chReadBuffer[64];  /* pipe read buffer */ 
  BOOL bSuccess;  /* BOOL return code for APIs */ 
  int j; 
  HANDLE hOutFile;  /* handle to log file */ 
  /* handles to the anonymous pipe */ 
  HANDLE hReadPipe, hWritePipe, hWritePipe2; 
 char szArgs[256];  /* child process argument buffer */ 
  char *p;  /* temporary pointer into szArgs */ 
  DWORD cchReadBuffer;  /* number of bytes read or to be written */ 
  STARTUPINFO si;  /* for CreateProcess call */ 
  PROCESS_INFORMATION pi;  /* for CreateProcess call */ 
  SECURITY_ATTRIBUTES saPipe;  /* security for anonymous pipe */ 

 
  /* create the log file where we will save all output from child */ 
  if ((hOutFile = CreateFile("\\\\.\\C:\\yalb_win\\tmp",  
      GENERIC_WRITE,  /* access mode */ 
      FILE_SHARE_READ,  /* share mode */ 
      NULL,  /* security attributes */ 
      CREATE_ALWAYS,  /* creation flags - trash existing file */ 
      FILE_ATTRIBUTE_NORMAL,  /* file attributes */ 
      NULL))==NULL) printf("Error %d\n",GetLastError()); 
 
/* set up the security attributes for the anonymous pipe */ 
  saPipe.nLength = sizeof(SECURITY_ATTRIBUTES); 
  saPipe.lpSecurityDescriptor = NULL; 
  /* In order for the child to be able to write to the pipe, the handle */ 
  /* must be marked as inheritable by setting this flag: */ 
  saPipe.bInheritHandle = TRUE; 
 
  /* create the anonymous pipe */ 
 if (!(bSuccess = CreatePipe(&hReadPipe,  /* read handle */ 
      &hWritePipe,  /* write handle, used as stdout by child */ 
      &saPipe,  /* security descriptor */ 
      0))) printf("Error %d\n",GetLastError());  /* pipe buffer size */ 
 
/* Now we need to change the inheritable property for the readable 
  end of the pipe so that the child will not inherit that handle as 
  a "garbage" handle. This will keep us from having extra, 
  unclosable handles to the pipe. Alternatively, we could have 
  opened the pipe with saPipe.bInheritHandle = FALSE and changed the 
  inherit property on the *write* handle of the pipe to TRUE. */ 
 
  if (!(bSuccess = DuplicateHandle(GetCurrentProcess(), /* source process */ 
      hReadPipe, /* handle to duplicate */ 
      GetCurrentProcess(), /* destination process */ 
      NULL, /* new handle - don't want one, change original handle */ 
      0, /* new access flags - ignored since DUPLICATE_SAME_ACCESS */ 
      FALSE, /* make it *not* inheritable */ 
      DUPLICATE_SAME_ACCESS))) printf("Error %d\n",GetLastError()); 

 
  
  if (!(bSuccess = DuplicateHandle(GetCurrentProcess(), /* source process */ 
      hWritePipe, /* handle to duplicate */ 
      GetCurrentProcess(), /* destination process */ 
      &hWritePipe2, /* new handle, used as stderr by child */ 
      0, /* new access flags - ignored since DUPLICATE_SAME_ACCESS */ 
      TRUE, /* it's inheritable */ 
      DUPLICATE_SAME_ACCESS))) printf("Error %d\n",GetLastError()); 

 
  /* Set up the STARTUPINFO structure for the CreateProcess() call */ 
  memset(&si, 0, sizeof(si)); 
  si.cb = sizeof(si); 
 
  /* Set up the command-line buffer for the child for CreateProcess() */ 
  memset(szArgs, 0, sizeof(szArgs)); 
strcpy(szArgs, *argvv); 

 strcat(szArgs, " "); 
p = strchr(szArgs, 0);  /* point to the terminating null */ 
	for (j = 0; argvv[j]!=NULL; j++) 
    { 
    strcat(p, argvv[j]); 
  strcat(p, " "); 
  } 
 
#ifdef USESTDHANDLES 
  
  si.hStdInput = hWritePipe2; /* hStdInput needs a valid handle in case it is checked by the child */ 
  si.hStdOutput = hWritePipe; /* write end of the pipe */ 
  si.hStdError = hWritePipe2; /* duplicate of write end of the pipe */ 
  si.dwFlags = STARTF_USESTDHANDLES; 
#else 
 bSuccess = SetStdHandle(STD_INPUT_HANDLE, hWritePipe2); 
  bSuccess = SetStdHandle(STD_OUTPUT_HANDLE, hWritePipe); 
  bSuccess = SetStdHandle(STD_ERROR_HANDLE, hWritePipe2); 
  bSuccess = DuplicateHandle(GetCurrentProcess(), /* source process */ 
      GetStdHandle(STD_INPUT_HANDLE), /* handle to duplicate */ 
      GetCurrentProcess(), /* destination process */ 
      NULL, /* new handle - don't want one, change original handle */ 
      0, /* new access flags - ignored since DUPLICATE_SAME_ACCESS */ 
      FALSE, /* it's *not* inheritable */ 
      DUPLICATE_SAME_ACCESS); 
 #endif 
 
  /* Now create the child process, inheriting handles */ 
 
  if ((bSuccess = CreateProcess(NULL,  /* filename */ 
    szArgs,//*argvv,//"hello.exe",  /* full command line for child */ 
      NULL,  /* process security descriptor */ 
      NULL,  /* thread security descriptor */ 
      TRUE,  /* inherit handles? Also use if STARTF_USESTDHANDLES */ 
      0,  /* creation flags */ 
      NULL,  /* inherited environment address */ 
      NULL,  /* startup dir; NULL = start in current */ 
      &si,  /* pointer to startup info (input) */ 
      &pi)) ==NULL) printf("Error %d\n",GetLastError());   /* pointer to process info (output) */ 
 
  /* We can close the returned child process handle and thread 
  handle as we won't be needing them; you could, however, wait on 
  the process handle to wait until the child process terminates. */ 
 *sockpid=pi.dwProcessId;
  CloseHandle(pi.hThread); 
  
 
  bSuccess = CloseHandle(hWritePipe); 
  bSuccess = CloseHandle(hWritePipe2); 

  /* read from the pipe until we get an ERROR_BROKEN_PIPE */ 
for (;;) 
    { 
    bSuccess = ReadFile(hReadPipe,  /* read handle */ 
        chReadBuffer,  /* buffer for incoming data */ 
        sizeof(chReadBuffer),  /* number of bytes to read */ 
        &cchReadBuffer,  /* number of bytes actually read */ 
        NULL);  /* no overlapped reading */ 
	
    if (bSuccess && cchReadBuffer) 
      { 
      /* write the data from the child to the file */ 
     send(sock, chReadBuffer,cchReadBuffer, 0);
      /* write buffer (of specified length) to console */ 
      printf("%.*s", cchReadBuffer, chReadBuffer); 
      } 
 if (cchReadBuffer<64) 
        break;  /* child has died */ 
 
    } 
  /* close the trace file, pipe handles */ 
  CloseHandle(hOutFile); 
  CloseHandle(hReadPipe); 
  handle_SIGCHLD(pi);
SetCurrentDirectory(pwd);
} 


/*************************************************************/ 
/* Creates the child process and redirects its std.IO handles*/ 
/*************************************************************/ 
/* these handles should be treated as if they send and receive ANSI, not Unicode */
HANDLE  ForkChildProcess( char *cmd,HANDLE inH,HANDLE outH,HANDLE errH ) 
{ 
SECURITY_ATTRIBUTES lsa; 
STARTUPINFO si; 
PROCESS_INFORMATION pi; 
int written;
HANDLE ChildIn=inH;//CreateFile(_T("CONIN$"),GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); //inH; 
HANDLE ChildOut;//=outH;//=CreateFile(_T("CONOUT$"),GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); //outH; 
HANDLE ChildErr=errH; 
lsa.nLength=sizeof(SECURITY_ATTRIBUTES); 
lsa.lpSecurityDescriptor=NULL; 
lsa.bInheritHandle=TRUE; 
ChildOut=outH;




si.cb=sizeof(STARTUPINFO); 
si.lpReserved=NULL; 
si.lpTitle=NULL; 
si.lpDesktop=NULL; 
si.dwX=si.dwY=si.dwYSize=si.dwXSize=0; 
si.dwFlags=STARTF_USESTDHANDLES; 
si.hStdInput =ChildIn; 
si.hStdError =errH; 
si.hStdOutput=ChildOut;
si.wShowWindow=SW_SHOW; 
si.lpReserved2=NULL; 
si.cbReserved2=0; 


// 
//Create Child Process 
// 
if (!CreateProcess (NULL,cmd,NULL,NULL,TRUE,NORMAL_PRIORITY_CLASS,NULL, NULL,&si,&pi)) 
{ 

} 

WaitForSingleObject(pi.hProcess,INFINITE);
return (pi.hProcess); 
} 
#endif
/*
 * Handle died or stopped children
 */
#ifdef WIN32

void handle_SIGCHLD (PROCESS_INFORMATION pi)
{
	DWORD status;               /* Status of the child process */
	DWORD pid;                         /* Process-id of child process */
	int sock;                        /* Socket belonging to process */
	int count;   
	float duration;                  /* Duration of command execution */
	int ret;
	
	/*
	 * Get pid of process, whose status has changed. We block on this
	 * because we do not want to miss an exiting child process
	 */
	WaitForSingleObject(pi.hProcess,INFINITE);
	pid=pi.dwProcessId;
	if (!GetExitCodeProcess(pi.hProcess,&status))
		printf("Error in Exit status = %d\n",GetLastError());

	CloseHandle(pi.hProcess);

	
	for (sock = 0 ; (sock < MAX_SOCKS) && (procs[sock].proc_id != pid); sock++);
	/*
	 * If no entry in procs--structure, quit handling of SIGCHILD
	 */
	
	if(sock == MAX_SOCKS) {
		return pid;
	}

	/*
	 * Send exit-status of dead process back to caller, clear socks
	 * table entry and close associated socket
	 */

time(&procs[sock].ended);
{
		/*
		 * Write statistics
		 */

		static stats_job_end job_end_info;

		job_end_info.proc_nr = procs[sock].proc_id;
		stats_write(STATS_TYPE_JOB_END, (stats_info)&job_end_info);
	}
	
	result.kind = EXIT_STATUS;
	result.r_status = status;
	
	while ((ret = send(sock/*+0x180*/, (char *)&result, sizeof (result), 0)) < 0  && (errno == EINTR));

	procs[sock].proc_id = -1;
	shutdown(sock,2);
	close(sock);
	FD_CLR(sock,&exceptfds);
	
	for(count = 0; (socks[count].socket != sock) && (count < MAX_CONNECTS); count++);
	
	/*
	 * If no entry in socks-structure, quit handling of SIGCHLD
	 */
	
	if(count == MAX_CONNECTS)
	  return;
	
	socks[count].socket = -1;
	
	imported--;
	
	/*
	 * Estimate load that was caused by terminated process and put it
	 * into shared memory...
	 */
	
	/*
	 * The load of short lived processes is estimated by 0.6...
	 */
	
	if( procs[sock].long_job ) {
		/*
		 * Decrease the number of long jobs in shared memory
		 */
		(*long_jobs)--;
	}
return pid;	
}
#endif
#ifdef UNIX
void handle_SIGCHLD ()
{
	/*changed 10.8.99 union wait status;               /* Status of the child process */
	int status;               /* Status of the child process */
	int pid;                         /* Process-id of child process */
	int sock;                        /* Socket belonging to process */
	int count;   
	struct rusage resourcen;         /* Resources needed by our child */
	float duration;                  /* Duration of command execution */
	int ret;
	
	/*
	 * Get pid of process, whose status has changed. We block on this
	 * because we do not want to miss an exiting child process
	 */
	while(((pid = wait3((int *)&status, 0, (struct rusage *) &resourcen)) < 0) && (errno == EINTR));
	
#ifdef PROTOCOL    
	{
		FILE *stats;
		
		if(stats =  fopen("/tmp/rexec.log","a")) {
			fprintf(stats,"Received SIGCHLD !\n");
			fclose(stats);
		}
	}
#endif
	

  /*
   * We are only interested in terminated processes
   */
	
	if((!WIFEXITED(status) && !WIFSIGNALED(status)) || pid == 0) {
#ifdef PROTOCOL    
		{
			FILE *stats;
			
			if(stats =  fopen("/tmp/rexec.log","a")) {
				fprintf(stats,"Job not exited. Process Id: %d\n", pid);
				fclose(stats);
			}
		}
#endif
		return;
	}
	
	for (sock = 0 ; (sock < MAX_SOCKS) && (procs[sock].proc_id != pid); sock++);
	
	/*
	 * If no entry in procs--structure, quit handling of SIGCHILD
	 */
	
	if(sock == MAX_SOCKS) {
#ifdef PROTOCOL    
		{
			FILE *stats;
			
			if(stats =  fopen("/tmp/rexec.log","a")) {
				fprintf(stats,"Job not in process-table, process-Id: %d\n", pid);
				fclose(stats);
			}
		}
#endif
		
		return;
	}

	/*
	 * Send exit-status of dead process back to caller, clear socks
	 * table entry and close associated socket
	 */
	gettimeofday(&procs[sock].ended, (struct timezone *)0);
	{
		/*
		 * Write statistics
		 */

		static stats_job_end job_end_info;

		job_end_info.proc_nr = procs[sock].proc_id;
		stats_write(STATS_TYPE_JOB_END, (stats_info)&job_end_info);
	}
	
	result.kind = EXIT_STATUS;
	result.r_status = status;
	
	while ((ret = send(sock, (char *)&result, sizeof (result), 0)) < 0  && (errno == EINTR));
	
	
#ifdef PROTOCOL    
	{
		FILE *stats;
		struct hostent *name;
		struct timeval time;
		char host[15];
			WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/

	
		if(stats =  fopen("/tmp/rexec.log","a")) {
			name = gethostbyaddr((char *)&from.sin_addr.s_addr, sizeof (from.sin_addr.s_addr), AF_INET);
			gethostname(host, sizeof(host));
			gettimeofday(&time, (struct timezone *)0);
			fprintf(stats,"Sent to: %10s Command received: %s Bytes: %d\n", 
				name->h_name, file,  ret);
			fclose(stats);
		}
	}
#endif
	
	
	procs[sock].proc_id = -1;
	shutdown(sock,2);
	close(sock);
	FD_CLR(sock,&exceptfds);
	
	for(count = 0; (socks[count].socket != sock) && (count < MAX_CONNECTS); count++);
	
	/*
	 * If no entry in socks-structure, quit handling of SIGCHLD
	 */
	
	if(count == MAX_CONNECTS)
	  return;
	
	socks[count].socket = -1;
	
	imported--;
	
	/*
	 * Estimate load that was caused by terminated process and put it
	 * into shared memory...
	 */
	duration = (((double)procs[sock].ended.tv_sec - (double)procs[sock].started.tv_sec) + 0.000001 * ((double)procs[sock].ended.tv_usec - (double)procs[sock].started.tv_usec));
	/*
	 * The load of short lived processes is estimated by 0.6...
	 */
	
	if(duration > SHORT_LIVED) 
	  (*terminated)  += ((double) resourcen.ru_utime.tv_sec + 0.000001 * (double)resourcen.ru_utime.tv_usec) / duration;
	else
	  (*terminated) += 0.6;
	
	if( procs[sock].long_job ) {
		/*
		 * Decrease the number of long jobs in shared memory
		 */
		(*long_jobs)--;
	}
	
}
#endif
/*
 * Handle out-of-band data (propagate signal to appropriate process)
 */
/*#ifdef WIN32
 //*eqvt?**
#endif*/
#ifdef UNIX
 void handle_SIGURG ()
{
	fd_set selectfds;               /* Temporary mask for select */
	int mask;                       /* Mask of blocked signals */
	int oob_socket;                 /* Socket from on which oob-data is received */
	char sig_char;                  /* We have to encode the signal in a single byte (oob-data!) */
	int ret;                        
	fd_set zerofds;
	
	/*
	 * Out-of-band-data is most important to us , so block all signals we
	 * can. 
	 */
	
	FD_ZERO(&zerofds);
	
	mask = sigblock (~0);
	
	selectfds = exceptfds;
	
	if(!bcmp((char *) &selectfds, (char *) &zerofds, sizeof (fd_set))) {
		sigsetmask(mask);
		return;
	}
	
	while ((ret = select(MAXWIDTH, (fd_set *)0, (fd_set *)0, &selectfds, (struct timeval *)0)) < 0 && errno == EINTR);
	
	if (ret < 0)  {
		syslog(LOG_ERR, "Error on select when receiving oob-data: %m");
		sigsetmask(mask);
		return;
	}
	
	/*
	 * We got the socket to listen to. Extract it from selectfds and read
	 * oob-data.
	 */
	
	for (oob_socket = 0; oob_socket < MAX_SOCKS; oob_socket++) {
		
		if(FD_ISSET(oob_socket, &selectfds)) {
			while (recv(oob_socket, &sig_char, sizeof (char), MSG_OOB) < 0) 
			  
			  switch (errno) {
				  
				case EWOULDBLOCK:
				  /*
				   * Urgent data not here yet. Since we do not use the sockets
				   * selected  upon for 'normal' data transfer, there is not way for
				   * us to block on a full buffer. So we simply wait for the data to
				   * be delivered to us. If any changes are made to this, we might
				   * have to change this and assure that the buffer is read so
				   * that the oob-data can be transmitted.
				   */
				  continue;
				  
				default:
				  
				  syslog(LOG_ERR, "Error receiving oob-data : %m");
				  sigsetmask(mask);
				  return;
				  
			  }
			
			/*
			 * Deliver signal to appropriate process
			 */
			
			ret = killpg(procs[oob_socket].proc_id, (long) sig_char);
			
		}
	}
	
	/*
	 * Reinstall old signal mask and exit
	 */
	
	sigsetmask(mask);
	return ;
}
#endif


/*
 * Extract the transmitted array of strings and return an array of
 * char pointers. Used to extract the argv and envp for the new
 * process 
 */

static char **extract (strPtrPtr)
     char          **strPtrPtr;
{
	char *cp;                          /* Points to currently extracted string */
	char **vec;                        /* Array member (address of currently extracted string) */
	long  numStrings;                  /* Number of strings in buffer */
	char  **vecPtr;                    /* Pointer to resulting array of char pointers */
	
	/*
	 * First get the number of arguments
	 */
	
	cp = *strPtrPtr;
	numStrings = *(long *)cp;
	
	/*
	 * Allocate memory for the pointer array
	 */
	
	vecPtr = (char **)malloc((unsigned)((numStrings + 1) * sizeof(char *)));
	
	/*
	 * Now fill the pointer array with appropriate addresses
	 */
	
	
	cp += sizeof(long);
	for (vec = vecPtr; numStrings != 0; vec++, numStrings--) {
		*vec = cp;
		cp += strlen(cp) + 1;
	}
	
	/*
	 * Set terminating entry of pointer list
	 */
	
	*vec = (char *)0;
	
	/*
	 * Return new pointer for analyzing and pointer to the extracted
	 * char pointer array
	 */
	
	*strPtrPtr = cp;
	return(vecPtr);
}


void readsysconfig(void)
{
	system_config local_system_config;
	int linenr;
	
	switch( open_config(&linenr) ) {
	      case ERR_CFDB_OPEN:
		fprintf(stderr, "Cant open configuration file\n");
		exit(-1);
		break;
	      case OK_CFDB:
		break;
	      default:
		fprintf(stderr, "Error at line %d in configuration file", linenr);
		exit(-1);
		break;
	}
	
	if( read_system_config(&local_system_config) != OK_CFDB ) {
		fprintf(stderr, "Cant read system configuration.\n");
		exit(-1);
	}

	close_config();
	
	if( local_system_config.statistics == TRUE ) {
		stats_on();
	}
	else {
		stats_off();
	}
}




void handle_SIG_CONFIG_READ(void)
{
	readsysconfig();
}

#ifdef WIN32
HANDLE  hServerStopEvent = NULL; 
VOID ServiceStop() 
{ 
    if ( hServerStopEvent ) 
        SetEvent(hServerStopEvent); 
} 
#endif


/*
 * Function main
 */
#ifdef WIN32
VOID ServiceStart (DWORD dwArgc, LPTSTR *lpArgv) 
#endif
#ifdef UNIX
int main ()
#endif     
{
int sock;          /* Socket for stdin, stdout, stderr */
	
	struct servent *get_port;        /* Structure to get port of rexec-manager */
#ifdef WIN32
	SOCKET in_socket;
#endif
#ifdef UNIX
	int in_socket;                   /* Socket for accepting connections */
#endif
	int auth_server;                 /* Socket for authentication */
	struct sockaddr_in my_name;      /* Internet-name of local socket */
	struct sockaddr_in auth_name;    /* Internet-name of authentication service */
	auth_request request;            /* Request for authenticaton */
	auth_reply reply;                /* Reply to authentication request */
	fd_set main_read;                /* Mask for select on local socket */
	fd_set auth_fd;                  /* Mask for select on authentication socket */
	fd_set data_fd;                  /* Mask for select on data socket */
	int ret;                         /* Return-value of procedure-calls */
	int count;                       /* Counter */
#ifdef WIN32
	HANDLE shared_mem;
	char pwd[50];
#endif
#ifdef UNIX
	int shared_mem;                  /* File descriptor for shared memory segment */
#endif

#ifndef PROTOCOL
	struct sockaddr_in from;         /* Who requested connection? */
#endif
	struct sockaddr_in where;        /* Address to connect stdin etc. to */
	int fromlen = 
	  sizeof (struct sockaddr_in);   /* Length of above address */
	exec_data buf;                   /* Buffer for incoming execution-data */
	char *analyze;                   /* Used to parse variable part of exec-data */
	char *cwd;                       /* Pointer to current work directory */
	char newcwd[1024];               /* Buffer for automount-compatible path-name */
#ifndef PROTOCOL
	char *file;                      /* Name of the file to be executed */
#endif
	char **argv;                     /* List of arguments */
	char **envp;                     /* List of environment variables */
	int on = TRUE;                   /* Flag used to set in_socket into SO_REUSEADDR-mode */
	int authenticated;               /* Flag used to indicate whether authentication-message received */
	struct timeval auth_timeout;     /* Timeout-interval for authentication */
	struct timeval data_timeout;     /* Timeout-interval for receiving rexec_data */
#ifdef WIN32
	HANDLE hIn,hInMap;
	LPSTR addr_time;
	struct tm *incoming;
	struct tm *last_tmp_updated;
	struct tm **last_update=&last_tmp_updated;	/* Timestamp for incoming messages */
#endif

#ifdef UNIX
	struct timeval *last_update,      /* Timestamp for last update */
	incoming;                       /* Timestamp for incoming requests */
	caddr_t addr_time;               /* Address of shared memory segment */
#endif
	int main_mask;                   /* Signalmask to be stored */
 
#define ERROR(no)   result.kind = EXEC_ERROR; result.r_error = no; send(socks[last].socket, &result, sizeof (result), 0); 

#ifdef WIN32
	int hProc;
STARTUPINFO StartUp;
PROCESS_INFORMATION ProcessInfo;
SYSTEMTIME StartTimeSys, ExitTimeSys;
#endif
	/*
	 * Open syslog
	 */
#ifdef WIN32
WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99

	
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    	return;
	}
#endif
#ifdef UNIX
	OPENLOG(myname);
#endif	
	/*
	 * Set timeout-interval for authentication
	 */
	
	auth_timeout.tv_sec = (long) AUTH_TIMEOUT / 1000000;
	auth_timeout.tv_usec = (long) AUTH_TIMEOUT - (auth_timeout.tv_sec * 1000000);
	
	/*
	 * Set timeout-interval for getting job data from remote site
	 */
	
	data_timeout.tv_sec = (long) DATA_TIMEOUT / 1000000;
	data_timeout.tv_usec = (long) DATA_TIMEOUT - (data_timeout.tv_sec * 1000000);
	
	/*
	 * Open Internet-Domain-Socket for receiving connections from applications
	 */
	
	in_socket = socket(AF_INET, SOCK_STREAM, 0);
	
	if (in_socket < 0) {
#ifdef WIN32
		//printf("Rexec-Manager: Error opening stream socket\n");
		exit(1);
#endif
#ifdef UNIX
		syslog(LOG_ERR, "Rexec-Manager: Error opening stream socket : %m");
		exit(1);
#endif
	}
	
	/*
	 * Create shared memory for timestamps and local load
	 */
	
#ifdef ROOT_OWNER
#ifdef WIN32
  if (CreateDirectory(YALB_PATH,NULL)==TRUE && GetLastError()!=ERROR_ALREADY_EXISTS){
	   fprintf(stderr,"Rexec-Manager:Failure in Creating directory : %d \n", GetLastError());
		exit(-1);
  }
  	if (!SetCurrentDirectory(YALB_PATH) )
			exit(-1);
#endif

#ifdef UNIX  
  if (mkdir(YALB_PATH,0500) < 0 && errno != EEXIST) {
    syslog(LOG_ERR, "Rexec-Manager: YALB-directory not creatable! : %m");
    exit(-1);
	}
  if (chdir(YALB_PATH) < 0) {
    syslog(LOG_ERR, "Rexec-Manager: YALB-directory not accessable! : %m");
    exit(-1);
  }
#endif
#else 
#ifdef WIN32
  if (CreateDirectory(YALB_PATH,NULL)==TRUE && GetLastError()!=ERROR_ALREADY_EXISTS){
	   fprintf(stderr,"Rexec-Manager:Failure in Creating directory : %d \n", GetLastError());
		exit(-1);
  }
  	if (!SetCurrentDirectory(YALB_PATH) )
			exit(-1);
#endif

#ifdef UNIX  
  if (mkdir(YALB_PATH,0555) < 0 && errno != EEXIST) {
    syslog(LOG_ERR, "Rexec-Manager: YALB-directory not creatable! : %m");
    exit(-1);
	}
  if (chdir(YALB_PATH) < 0) {
    syslog(LOG_ERR, "Rexec-Manager: YALB-directory not accessable! : %m");
    exit(-1);
  }
#endif
  
#endif

 #ifdef WIN32
	hIn=CreateFile ("\\tmp\\yalb\\yalb.shared", GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	printf ("Error in creating File yalb.shared  %d\n", GetLastError());
	hInMap=CreateFileMapping(hIn,NULL,PAGE_READWRITE,0,sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float),NULL);
	printf ("Error in creating file mapping for yalb.shared  %d\n", GetLastError());

	addr_time=MapViewOfFile(hInMap,FILE_MAP_ALL_ACCESS,0,0,0);
	fprintf (stderr,"Rexec-Manager:Error in  mapping file for yalb.shared  %d\n", GetLastError());
	*last_update = (struct tm *) addr_time;
#endif

#ifdef UNIX
	#ifdef ROOT_OWNER
		shared_mem = open(SHARED,O_RDWR | O_CREAT, 0600);
	#else
		shared_mem = open(SHARED,O_RDWR | O_CREAT, 0666);
	#endif
	if (shared_mem < 0){
		syslog(LOG_ERR, "Rexec-Manager: Shared memory not available : %m");
		exit(1);
	}
 
  ftruncate (shared_mem, 4096);

  addr_time = mmap ((caddr_t)0, (size_t) (sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof (float) + sizeof(int)), 
		    PROT_WRITE | PROT_READ, MAP_SHARED, shared_mem, (off_t)0 );   
  
  if (addr_time == (caddr_t)-1)
    syslog(LOG_ERR, "Load-Daemon: getting shared segment (%m)");
  last_update = (struct timeval *) addr_time;
#endif

	/*
	 * Place number of imported and terminated jobs into shared memory
	 */
	
	temp_imported = (int *) (addr_time + sizeof(struct timeval) + sizeof(float) + sizeof(int));
	terminated = (float *) (addr_time + sizeof(struct timeval) + sizeof(float) + 2*sizeof(int));
	long_jobs = (int *) (addr_time + sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float));
	*terminated = 0;
	*temp_imported = 0;
	*long_jobs = 0;
	

	readsysconfig();

	/*
	 * Install signal handler for SIG_CONFIG_READ (SIG_CONFIG_READ is defined in system.h)
	 */
	
#ifdef WIN32
	SetConsoleCtrlHandler(SIG_CONFIG_READ, handle_SIG_CONFIG_READ);
#endif
#ifdef UNIX
	signal(SIG_CONFIG_READ, handle_SIG_CONFIG_READ);
#endif



	/*
	 * Get port number for service "remote"
	 */
	
	get_port = getservbyname(REMA_SERVICE, "tcp");
	/*printf("%d\n",WSAGetLastError());*/

	/*
	 * Bind name (port) to local socket
	 */
	
	my_name.sin_family = AF_INET;
	my_name.sin_port = get_port->s_port;
	my_name.sin_addr.s_addr =INADDR_ANY;
#ifdef WIN32
	setsockopt(in_socket, SOL_SOCKET, SO_REUSEADDR, &on, sizeof (on));
#endif
	if (bind(in_socket, (struct sockaddr *)&my_name, sizeof my_name) < 0) {
#ifdef WIN32
		printf("Rexec-Manager: Error binding local socket: \n");
		exit(1);
#endif
#ifdef UNIX
		syslog(LOG_ERR, "Rexec-Manager: Error binding local socket: %m");
		exit(1);
#endif
	}  
	
	/*
	 * Get port number for service "ldaemon". We need the loaddaemon for
	 * authentication.
	 */
	
	get_port = getservbyname(DAEMON_SERVICE, "udp");
	
	auth_name.sin_family = AF_INET;
	auth_name.sin_port = get_port->s_port;
	
	/*
	 * Open udp-socket used for authenticcation
	 */
	
	auth_server = socket(AF_INET, SOCK_DGRAM,0);
	
	/*
	 * Init authentication-message
	 */
	
	request.kind = AUTH_REQUEST;
	request.magic_number = MAGIC;
	
	/*
	 * Init result-message
	 */
	
	result.magic_number = MAGIC;
	
	/*
	 * Init notification-message
	 */
	
	notification.magic_number = MAGIC;
	
	/*
	 * Init file descriptor set for sockets with possible oob-data
	 */
	
	FD_ZERO(&exceptfds);
	
	/*
	 * We do not want to exit if we write to an unconnected socket, so
	 * ignore SIGPIPE
	 */
	
#ifdef UNIX
	signal (SIGPIPE, SIG_IGN);
#endif
	
	/*
	 * Init procs and socks data-structure
	 */
	
	for(count = 0 ; count< MAX_SOCKS; count++)
	  procs[count].proc_id = -1;
	
	for(count = 0; count < MAX_CONNECTS; count++)
	  socks[count].socket = -1;
	
	/*
	 * Mark socket as receiving connections. Parameter backlog not specified
	 */
#if 1
	/* XXX (schoenfr) better define a backlog; C is a wonderful trap... */
	if (listen (in_socket, 10) < 0)
	  {
	    #ifdef WIN32
		printf("Rexec-Manager: cannot listen; reason: \n");
	    exit(-1);
		#endif
	#ifdef UNIX
		syslog(LOG_ERR, "Rexec-Manager: cannot listen; reason: %m");
	    perror ("Rexec-Manager: cannot listen; reason");
	    exit(-1);
		#endif
	  }
#else	
	listen (in_socket);
	
#endif	


#ifdef UNIX
	signal(SIGCHLD, handle_SIGCHLD);
	signal(SIGURG, handle_SIGURG);
#endif

	/*
	 * Now wait for incoming requests of applications and accept them.
	 * According to the SUN Network Programming Guide, the accept-call is
	 * interruptable by a signal, whereas the man page says nothing
	 * about it...
	 */
	
	for(;;){
		
		do {
			
			/*
			 * Blocks indefintely unless signal is delivered or a connection
			 * is accepted...
			 */    
			
			ret = accept (in_socket, (struct sockaddr FAR  *)&from, &fromlen);
			
		} while ((errno == EINTR) && (ret < 0));
		
		
		if((errno != EINTR) && (ret < 0)) {
#ifdef WIN32
			//fprintf(stderr,"Rexec-Manager: Could not accept connecton: \n");

#endif
#ifdef UNIX
			syslog(LOG_ERR, "Rexec-Manager: Could not accept connecton: %m ");
#endif
			continue;
		}
		
		/*
		 * Determine free entry in socks data-structure
		 */
		
		for (last = 0; (last < MAX_CONNECTS) && (socks[last].socket >= 0); last++)
		    continue;
		
		/*
		 * Check whether maximum number of connections is exceeded. If so,
		 * shutdown and close socket
		 */
		
		if(socks[last].socket >= 0) {
			
			/*
			 * Send notification of refusal to remote site
			 */
			
			notification.kind = NO_EXECUTION;
			
			/*
			 * Send notification to remote host. We only care for
			 * interruptions due to signals.
			 */
			
			while ((send(ret,&notification, sizeof (notify), 0) < 0)
			       && (errno == EINTR)) ;
			shutdown(ret,2);
			close(ret);
			continue;
		}
		else {
			
			/*
			 * Send notification of acceptance to remote site
			 */
	
			notification.kind = EXECUTION_OK;
			
			/*
			 * Send notification to remote host. We only care for
			 * interruptions due to signals.
			 */
			
			while (send(ret,&notification, sizeof (notify), 0) < 0
			       && errno == EINTR) ;
			
#ifdef WIN32
			socks[last].socket =ret; /* ret-0x180; value of too large for WIN32*/
#else
	socks[last].socket = ret; /*value of too large for WIN32*/
#endif
#ifdef UNIX
			socks[last].socket = ret;
		
#endif
			sockslastsocket=ret;
			socks[last].host = from;
			imported++;
		}
#ifdef WIN32
	//fprintf(stderr,"Rexecmanger: Reached the stage after sending notification to remote site\n"); 
#endif
#ifdef UNIX
		syslog(LOG_ERR,"Rexecmanger: Reached the stage after sending notification to remote site\n"); /*added on 29.8.99*/	
#endif
		/*
		 * We read the incoming message. To avoid being blocked by a connection
		 * that does not send any request, we use a select with a timeout of
		 * DATA_TIMEOUT microseconds.
		 */
      
		FD_ZERO(&data_fd);
		FD_SET(sockslastsocket,&data_fd);
		while((ret = select(MAXWIDTH, &data_fd, (fd_set *)0, (fd_set *)0, NULL/* &data_timeout*/)) < 0 && errno == EINTR)
		    continue;
		
		/*
		 * Check whether timeout occured and no data was read. If so, close
		 * the socket and refuse any further requests from the connected socket.
		 * Continue work.
		 */
		
		if (ret <= 0) 
		{
			REFUSE;
			continue;
		}
		
		/*
		 * Otherwise get exec-data from socket. We must be careful at
		 * this point, because it is possible that not the whole
		 * exec_data structure is transmitted at one call of recv
		 */
#ifdef WIN32
		//fprintf(stderr,"Rexecmanger: just before receiving the command : %d\n", GetLastError()); /*added on 29.8.99*/	
#endif
#ifdef UNIX	
	syslog(LOG_ERR,"Rexecmanger: just before receiving the command \n"); /*added on 29.8.99*/	
#endif
	while ((ret = recv(sockslastsocket, (char *)(&buf),
				   sizeof (buf), 0)) < 0 && errno == EINTR)
		    continue;
		
		if (ret < 0) 
		{
			buf.kind == FALSE;
#ifdef WIN32
	//fprintf(stderr, "Rexec-Manager: Error reading exec_data : %d\n", GetLastError());

#endif
#ifdef UNIX
			syslog(LOG_ERR,
			       "Rexec-Manager: Error reading exec_data : %m ");
#endif
		}
#ifdef WIN32
	//fprintf(stderr,"Rexecmanger: Received command correctly\n"); /*added on 29.8.99*/	

#endif
#ifdef UNIX
		syslog(LOG_ERR,"Rexecmanger: Received command correctly\n"); /*added on 29.8.99*/	
#endif

		/*
		 * We received a message from remote site. 
		 * Check for correctness of
		 * magic number and message type. If message is incorrect,
		 * close socket, refuse any further requests from the connected
		 * socket and resume main loop.
		 */
		
		if (buf.kind != REQUEST_FOR_EXEC || buf.magic_number != MAGIC) 
		{
			REFUSE;
	#ifdef WIN32
	///fprintf(stderr,"Rexec-Manager: Job refused...\n");

#endif
#ifdef UNIX
			syslog(LOG_WARNING, "Rexec-Manager: Job refused...");
#endif
			continue;
		} 
		
		if (ret < buf.length)  
#ifdef WIN32
	fprintf(stderr,"Rexec-Manager: %d bytes received, %d bytes expected\n",ret, buf.length);
#endif
#ifdef UNIX
		  syslog(LOG_WARNING, "Rexec-Manager: %d bytes received, %d bytes expected",ret, buf.length);
#endif

		

		/* 
		 * XXX (schoenfr): short messages should be errors, 
		 * not only warnings... 
		 *
		 * XXX should we try to assemble a splitted message ?
		 */


		/*
		 * Incoming request seems to be correct. Now we try to
		 * contact the remote loaddaemon and demand an
		 * authentication of the remote site
		 */
#ifdef WIN32
	//fprintf(stderr,"Rexecmanger: Received command verified for correctness-contacting loaddaemon for authentication of remote site\n"); /*added on 29.8.99*/	
	memcpy(&auth_name.sin_addr.s_addr, &from.sin_addr.s_addr, sizeof (from.sin_addr.s_addr));
		
#endif
#ifdef UNIX
		syslog(LOG_ERR,"Rexecmanger: Received command verified for correctness-contacting loaddaemon for authentication of remote site\n"); /*added on 29.8.99*/	
		bcopy(&from.sin_addr.s_addr, &auth_name.sin_addr.s_addr,
		      sizeof (from.sin_addr.s_addr));
		
#endif
		
		request.port = from.sin_port;
		request.proc_nr = buf.proc_nr;
		request.sock_nr = buf.sock_nr;
#ifdef WIN32
		/*added on 5.12.99*/
	getuid(&request.ruid);
	getgid(&request.rgid);
#endif
#ifdef UNIX
		request.euid = buf.euid;
		request.ruid = buf.ruid;
		request.rgid = buf.rgid;
		request.egid = buf.egid;
		
		for (count=0;count<buf.ngroups;count++)
		  request.groups[count]=buf.groups[count];
#endif
		/*
		 * Wait for authentication. 
		 */
		
		{
			static stats_timeout timeout_info;

			timeout_info.count=0;
			authenticated = FALSE;
			
			while(timeout_info.count<MAX_TRIES && !authenticated) {
				
				/*
				 * Send request for authentication to remote Loaddaemon
				 */
			
				if (sendto(auth_server, &request, sizeof request,
					   0, (struct sockaddr_in *) &auth_name,
					   sizeof auth_name) < 0) {
#ifdef WIN32
				//fprintf(stderr,"Rexec-Manager: contacting authentication server: %d\n", GetLastError());

#endif
#ifdef UNIX
					syslog(LOG_ERR,
			"Rexec-Manager: contacting authentication server: %m");
#endif
					continue;
				}
				
				FD_ZERO(&auth_fd);
				FD_SET(auth_server, &auth_fd);
				
				/*
				 * Select for readability on authentication-socket 
				 */
				
				while((ret = select(MAXWIDTH, &auth_fd, (fd_set *)0, (fd_set *)0, &auth_timeout)) < 0 && errno == EINTR);
				
				timeout_info.count++;
				
				if (ret == 0)
				  continue;
				else if (ret < 0) {
#ifdef WIN32
				//fprintf(stderr,"Rexec-Manager: Error getting authentication from Loaddaemon: %d\n", GetLastError());

#endif
#ifdef UNIX
					syslog(LOG_ERR,
      "Rexec-Manager: Error getting authentication from Loaddaemon: %m");
#endif
					continue;
				}
				
				if(!FD_ISSET(auth_server, &auth_fd)) {
					continue;
				}
				
				/*
				 * Read Authentication-reply
				 */
				
				while ((ret = recvfrom(auth_server, &reply, 
				          sizeof reply, 0, (struct sockaddr_in  *) 
						       &where, &fromlen)) < 0 
				       && errno == EINTR);
				
				if (ret > 0) {
					authenticated = TRUE;
					continue;
				}
				else if (ret < 0) {
#ifdef WIN32
	fprintf(stderr,"Rexec-Manager: Error getting authentication from Loaddaemon: %d\n", GetLastError());

#endif
#ifdef UNIX
					syslog(LOG_ERR,
 "Rexec-Manager: Error getting authentication from Loaddaemon:  %m");
#endif
					continue;
				}
			}
			timeout_info.count--;
			if( timeout_info.count > 0 ) {
				/*
				 * Write statistics
				 */
				stats_write(STATS_TYPE_AUTH_TIMEOUT, (stats_info)&timeout_info);
			}
		}
#ifdef WIN32
	fprintf(stderr,"Rexecmanger: Received authentication mesg (Y/N) of remote site : %d\n", GetLastError()); 
#endif
#ifdef UNIX
	syslog(LOG_ERR,"Rexecmanger: Received authentication mesg (Y/N) of remote site\n"); 
#endif
		/*
		 * Now we examine incoming reply for correctness
		 */
		
		if(!authenticated || where.sin_port != auth_name.sin_port || reply.kind != AUTH_REPLY || reply.magic_number != MAGIC || reply.ok != TRUE) {
			fprintf(stderr,"authentication =%d\n",authenticated);
			fprintf(stderr,"where.sin_port=%d\n",where.sin_port);
			fprintf(stderr,"auth_name.sin_port=%d\n",auth_name.sin_port);
			fprintf(stderr,"reply.kind=%d\n",reply.kind);
			fprintf(stderr,"AUTH_REPLY=%d\n",AUTH_REPLY);
			fprintf(stderr,"reply.magic_number=%d\n",reply.magic_number);
			fprintf(stderr,"MAGIC=%d\n",MAGIC);
			fprintf(stderr,"reply.ok=%d\n",reply.ok);
			ERROR(NO_AUTHENTICATION);
			REFUSE;
#ifdef WIN32
			fprintf(stderr,"Rexecmanger: Received NEGATIVE authentication mesg of remote site: %d\n", GetLastError());  /*added on 29.8.99*/	
#endif
#ifdef UNIX

	syslog(LOG_ERR,"Rexecmanger: Received NEGATIVE authentication mesg of remote site\n"); /*added on 29.8.99*/	
#endif
	continue;
		}
#ifdef WIN32
	fprintf(stderr,"Rexecmanger: Received POSITIVE authentication mesg of remote site%d\n", GetLastError());  /*added on 29.8.99*/	
#endif
#ifdef UNIX
	syslog(LOG_ERR,"Rexecmanger: Received POSITIVE authentication mesg of remote site\n"); /*added on 29.8.99*/	
	
		/*
		 * Make sure the person's not trying to execute as a privileged user 
		 */
	
		#ifndef ROOT_OWNER
		if (buf.ruid <= 1024 || buf.euid <= 1024) {
			ERROR(NO_ROOT_EXEC);
			REFUSE;
			continue;
		}
		#endif
	
	syslog(LOG_ERR,"Rexecmanger: Verified that user is not trying priviliged command: analyzing other factors of command\n"); /*added on 29.8.99*/	
		
		/*
		 * Analyze variable part of exec-data
		 */
#endif

		analyze = buf.buf;
		
		/*
		 * Get current work directory and perform the one and only
		 * nase_check_path - function on it
		 */
		
		cwd = analyze;
		
		analyze += strlen(cwd) + 1;
		
		if (check_path (cwd, newcwd))
		  cwd = newcwd;
		
		/*
		 * Next data-item. Get the bin-file to execute
		 */
		
		file = analyze;
		
		/*
		 * Next data-item. Extract the arguments to be passed to the file
		 */
		
		analyze += strlen(file) + 1;
		
		/*
		 * Align the resulting pointer to longword boundary and extract argument vectors
		 */
		
		analyze = ALIGN(analyze, char *);
		
		argv = extract (&analyze);
		
		/*
		 * Align the resulting pointer to longword boundary and extract environment vectors
		 */
		
		analyze = ALIGN(analyze, char *);
		
		envp = extract (&analyze);

	
		/*
		 * Set address to connect stdin, stdout, stderr to
		 */
		
		where = from;
		where.sin_port = buf.port;
		
		/*
		 * Set owner of SIGURG to current process and insert socket into
		 * exceptfds to enable selecting for oob-data
		 */

#ifdef UNIX
		if (fcntl(socks[last].socket, F_SETOWN, getpid()) < 0) {
			ERROR(INTERNAL_ERROR);
			syslog(LOG_ERR, "Rexec-Manager: Error fcntl F_SETOWN: %m");
			exit(1);
		}
#endif	
		FD_SET(sockslastsocket, &exceptfds);
		
		/*
		 * Fork and execute given command 
		 */
		
		(*temp_imported)++;
		
		if( buf.jobkind == LONG_JOB ) {
			/*
			 * Mark the process as a long job and increase the number
			 * of long jobs in shared memory
			 */
			procs[socks[last].socket].long_job = TRUE;
			(*long_jobs)++;
		}
		else {
			procs[socks[last].socket].long_job = FALSE;
		}
		
		
#ifdef WIN32
		time(&(procs[socks[last].socket].started));
		GetCurrentDirectory(sizeof (pwd), pwd);

	/*
		UnmapViewOfFile(addr_time);
		CloseHandle(hInMap);
		CloseHandle(hIn);
		close(auth_server);
		close(in_socket);
		{ 
				int count;
				for(count=0; count < MAX_CONNECTS; count++) {
					if (socks[count].socket > 2)
					  close(socks[count].socket);
				}
			
			} 
*/

			/*
			 * Open socket for stdin, stdout, stderr and connect it to remote site
			 */
			
			sock = socket(AF_INET, SOCK_STREAM, 0);
			
			if (connect(sock,(struct sockaddr FAR *)&where, sizeof (where)) != 0) {
				/* 
				 // No correct remote socket specified, so we are in trouble
				 // here. We can't report any error-messages back to our
				 // client (is this our fault ?)...
				 */
				_exit(-1);
			}
			
							
			umask (buf.umask);
			
			/*
			 * Assign correct process-group to process
			 */
			
	SetCurrentDirectory(cwd);
		
	ForkAndExec(sock,argv,&procs[socks[last].socket].proc_id,pwd);


#if 0
			/* oh dear ... */
			free((char *)argv);
			free((char *)envp);
#endif			
		
			if(hProc==-1) {
			(*temp_imported)--;
			ERROR(NO_FORK);
			REFUSE;
		}
#endif
#ifdef UNIX
		gettimeofday(&(procs[socks[last].socket].started), (struct timezone *)0);
		main_mask = sigblock(~0);
	
		procs[socks[last].socket].proc_id = fork();

		if (procs[socks[last].socket].proc_id == 0) {
			
			/*
			 * Child process: executes given command
			 */
			
			int sock;          /* Socket for stdin, stdout, stderr */
			
			/*
			 * Reinstall standard signal-handlers for SIGURG, SIGCHLD and SIGPIPE
			 */
			
			signal (SIGPIPE, SIG_DFL);
			signal(SIGCHLD, SIG_DFL);
			signal(SIGURG, SIG_DFL);
			
			/*
			 * Unmap the shared memory segment and close attached file
			 */
			
			
			if( munmap(addr_time, (size_t) (sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float) + sizeof(int)) ) < 0){
				perror ("unmapping shared memory segment");
				exit(-1);
			}
			
			close(shared_mem);
			
			/*
			 * Close all sockets of parent
			 */
			
			close(auth_server);
			close(in_socket);
			
			{ 
				int count;
				for(count=0; count < MAX_CONNECTS; count++) {
					if (socks[count].socket > 2)
					  close(socks[count].socket);
				}
			}
			
	syslog(LOG_ERR,"Rexecmanger: After fork:cleared shared memory etc. Wil redirect the stdin/stdout etc. now.\n"); /*added on 29.8.99*/	
			/*
			 * Open socket for stdin, stdout, stderr and connect it to remote site
			 */
			
			sock = socket(AF_INET, SOCK_STREAM, 0);
			
			if (connect(sock, (struct sockaddr FAR  *)&where, sizeof (where)) != 0) {
				
				/* 
				 * No correct remote socket specified, so we are in trouble
				 * here. We can't report any error-messages back to our
				 * client (is this our fault ?)...
				 */
				exit(-1);
			}
	syslog(LOG_ERR,"Rexecmanger: After fork: No Error in connecting stdin/stdout etc. to remote m/c.\n"); /*added on 29.8.99*/	
			
			/*
			 * Redirect the process's stdin/out/err to remote site
			 */
			if (sock != 0) {
				dup2 (sock, 0);
			}
			if (sock != 1) {
				dup2 (sock, 1);
			}
			if (sock != 2) {
				dup2 (sock, 2);
			}
			
			if (sock > 2) {
				close(sock);
			}
			

			/*
			 * Set environment pointer
			 */
			
			environ = envp;
			
			/*
			 * Set group-id of user
			 */

			if (setregid (buf.rgid, buf.egid) < 0) {
			    /* Error: Could not group-id */
			    perror("Could not set group-id; reason");
			    _exit(-1);
			}

	syslog(LOG_ERR,"Rexecmanger: After fork: No Error in setregid\n"); /*added on 29.8.99*/	

#ifdef ROOT_OWNER
			
			/*
			 * Set groups of user
			 */
	
			if (setgroups (buf.ngroups, buf.groups) < 0) {
			    /* Error: Could not set groups */
			
				perror ("Could not set groups; reason");
			    exit (-1);

			}


			syslog(LOG_ERR,"Rexecmanger: After fork: No Error in setgroup\n"); /*added on 29.8.99*/	
		
#endif /* ROOT_OWNER */
			
			/*
			 * Set effective user-id of user
			 */
		
			if (setreuid (buf.ruid, buf.euid) < 0) {
				/* Error: Could not set user-id */
		
				perror("Could not call setreuid; reason");
				_exit (-1);

			}
			

			syslog(LOG_ERR,"Rexecmanger: After fork: No Error in euid\n"); /*added on 29.8.99*/	

																		   
		   /*
			 * Change directory to cwd of user
			 */

					if (chdir (cwd) < 0) {

						/* Error: Could not change directory */

				perror ("Could not change directory; reason");
			    exit (-1);

			}
	
	syslog(LOG_ERR,"Rexecmanger: After fork: No Error in cwd\n"); /*added on 29.8.99*/	
														  /*
			 * Set umask correctly
			 */
			
			umask (buf.umask);
			
			/*
			 * Assign correct process-group to process
			 */

			if (setpgrp (0, getpid()) < 0)
			{
			 
				perror ("Could not call setpgrp; reason");
			    _exit (-1);

			}
	syslog(LOG_ERR,"Rexecmanger: After fork: No Error in setgrp\n"); /*added on 29.8.99*/	
			
			/*
			 * Reinstall default sigmask
			 */
			
			sigsetmask(0);
		
			if( buf.jobkind == LONG_JOB && NICE > 0)
			    nice(NICE);
			
	syslog(LOG_ERR,"Rexecmanger: Ready to execvp\n"); /*added on 29.8.99*/	
	syslog(LOG_ERR,"File=%s\tArgv=%s\n",file,argv); /*added on 30.8.99*/	
			/*
			 * Execute given file
			 */
			execvp (file, argv);

	syslog(LOG_ERR,"Rexecmanger: After Execution: You see this only if no execution happened\n"); /*added on 29.8.99*/	
#if 0
			/* oh dear ... */
			free((char *)argv);
			free((char *)envp);
#endif			
			/*
			 * Should not be reached unless error in execution occured 
			 */
			
			/* Error: Could not execute file */			
			perror ("Could not execute file; reason");

			exit(-1);    /* This is only valid for the child process */
		}
		
		if(procs[socks[last].socket].proc_id < 0) {
			(*temp_imported)--;
			ERROR(NO_FORK);
			REFUSE;
		}
#endif	/*end of WIN32*/	
		
		{	/*
			 * Write statistics
			 */
			static struct hostent *host_ent;
			static stats_job_begin job_begin_info;

			job_begin_info.proc_nr = procs[socks[last].socket].proc_id;
			strcpy(job_begin_info.command, file);
			host_ent = gethostbyaddr((char *)&from.sin_addr.s_addr, sizeof (from.sin_addr.s_addr), AF_INET);
			strcpy(job_begin_info.from, host_ent->h_name); 
			stats_write(STATS_TYPE_JOB_BEGIN, (stats_info)&job_begin_info);
		}
#ifdef PROTOCOL    
		{
			FILE *stats;
			struct hostent *name;
			struct timeval time;
			char host[15];
			
			if(stats =  fopen("/tmp/rexec.log","a")) {
				name = gethostbyaddr((char *)&from.sin_addr.s_addr, sizeof (from.sin_addr.s_addr), AF_INET);
				gethostname(host, sizeof(host));
#ifdef WIN32
				time(&time);
#endif
#ifdef UNIX
		gettimeofday(&time, (struct timezone *)0);

#endif

				fprintf(stats,"Host: %10s Date: %15s Command received: %10s From host: %10s\n", host, ctime(&time.tv_sec), file, name->h_name);
				fclose(stats);
			}
		}
#endif
		
		free((char *)argv);
		free((char *)envp);
		
		/*
		 * deblock SIGCHLD and SIGURG
		 */

#ifdef UNIX
		sigsetmask(main_mask);
#endif
	}
		
	/*
	 * Never reached
	 */
	exit(0);
}
