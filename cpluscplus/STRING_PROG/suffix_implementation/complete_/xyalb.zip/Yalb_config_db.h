/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_config_db.h,v 1.0 1993/12/21 10:54:15 carlsson Exp $
 * $Log: yalb_config_db.h,v $
 * Revision 1.0  1993/12/21  10:54:15  carlsson
 * Initial revision
 *
 */

#ifndef _YALB_CONFIG_DB_H
#define _YALB_CONFIG_DB_H
#include "system.h"

#define TOPLIST_NAME "TOPLIST"
#define TOPHOST_NAME "TOPHOST"
#define YES_NAME "YES"
#define NO_NAME "NO"

#define DEFAULT_TIMEOUT 2000000
#define DEFAULT_POLL_TIMEOUT 80000
#define DEFAULT_SWAP_VALIDITY 10
#define DEFAULT_IDLE_HOST 0.95
#define DEFAULT_MINIMUM_TOP 3
#define DEFAULT_IMPROVMENT 30
#define DEFAULT_STRATEGY TOPLIST
/* default: no load polling - instead periodic load-broadcasts: */
#define DEFAULT_LOADPOLLING FALSE
#define DEFAULT_CHOOSE FALSE
#define DEFAULT_STATISTICS FALSE
#define DEFAULT_ALPHA 1.0
#define DEFAULT_SYS1 0.0
#define DEFAULT_SYS2 0.0
#define DEFAULT_MAX_LONG 3


#define TYPE_TIMEOUT 0
#define TYPE_SWAP_VALIDITY 1
#define TYPE_IDLE_HOST 2
#define TYPE_MINIMUM_TOP 3
#define TYPE_IMPROVMENT 4
#define TYPE_STRATEGY 5
#define TYPE_LOADPOLLING 6
#define TYPE_HOST 7
#define TYPE_OS_NAME 8
#define TYPE_CHOOSE 9
#define TYPE_STATISTICS 10
#define TYPE_ALPHA 11
#define TYPE_SYS1 12
#define TYPE_SYS2 13
#define TYPE_SWAP_SERVER 14
#define TYPE_MACHINE 15
#define TYPE_POLL_TIMEOUT 16
#define TYPE_MAX_LONG 17

#define OK_CFDB 0
#define ERR_CFDB_NO_DB -1
#define ERR_CFDB_OPEN -2
#define ERR_CFDB_FORMAT -3
#define ERR_CFDB_VALUE -4
#define ERR_CFDB_NOT_OPEN -5
#define ERR_CFDB_IS_OPEN -6
#define ERR_CFDB_NO_HOST -7
#define ERR_CFDB_NO_VALUE -8

#define YALB_CONFIG "yalb.config"

typedef enum strategy { TOPLIST, TOPHOST } strategy;

typedef struct system_config {
	long int timeout;
	int swap_validity;
	float idle_host;
	int minimum_top;
	int improvment;
	strategy strategy;
	int loadpolling;
	int statistics;
	long int poll_timeout;
} system_config;

typedef struct host_config {
	char name[MAXNAMELENGTH];
	char os_name[MAXNAMELENGTH];
	int choose;
	char swap_server[MAXNAMELENGTH];
	char machine[MAXNAMELENGTH];
	float alpha;
	float sys1;
	float sys2;
	int max_long;
} host_config;

typedef struct host_config_list {
	host_config host_config;
	struct host_config_list *rest_of_list;
} host_config_list;


extern int is_missval(int, void *);
extern int close_config(void);
extern int open_config(int *line_number);
extern void clear_host_config(host_config *out_host_config);
extern int read_host_config(host_config *out_host_config, char *in_host_name);
extern void clear_system_config(system_config *out_system_config);
extern int read_system_config(system_config *out_system_config);
extern int write_system_config(system_config *in_system_config);
extern int write_host_config(host_config *in_host_config);


#endif

