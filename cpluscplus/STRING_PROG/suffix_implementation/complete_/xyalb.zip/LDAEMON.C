/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */


/*
 * $Id: loaddaemon.c,v 1.2 1994/02/28 18:57:33 carlsson Exp $
 * $Log: loaddaemon.c,v $
 * Revision 1.2  1994/02/28  18:57:33  carlsson
 * Searching for bugs that doesn't exist.
 *
 * Revision 1.2  1994/02/28  18:57:33  carlsson
 * Searching for bugs that doesn't exist.
 *
 * Revision 1.1  1993/12/21  10:17:15  carlsson
 * The following global variables were added:
 * 	idle_host	- Max load for a host to be considered idle.
 * 	loadpolling	- TRUE if loaddaemon shall answer loadpolling requests.
 * 	max_long	- Max allowed long jobs for host to be considered 
 *			  available.
 * 	long_jobs	- Number of long jobs executing at host (Pointer
 *			  to shared memory).
 *
 * The following new functions were added:
 * 	close_all()		- Closes all resources allocated by the
 *				  loaddaemon.
 * 				  Used as callback function when initializing
 *				  the child process
 * 				  handling routines. It is called before a
 *				  new child process is
 * 				  started.
 * 	readhostdatabase()	- Reads host and system configuration.
 *
 * The following functions were changed:
 * 	calculate()	- If the number of executing long jobs at host
 *			  is greater than max_long
 * 			  the host is considered as inavailable.
 * 			  The load from long jobs is subtracted from the
 *			  total load (rungue -= (*long_jobs)
 * 	main()		- The hardcoded names in calls to getservbyname 
 *			  were changed to DAEMOMN_SERVICE
 * 			  and LOMA_SERVICE.
 * 			  The use of the child process handling routines 
 *			  were introduced to start and restart
 * 			  the loadmanager and the rexecmanager.
 * 			  The messages CONFIG_READ_SYS and CONFIG_READ_HOST
 *			  were introduced in order to answer
 * 			  the requests to reread system and host
 *			  configuration respectively.
 * 			  The message KILL_REQUEST was added to be able
 *			  to exit correctly.
 *
 * Revision 1.0  1993/12/02  14:49:32  stille
 * Initial revision
 */
/*#define _SVID_SOURCE*/
#define __USE_BSD
#define inline __inline__
#include "sysdef.h"
#include <math.h>
#include <stdio.h>
#ifdef LINUX
/*	#include <linux/module.h>*/
	#undef __KERNEL_STRICT_NAMES 
	#undef __LINUX_TYPES_H
	#define __GNUC__ 2
	#undef __STRICT_ANSI__
	#define CPUSTATES 2
	/*#include <asm/semaphore.h>
	#include <asm/atomic.h>
	#include <linux/types.h>*/
	#include <linux/sched.h>
	#include <linux/socket.h>
	#include <linux/signal.h>
	#include <linux/sys.h>
	#define TASK 0x001d61f4
	#define NGROUPS 4 /*correct value? ***??*/
	#ifdef OLDLNUX
		#define FD0 ((char *)&ts.files->fd[0] - (char *)&ts)
		#define AD(fd) (taskp+FD0+4*(fd))
	#else
		#define FILES ((char *)&ts.files - (char *)&ts)
		#define FD0 ((char *)&fs.fd[0] - (char *)&fs)
		#define AD(fd) (readvalz(taskp+FILES)+FD0+4*(fd))
		#define IND(fd) (readvalz(AD(fd))+(char *)&ofile.f_inode-(char *)&ofile)
		#define TYPE(fd) (readval(IND(fd))+(char *)&ind.i_sock-(char *)&ind)
		#define SKT(fd) (readvalz(IND(fd))+(char *)&ind.u-(char *)&ind)
		#define SKT_FAM(fd) (readvalz(SKT(fd)+(char *)&so.ops-(char *)&so)+(char *)&proto.family-(char *)&proto)
	#endif
		
#endif
#ifdef SUNOS
	#include <kvm.h>
	#include <nlist.h>
	#include <sys/dk.h>
	#include <vm/anon.h>
	#include <sys/vmmeter.h>
	#include <netinet/in_pcb.h>
	#include <sys/domain.h>
	#include <sys/socket.h>
	#include <sys/protosw.h>
	#include <sys/proc.h>
	#include <sys/unpcb.h>
	#include <sys/stat.h>
	#include <signal.h>
	#include <sys/resource.h>
	#include <net/route.h>
	#include <sys/socketvar.h>
	#include <sys/param.h>
	#define KERNEL
	#include <sys/file.h>
	#undef KERNEL
	#include <sys/user.h>
#endif
#ifdef WIN32
        #include <signal.h>
        #define CPUSTATES 2
	#define LMANAGER "lmanager" 
	#define RMANAGER "remote"
	#define YALB_DAEMON "\\usr\\local\\etc"
	#define LDAEMON_BASE "loaddaemon"
	#define ROOT_OWNER 
	#include <tchar.h>
	#include "ldaemon.h"

   #include "enumproc.h"
   #include <tlhelp32.h>
   #include <vdmdbg.h>

   typedef struct
   {
      DWORD          dwPID ;
      BOOL           bEnd ;
   } EnumInfoStruct ;

 
   DWORD WINAPI EnumProcs()
   {
      OSVERSIONINFO  osver ;
      HINSTANCE      hInstLib ;
      HINSTANCE      hInstLib2 ;
      HANDLE         hSnapShot ;
      PROCESSENTRY32 procentry ;
      BOOL           bFlag ;
      LPDWORD        lpdwPIDs ;
      DWORD          dwSize=0, dwSize2, dwIndex ;
      HMODULE        hMod ;
      HANDLE         hProcess ;
      char           szFileName[ MAX_PATH ] ;
      EnumInfoStruct sInfo ;

      /* ToolHelp Function Pointers.*/
      HANDLE (WINAPI *lpfCreateToolhelp32Snapshot)(DWORD,DWORD) ;
      BOOL (WINAPI *lpfProcess32First)(HANDLE,LPPROCESSENTRY32) ;
      BOOL (WINAPI *lpfProcess32Next)(HANDLE,LPPROCESSENTRY32) ;

      /* PSAPI Function Pointers.*/
      BOOL (WINAPI *lpfEnumProcesses)( DWORD *, DWORD cb, DWORD * );
      BOOL (WINAPI *lpfEnumProcessModules)( HANDLE, HMODULE *,
         DWORD, LPDWORD );
      DWORD (WINAPI *lpfGetModuleFileNameEx)( HANDLE, HMODULE,
         LPTSTR, DWORD );

      /* VDMDBG Function Pointers.*/
      INT (WINAPI *lpfVDMEnumTaskWOWEx)( DWORD,
         TASKENUMPROCEX  fp, LPARAM );


      /* Check to see if were running under Windows95 or
       Windows NT.*/
      osver.dwOSVersionInfoSize = sizeof( osver ) ;
      if( !GetVersionEx( &osver ) )
      {
         fprintf(stderr,"Error in getting  version\n");
		exit(-1);
      }

      /* If Windows NT:*/
      if( osver.dwPlatformId == VER_PLATFORM_WIN32_NT )
      {

         /* Load library and get the procedures explicitly. We do
          this so that we don't have to worry about modules using
          this code failing to load under Windows 95, because
          it can't resolve references to the PSAPI.DLL.*/
         hInstLib = LoadLibraryA( "PSAPI.DLL" ) ;
         if( hInstLib == NULL ){
 			fprintf(stderr,"Error in loading library PSAPI\n");
			exit(-1);
		}

         hInstLib2 = LoadLibraryA( "VDMDBG.DLL" ) ;
         if( hInstLib2 == NULL ){
			fprintf(stderr,"Error in loading VDMDBG\n");
			exit(-1);
		}
            
         /* Get procedure addresses.*/
         lpfEnumProcesses = (BOOL(WINAPI *)(DWORD *,DWORD,DWORD*))
            GetProcAddress( hInstLib, "EnumProcesses" ) ;
         lpfEnumProcessModules = (BOOL(WINAPI *)(HANDLE, HMODULE *,
            DWORD, LPDWORD)) GetProcAddress( hInstLib, "EnumProcessModules" ) ;
         lpfGetModuleFileNameEx =(DWORD (WINAPI *)(HANDLE, HMODULE,
            LPTSTR, DWORD )) GetProcAddress( hInstLib,
            "GetModuleFileNameExA" ) ;
         lpfVDMEnumTaskWOWEx =(INT(WINAPI *)( DWORD, TASKENUMPROCEX,
            LPARAM))GetProcAddress( hInstLib2, "VDMEnumTaskWOWEx" );
         if( lpfEnumProcesses == NULL ||
            lpfEnumProcessModules == NULL ||
            lpfGetModuleFileNameEx == NULL ||
            lpfVDMEnumTaskWOWEx == NULL)
            {
               FreeLibrary( hInstLib ) ;
               FreeLibrary( hInstLib2 ) ;
 				fprintf(stderr,"Error \n");
				exit(-1);
	  		}

         dwSize2 = 256 * sizeof( DWORD ) ;
         lpdwPIDs = NULL ;
         do
         {
            if( lpdwPIDs )
            {
               HeapFree( GetProcessHeap(), 0, lpdwPIDs ) ;
               dwSize2 *= 2 ;
            }
            lpdwPIDs = HeapAlloc( GetProcessHeap(), 0, dwSize2 );
            if( lpdwPIDs == NULL )
            {
               FreeLibrary( hInstLib ) ;
               FreeLibrary( hInstLib2 ) ;
 				fprintf(stderr,"Error \n");
				exit(-1);
			}	
            if( !lpfEnumProcesses( lpdwPIDs, dwSize2, &dwSize ) )
            {
               HeapFree( GetProcessHeap(), 0, lpdwPIDs ) ;
               FreeLibrary( hInstLib ) ;
               FreeLibrary( hInstLib2 ) ;
 				fprintf(stderr,"Error \n");
				exit(-1);
			}
         }while( dwSize == dwSize2 ) ;

         /* How many ProcID's did we get?*/
         dwSize /= sizeof( DWORD ) ;

         HeapFree( GetProcessHeap(), 0, lpdwPIDs ) ;
         FreeLibrary( hInstLib2 ) ;

	return dwSize;
      /* If Windows 95:*/
      }else if( osver.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
      {


         hInstLib = LoadLibraryA( "Kernel32.DLL" ) ;
         if( hInstLib == NULL ){
			fprintf(stderr,"Error \n");
			exit(-1);
		}

         /* Get procedure addresses.
          We are linking to these functions of Kernel32
          explicitly, because otherwise a module using
          this code would fail to load under Windows NT,
          which does not have the Toolhelp32
          functions in the Kernel 32.*/
         lpfCreateToolhelp32Snapshot=
            (HANDLE(WINAPI *)(DWORD,DWORD))
            GetProcAddress( hInstLib,
            "CreateToolhelp32Snapshot" ) ;
         lpfProcess32First=
            (BOOL(WINAPI *)(HANDLE,LPPROCESSENTRY32))
            GetProcAddress( hInstLib, "Process32First" ) ;
         lpfProcess32Next=
            (BOOL(WINAPI *)(HANDLE,LPPROCESSENTRY32))
            GetProcAddress( hInstLib, "Process32Next" ) ;
         if( lpfProcess32Next == NULL ||
            lpfProcess32First == NULL ||
            lpfCreateToolhelp32Snapshot == NULL )
         {
            FreeLibrary( hInstLib ) ;
			fprintf(stderr,"Error \n");
			exit(-1);

         }

         /* Get a handle to a Toolhelp snapshot of the systems
          processes.*/
         hSnapShot = lpfCreateToolhelp32Snapshot(
            TH32CS_SNAPPROCESS, 0 ) ;
         if( hSnapShot == INVALID_HANDLE_VALUE )
         {
            FreeLibrary( hInstLib ) ;
			fprintf(stderr,"Error \n");
			exit(-1);

         }

         /* Get the first process' information.*/
         procentry.dwSize = sizeof(PROCESSENTRY32) ;
         bFlag = lpfProcess32First( hSnapShot, &procentry ) ;

         /* While there are processes, keep looping.*/
         while( bFlag )
         {
             dwSize++;
	           bFlag = lpfProcess32Next( hSnapShot, &procentry );
           }


     

      /* Free the library.*/

      FreeLibrary( hInstLib ) ;

      return dwSize ;
   }
}


#endif


#include "children.h"
#include "yalb_config_db.h"
#include "reconfig.h"


#define MAXSYMBOL 10
#define MAXWIDTH 10
#define TRUE 1
#define FALSE 0

#ifndef UPDATE
	#define UPDATE 500                /* Update interval for load information (in sec) */
#endif /* !UPDATE */

#ifndef SECONDS
	#define SECONDS 30                  /* Smoothing interval (not needed) */
#endif /* !SECONDS */

char myname[] = "loaddaemon";

#ifdef LINUX
	int kfd;                      /* File Pointer to /dev/kmem */
	int taskp;      
	int socketp;      
	struct task_struct ts;
	struct files_struct fs;
	struct file ofile;             /* File structure of a kernel object */
	struct file *fileptr;          /* Pointer to above mentioned structure */
	struct inode ind;              /* Inode structure */
	struct socket so;              /* Socket structure */
	struct proto_ops proto;          /* Socket protocol structure */
	int dom;             /* Domain of given socket */
	struct uid_credit{
		unsigned short uid,euid,suid,fsuid;
		unsigned short gid,egid,sgid,fsgid;
	}credits;

	int procgrps[NGROUPS];
#endif

#ifdef WIN32

	int kfd;  
	struct uid_credit{
		PSID uid;
		PSID gid;
	};
#endif

#ifdef SUNOS
	struct nlist symbole[MAXSYMBOL];  /* List of symbols to be read from kernel */ 
	kvm_t *mptr;                      /* Pointer to kmem */
#endif

float idle_host;                  /* Max load for a host to be considered idle */
int loadpolling;                  /* Should loaddaemon answer loadpolling requests */
int max_long;                     /* Max long lived jobs allowed on host for considering host available */
float arch_factor;                /* Architecture-dependent speed-factor */
float system_factor1,             /* Architecture-dependent system-factor for low system load */
	system_factor2;                 /* Architecture-dependent system-factor for high system load */
int transmit;                         /* Flag for sending load information to remote hosts */
rpc_message info;                 /* Message body for load broadcast */
int first = 1;                    /* Flag for first run */
static float old_load;            /* Old load index needed to
				   * determine whether broadcast of new
				   * load index is needed */
static int old_avail;             /* Old availability flag needed to
				   * determine whether broadcast of new
				   * load index is needed */
#ifdef WIN32
	struct tm *incoming;
	struct tm *last_tmp_updated;
	struct tm **last_update=&last_tmp_updated;	/* Timestamp for incoming messages */
#endif

#ifdef UNIX
	struct timeval *last_update,      /* Timestamp for last update */
	incoming;                       /* Timestamp for incoming requests */
#endif

int sock;                         /* Descriptor for UDP-socket */
struct sockaddr_in  remote;       /* Broadcast-Address of remote socket */
char host_name[MAXNAMELENGTH];               /* Name of local host  */
float *local_load;                /* Local load for shared memory */
int *availability;                /* Local availability for shared memory */
float *terminated;                /* Number of terminated jobs since last update of load-information */
int *temp_imported;               /* Number of jobs imported since last update of load-information */
int *long_jobs;                   /* Number of long jobs executing at host */
#ifdef WIN32
	HANDLE hIn,hInMap;
	LPSTR addr_time;
	static HANDLE shared_mem;                   /* File descriptor for shared memory segment */
#else
	caddr_t addr_time;               /* Address of shared memory segment */
	static int shared_mem;                   /* File descriptor for shared memory segment */
#endif
/*
 * close_all closes all open files, sockets, kvm, syslog  and 
 * shared memory segments.
 * It is used as the call back function in call to init_children
 * and will be called every time a children is started or restarted.
 */

static void close_all(void)
{
	#ifdef WIN32
		UnmapViewOfFile(addr_time);
		CloseHandle(hInMap);
		CloseHandle(hIn);
	#endif
		
	#ifdef UNIX
		(void)munmap(addr_time, (size_t) (sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float)));
		close(sock);
		close(shared_mem);
	#endif		
	
	#if defined(LINUX) || (defined WIN32)
		close(kfd);
	#endif

	#ifdef SUNOS
		kvm_close(mptr);
	#endif
	#ifdef UNIX
		closelog();
	#endif
}

/*
 * Authenticates a given uid and returns TRUE if authenticated, FALSE
 * otherwise 
 */
#ifdef LINUX 

int readval(int ad){
	int val,r;

	if (lseek(kfd,ad,SEEK_SET)<0){
		perror("lseek"); exit(1);
	}
	if((r=read(kfd,&val,4))!=4){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
	return val;
}

int readvalz(int ad){
	int r=readval(ad);

	if(r==0) fprintf(stderr,"Error reading ..\n");
	return r;
}

void readtask(int ad){
	int r;

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,&ts,sizeof(struct task_struct)))!=sizeof(struct task_struct)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
}

void readsocket(int ad){
	int r;

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,&so,sizeof(struct socket)))!=sizeof(struct socket)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
}

void findtask(int pid){
	int adr;

	for(adr=TASK;;adr+=4){
		if (adr>=TASK+4*NR_TASKS){
			fprintf(stderr,"Proc not found ..\n"); 
		}		
		taskp=readval(adr);
		readtask(taskp);
		if (ts.pid==pid) break;
	}
}
void readcred(struct uid_credit *credits){
	int r;
	int ad=taskp+(char *)&ts.uid-(char *)&ts;

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,credits,sizeof(struct uid_credit)))!=sizeof(struct uid_credit)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
}

void readgroups(int *procgrps){
	int r;
	int ad=taskp+(char *)&ts.groups[0]-(char *)&ts;

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,procgrps,NGROUPS*sizeof(int)))!=NGROUPS*sizeof(int)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
}

void readfile(int sock_nr, struct file *fileptr){
	int r;
	int ad=AD(sock_nr);

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,(char *)fileptr,sizeof(struct files_struct)))!=sizeof(struct files_struct)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
}

unsigned char readfdtype(int sock_nr){
	unsigned char chr;
	int r,ad=TYPE(sock_nr);

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,&chr,sizeof(unsigned char)))!=sizeof(unsigned char)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
return chr;
}

int readfmaily(int ad){
	int ret,r;

	if (lseek(kfd,ad,SEEK_SET)<0)
		perror("lseek"), exit(1);
	if((r=read(kfd,&ret,sizeof(int)))!=sizeof(int)){
		if (r<0) perror("read");
		else fprintf(stderr,"Error reading ..\n");
		exit(1);
	}
	return ret;
}


int authenticate(what)
auth_request *what;
{
	int count=0;

  /*
   * In Linux we read the task structure first
   */
	findtask(what->proc_nr);
  
  /*
   * Try to read the credentials of the calling process
   */
  
	readcred(&credits);
  
	if(credits.euid != what->euid ||
		credits.egid != what->egid ||
		credits.uid != what->ruid ||
		credits.gid != what->rgid){
		return FALSE;
	}
	fprintf(stderr,"User ids authenticated\n");/*added on 29.8.99*/ 
  /*
   * Now let's proof the user groups sent by the calling process
   */
	readgroups(procgrps); 
	{
		int count = 0;
  
		for (;procgrps[count] >= 0; count++) 
			if(procgrps[count] != what->groups[count]){
				return FALSE;
			}
	}

	fprintf(stderr,"User Proc grs authenticated\n");/*added on 29.8.99*/ 

	return TRUE; /*added on 29.8.99*/
/*
 * Now, we read the ofile structure for the socket
 * on which the request occured. 
 */

	readfile(what->sock_nr,&ofile); 
  

/*
 * Now we can consider the type (file/socket) of the kernel object.
 * If not a socket, somebody tried to cheat us !
 */

	if (readfdtype(what->sock_nr) != S_IFSOCK){
		return FALSE;
	}

	fprintf(stderr,"SOCKETTYPE authenticated\n");/*added on 29.8.99*/ 
/*
 * Consider the protocol domain of the socket
 */
	readsocket(SKT(what->sock_nr));

	if (readfamily(SKT_FAM(what->sock_nr)) != AF_INET){
		return FALSE;
	}

/*
 * Given port and user-id are correct!
 */

	return TRUE;

}

#endif

#ifdef SUNOS 
int authenticate(what)
auth_request *what;
{
  struct proc *process;          /* Pointer to proc structure of given process */
  struct user *user;             /* Pointer to user structure of given process */
  struct file ofile;             /* File structure of a kernel object */
  struct file *fileptr;          /* Pointer to above mentioned structure */
  struct socket so;              /* Socket structure */
  struct protosw proto;          /* Socket protocol structure */
  struct domain dom;             /* Domain of given socket */
  struct inpcb pcb;
  struct ucred credits;          /* Process credentials */
  int count=0;

  
  /*
   * Fortunately, we have the kvm routines to read certain infomation
   * from the kernel. First, we read the process-structure of the
   * calling process, if any. 
   */
  

	while ((process = kvm_getproc(mptr, what->proc_nr)) == NULL) {
		count++;
		if (count == 10){
			return FALSE;
		}
	}
  
  /*
   * Try to read the credentials of the calling process
   */
  
  if(kvm_read(mptr, process->p_cred, (char *) &credits, sizeof (credits)) != sizeof (credits)){
    return FALSE;
  }
  
  if(credits.cr_uid != what->euid ||
     credits.cr_gid != what->egid ||
     credits.cr_ruid != what->ruid ||
     credits.cr_rgid != what->rgid){
    return FALSE;
  }
  
  /*
   * Now let's proof the user groups sent by the calling process
   */
  
	{
		int count = 0;
  
		for (;credits.cr_groups[count] >= 0; count++) 
			if(credits.cr_groups[count] != what->groups[count]){
				return FALSE;
			}
	}


/*
 * Next, we read its user structure from the kernel
 */

	if((user = kvm_getu(mptr, process)) == NULL){
		return FALSE;
	}


/*
 * Now, we should be able to read the ofile structure for the socket
 * on which the request occured. First, we consider the easy case
 * that the file structure for the socket is in the user-area
 * itself. This is indicated by a socket number less than
 * NOFILE_IN_U 
 */

	if (what->sock_nr < NOFILE_IN_U) {
		if(kvm_read(mptr, user->u_ofile_arr[what->sock_nr], (char *) &ofile, sizeof (struct file)) != sizeof (struct file)){
			return FALSE;
		}
	}
	else
  
  /*
   * Consider the slightly complicated case that the file structure is
   * in dynamically allocated storage. First read the appropriate
   * address in kernel... 
   */
	{
		if (kvm_read(mptr, (user->u_ofile + ((what->sock_nr - NOFILE_IN_U) * sizeof (struct file *))), 
	       (char *) &fileptr, sizeof (struct file *)) != sizeof (struct file *)){
				return FALSE;
		}
  
  /*
   * ... then get the file structure
   */
  
		if (kvm_read(mptr, fileptr, (char *) &ofile, sizeof (struct file)) != sizeof (struct file)){
			return FALSE;
		}
	}

/*
 * Now we can consider the type (file/socket) of the kernel object.
 * If not a socket, somebody tried to cheat us !
 */

	if (ofile.f_type != DTYPE_SOCKET){
		return FALSE;
	}

/*
 * Read socket structure 
 */

	if (kvm_read(mptr, ofile.f_data, &so, sizeof (so)) != sizeof (so) || so.so_pcb == NULL){
		return FALSE;
	}

/*
 * Consider the protocol data structure and the domain of the socket
 */

	if (kvm_read(mptr, so.so_proto, &proto, sizeof (proto)) != sizeof (proto)){
		return FALSE;
	}

	if (kvm_read(mptr, proto.pr_domain, (char *) &dom, sizeof (struct domain)) != sizeof (struct domain) ||
    dom.dom_family != PF_INET){
		return FALSE;
	}

/*
 * Now we finally (!!) read the inpcb structure which contains the port
 * of the socket
 */

	if (kvm_read(mptr, so.so_pcb, (char *) &pcb, sizeof (pcb)) != sizeof(pcb) ||
    pcb.inp_lport != what->port){
		return FALSE;
	}


/*
 * Given port and user-id are correct!
 */

	return TRUE;

}
#endif

#ifdef WIN32

BOOL readcred(int procId, PSID credits_uid,PSID credits_gid ){
	
       
      HANDLE               hToken;
      TOKEN_OWNER          ptuOwner[256];
      TOKEN_PRIMARY_GROUP  ptuGroup[256];
      DWORD                cbBuffer=256;
      PSID                 pUserSid;
      OpenProcessToken(procId,TOKEN_READ,&hToken);

      GetTokenInformation(hToken,TokenOwner,ptuOwner,cbBuffer,&cbBuffer);

     if (credits_uid != ptuOwner->Owner) return FALSE;
		
	  GetTokenInformation(hToken,TokenGroups,ptuGroup,cbBuffer,&cbBuffer);

      if (credits_gid != ptuGroup->PrimaryGroup) return FALSE;
	

/*      CloseHandle(hToken);*/
	    return TRUE;


}


int authenticate(what)
auth_request *what;
{
  SOCKET so;              /* Socket structure */
  int sotype;
  int solen=sizeof(int);
  typedef  struct _PROTOCOL_INFO { 
    DWORD  dwServiceFlags; 
    INT  iAddressFamily; 
    INT  iMaxSockAddr; 
    INT  iMinSockAddr; 
    INT  iSocketType; 
    INT  iProtocol; 
    DWORD  dwMessageSize; 
    LPTSTR  lpProtocol; 
} PROTOCOL_INFO; 
 

struct 	_PROTOCOL_INFO soproto;          /* Socket protocol structure */
  PSID  credits_uid;          /* Process credentials */
  PSID credits_gid;
  int count=0;

  //return TRUE; //authentication put off for the time being
 

  /*
   * Try to read the credentials of the calling process
   */
  
   if (!readcred(what->proc_nr,what->ruid, what->rgid))
	   return FALSE;
   
  /*readcred(what->proc_nr,what->ruid, what->gid);
	if(credits_uid != what->ruid ||
		credits_gid != what->rgid){
		return FALSE;
	}
	fprintf(stderr,"User ids authenticated\n");/*added on 29.8.99*/ 
  /*
   * Now let's proof the user groups sent by the calling process
   */
/*We can verify ACL Lists in similar way--presently not implemented**/

/*
 * Now, we verify that the request does not come from disk/char file/pipes
 * 
 */

#ifdef WIN95
	if (GetFileType(what->sock_nr)!=FILE_TYPE_UNKNOWN)
		return FALSE;
#endif
#ifdef WINNT
	if (GetFileType(what->sock_nr)!=FILE_TYPE_PIPE)
		return FALSE;
#endif

/*
 * Consider the protocol domain of the socket
 */
#ifdef WIN95
	/*This must be a bug in Windows 95--getsockopt does not work--error WSAENOTSOCK (10038) even if sock descriptor is valid
	if (getsockopt((SOCKET)what->sock_nr,SOL_SOCKET,SO_TYPE,(char *)&sotype, (int *)&solen))
		fprintf(stderr,"Error in getting socket type =%d\n",WSAGetLastError());

		if (sotype!=SOCK_DGRAM) return FALSE;*/

#else
	if (getsockopt(what->sock_nr,SOL_SOCKET,SO_TYPE,&sotype, &solen))
		fprintf(stderr,"Error in getting socket type =%d\n",WSAGetLastError());

		if (sotype!=SOCK_DGRAM) return FALSE;
#endif
return TRUE;

}
#endif






void readhostdatabase(void)
{
	host_config local_host_config;
	system_config local_system_config;
	int linenr;

	switch( open_config(&linenr) ) {
	      case ERR_CFDB_OPEN:
		fprintf(stderr, "Cant open configuration file\n");
		exit(-1);
		break;
	      case OK_CFDB:
		break;
	      default:
		fprintf(stderr, "Error at line %d in configuration file", linenr);
		exit(-1);
		break;
	}
	if( read_host_config(&local_host_config, host_name) != OK_CFDB ||
	   local_host_config.choose != TRUE ) {
		fprintf(stderr, "This host is not configuered as part of Rexec-System.\nUse yalb_host_config to configure host.\n");
		if (local_host_config.choose !=TRUE) fprintf(stderr, "This host is not chosen.\n"); /*added on 3.9.99*/
		exit(-1);
	}
	if( read_system_config(&local_system_config) != OK_CFDB ) {
		fprintf(stderr, "Cant read system configuration.\n");
		exit(-1);
	}
	if( !is_missval(TYPE_IDLE_HOST, (void *)&local_system_config.idle_host) ) {
		idle_host = local_system_config.idle_host;
	}
	else {
		idle_host = DEFAULT_IDLE_HOST;
	}
	if( !is_missval(TYPE_LOADPOLLING, (void *)&local_system_config.loadpolling ) ) {
		loadpolling = local_system_config.loadpolling;
	}
	else {
		loadpolling = DEFAULT_LOADPOLLING;
	}
	if( !is_missval(TYPE_ALPHA, (void *)&local_host_config.alpha) ) {
		arch_factor = local_host_config.alpha;
	}
	else {
		arch_factor = DEFAULT_ALPHA;
	}
	if( !is_missval(TYPE_SYS1, (void *)&local_host_config.sys1) ) {
		system_factor1 = local_host_config.sys1;
	}
	else {
		system_factor1 = DEFAULT_SYS1;
	}
	if( !is_missval(TYPE_SYS2, (void *)&local_host_config.sys2) ) {
		system_factor2 = local_host_config.sys2;
	}
	else {
		system_factor2 = DEFAULT_SYS2;
	}

	if( !is_missval(TYPE_MAX_LONG, (void *)&local_host_config.max_long) ) {
		max_long = local_host_config.max_long;
	}
	else {
		max_long = DEFAULT_MAX_LONG;
	}
	
	close_config();
	printf ("Read the host databas\n");
}











/*
 * Procedure to broadcast load-information and save old load-information
 */


void broadcast_load()

{
#ifdef WIN32
	time_t ltime;
#endif
#if 0  
  *last_update = incoming;
#else
  /* XXX: check rc */
#ifdef WIN32
		time(&ltime);
		*last_update=gmtime(&ltime);
#endif
		
#ifdef UNIX
  gettimeofday (last_update, (struct timezone *) 0);
#endif

#endif /*end of 0*/

fprintf(stderr,"Loaddaemon before broadcasting load\n");
  if (sendto(sock, &info , sizeof info, 0,(struct sockaddr *)&remote, sizeof remote) < 0)
    #ifdef WIN32 
		  fprintf(stderr,"Load-Daemon: Error broadcasting load_index --to all:%d \n", GetLastError());
	#else
		syslog(LOG_ERR, "Load-Daemon: Error broadcasting load_index --to all: %m");
	#endif
  /*
   * Save last load information broadcasted
   */
  
  old_avail = info.data_avail;
  old_load = info.data_load;
}

/*
 * Procedure to send back the current load to the sender only
 */

void send_load(from)
struct sockaddr_in *from;
{
  
  *last_update = incoming;
  
  if (sendto(sock, &info , sizeof info, 0,(struct sockaddr *)from, sizeof *from) < 0)
	#ifdef WIN32 
		 fprintf(stderr,"Load-Daemon: Error broadcasting load_index  to a particular server: %d \n", GetLastError());
	#else
		syslog(LOG_ERR, "Load-Daemon: Error broadcasting load_index  to a particular server (%m)");
	#endif
  /*
   * Save last load information broadcasted
   */
  old_avail = info.data_avail;
  old_load = info.data_load;
}

#ifdef LINUX
void readswap(struct sysinfo *swapinfo)
{
	sysinfo(swapinfo);
}

void readcputime(unsigned long *cptimeptr)
{
	findtask(1);
	*cptimeptr=ts.cutime;
	*(cptimeptr+1)=ts.cstime;
}
#endif




/*
 * Function for handling SIGALARM
 *
 * Gathers statistics and calculates the load index
 * Sets new timer at end of execution
 * 
 */
#ifdef WIN32
void CALLBACK calculate(HWND hWnd,UINT uMsg,UINT uEvent,DWORD dwTime)
#endif
#ifdef UNIX
void calculate()
#endif
{
  static int ret;                           /* Return value of function calls */
#ifdef WIN32
 struct { // mst 
    DWORD dwLength;        // sizeof(MEMORYSTATUS) 
    DWORD dwMemoryLoad;    // percent of memory in use 
    DWORD dwTotalPhys;     // bytes of physical memory 
    DWORD dwAvailPhys;     // free physical memory bytes 
    DWORD dwTotalPageFile; // bytes of paging file 
    DWORD dwAvailPageFile; // free bytes of paging file 
    DWORD dwTotalVirtual;  // user bytes of address space 
    DWORD dwAvailVirtual;  // free user bytes 
  } msInfo; 
  struct { // ft     
	 DWORD dwLowDateTime; 
    DWORD dwHighDateTime; } crTime,exTime,kernelTime, userTime; 
	DWORD aProcesses[1024], cbNeeded, cProcesses;  
	struct tm *tv;
  time_t ltime;
#endif

#ifdef UNIX
  static struct sysinfo swapinfo;          /* Swap/Memory info from kernel */
  struct timeval tv;
#endif
  
#ifdef SUNOS
  static struct vmtotal itotal;             /* For determining the
					     * local runqueue (CPU) */
  static struct anoninfo swapinfo;          /* Swap info from kernel */
   static long aven[3];
 
#endif

  static unsigned long cptime[CPUSTATES];            /* Ticks per CPU-state */
  static long oldcptime[CPUSTATES];         /* Previous ticks per CPU-state */
  static float cpuusage[CPUSTATES];         /* Averaged CPU usage */
  static float runqueue = 0.0;              /* Averaged runqueue (CPU) */
  int i;                                    /* Counter */
  static int broadcast;                     /* Flag whether broadcast is to be forced */
  static float smoothing;                   /* Used for smoothing the runqueue */

 info.data_avail = TRUE;

#ifdef  WIN32 
  	cProcesses = EnumProcs(); 
	GlobalMemoryStatus(&msInfo);
#ifndef USE_AVENRUN
    if (!GetProcessTimes(GetCurrentProcess(),&crTime,&exTime,&kernelTime,&userTime))
		fprintf(stderr,"Error in GetProcessTimes %d\n",GetLastError());
	else {
		cptime[0]=userTime.dwLowDateTime/10000000;
		cptime[1]=kernelTime.dwLowDateTime/10000000;
	}
#else

  /*
   * Calculate basic load index...
   */
  
  info.data_load = msInfo.dwMemoryLoad;

#endif
#endif

 	
#ifdef LINUX
	readswap(&swapinfo);
#ifndef USE_AVENRUN
	readcputime(cptime);
#else

  /*
   * Calculate basic load index...
   */
  
  info.data_load = swapinfo.load[0] / 256.0;
#endif
#endif

#ifdef SUNOS
	  
#ifndef USE_AVENRUN
 if ((ret = kvm_read (mptr, symbole[0].n_value , &itotal, sizeof itotal)) != sizeof itotal){
    syslog(LOG_ERR, "Load-Daemon: Error reading runqueue from kernel (%m)");
  }
 if ((ret = kvm_read (mptr, symbole[1].n_value , &swapinfo, sizeof swapinfo)) != sizeof swapinfo){
    syslog(LOG_ERR, "Load-Daemon: reading swapinfo from kernel (%m)");
  }
  if ((ret = kvm_read (mptr, symbole[2].n_value , &cptime, sizeof cptime)) != sizeof cptime){
    syslog(LOG_ERR, "Load-Daemon: reading cptimeinfo from kernel (%m)");
  }
   if (itotal.t_sw > 0){
    info.data_avail = FALSE;
  }
#else

   if ((ret = kvm_read (mptr, symbole[0].n_value , aven, sizeof(aven))) != sizeof(aven)){
    syslog(LOG_ERR, "Load-Daemon: reading runqueue from kernel (%m)");
  }
  
 

  /*
   * Calculate basic load index...
   */
  
  info.data_load = (float) aven[0] / 256.0;
#endif

#endif
  
 
#ifndef USE_AVENRUN
  if (first){
    for (i=0 ; i<CPUSTATES ; i++)
      oldcptime[i]=cptime[i];
    old_load = 10;    /* force broadcast for load-index */
    smoothing = (float) exp(-(double)UPDATE/(double)SECONDS);
  }
  
  /*
   * Examine swap space available 
   */
 
#ifdef UNIX
  if (((float)swapinfo.freeswap / (float)swapinfo.totalswap) < (SWAP_AVAIL / 100.0)){
    info.data_avail = FALSE;
  }
  /*
   * Examine swapped processes
   */
   if (swapinfo.freeswap<swapinfo.totalswap){
    info.data_avail = FALSE;
  }
#endif

#ifdef WIN32
  if (((float)msInfo.dwAvailVirtual/ (float)msInfo.dwTotalVirtual) < (SWAP_AVAIL / 100.0)){
    info.data_avail = FALSE;
  }
  /*
   * Examine swapped processes
   */
   if (msInfo.dwAvailVirtual<msInfo.dwTotalVirtual){
    info.data_avail = FALSE;
  }
#endif
   /*
   * Calculate average CPU-usage for all CPU-states (This could be
   * restricted to system time only, since no other value is needed
   * for the load-index). That's the way I do it now!
   */
  
    cpuusage[SYSTEM] = (cptime[SYSTEM] -  oldcptime[SYSTEM]);
    oldcptime[SYSTEM] = cptime[SYSTEM];
  
#endif

  if( *long_jobs >= max_long ) {
	  info.data_avail = FALSE;
  }

  /*
   * Update availability in shared memory segment
   */
  
  *availability = info.data_avail;
  
  
  /*
   * Calculate average runqueue (CPU)
   */
#ifdef UNIX
  runqueue = (smoothing * runqueue + (float) swapinfo.procs * (1.0 - smoothing));
#endif

#ifdef WIN32
     runqueue = (smoothing * runqueue + (float) cProcesses * (1.0 - smoothing));
#endif
  /*
   * Check whether any job has been imported or terminated since the
   * last calculation of the load-index. 
   */
  
  /*changed 7.9.99 broadcast = FALSE;*/
  broadcast = TRUE;

  if( (*long_jobs) > 0 ) {
	  runqueue -= (*long_jobs);
  }
  if (*terminated > 0){
    runqueue -= (*terminated);
    *terminated = 0;
    broadcast = TRUE;
  }
  if (*temp_imported > 0) {
    runqueue += 0.6 * (*temp_imported);
    *temp_imported = 0;
    broadcast = TRUE;
  }
  
 #ifndef USE_AVENRUN
  if(runqueue < 0.0)
    runqueue = 0.0;
  
  /*
   * Calculate load index
   */
  
  info.data_load = 1.0 + runqueue;
  
  if (cpuusage[SYSTEM] > 50.0)    
    info.data_load += system_factor1;
  
  if (cpuusage[SYSTEM] > 100.0)    
    info.data_load += system_factor2 * ((int)((cpuusage[SYSTEM] - 50)/50));
#endif

	if(info.data_load < 0.0)
		info.data_load = 0.0;
    
  info.data_load += 1;
  info.data_load *= arch_factor;
  
  /*
   * Put local load into shared memory segment
   */
  
  *local_load = info.data_load;

  
  /*
   * If any job has finished or being started since last calculation
   * of the load-index, we force a load-broadcast 
   */
  
  /*
   * Otherwise, determine whether broadcast is needed on request of
   * any load-manager
   */
  
  if (((old_load / info.data_load < (1.0 - (float)LOAD_CHANGE/100.0)) ||
       (old_load / info.data_load > (1.0 + (float)LOAD_CHANGE/100.0))) ||
      (old_avail != FALSE && info.data_avail == FALSE))
    broadcast = TRUE;
  
  if (((old_load < idle_host && info.data_load > idle_host) || 
       (old_load > idle_host && info.data_load < idle_host)) ||
      (old_avail == FALSE && info.data_avail != FALSE))
    broadcast = TRUE;
  
  /*
   * send at least one loadinfo packet within the invalidateion interval:
   */
#ifdef WIN32
		time(&ltime);
		tv=gmtime(&ltime);
		if (tv!= NULL &&
      tv->tm_sec - (*last_update)->tm_sec >= (MAX_MISSING_UPDATES - 2) * UPDATE)
#endif
	  
#ifdef UNIX
  if (gettimeofday (&tv, (struct timezone *) 0) >= 0 &&
      tv.tv_sec - last_update->tv_sec >= (MAX_MISSING_UPDATES - 2) * UPDATE)
#endif

      broadcast = TRUE;
  
  if (broadcast)
    broadcast_load();

  /*
   * Set new timer if not first call
   */
  
  if (first){
    first = FALSE;
    return;
  }
	#ifdef WIN32
	   SetTimer(NULL,0,UPDATE,GenerateConsoleCtrlEvent(SIGTERM,_getpid()));
	#endif
	  
	#ifdef UNIX
		alarm(UPDATE);
	#endif
}



#ifdef WIN32
VOID ServiceStart (DWORD argc, LPTSTR *argv) 
#endif
#ifdef UNIX
int main(int argc,char *argv[])
#endif
{
  int ret = 0;                      /* Return value of function calls */
  struct hostent *local_address;    /* Internet-Address of local host  */
  int ldaemon;                      /* Port of load-daemon */
  int lmanager;                     /* Port of load-manager */
  struct servent *get_ports;        /* Structure to get port of load-daemon and load-manager */
  struct sockaddr_in local;         /* Address of local socket */
  struct sockaddr_in from;          /* Who sent the authentication request? */
  unsigned int fromlen = 
    sizeof (struct sockaddr);      /* Length of address */
  rpc_message request;              /* Buffer for incoming messages */ 
  auth_request a_request;           /* Authentication-request of remote rexec manager */
  auth_reply a_reply;               /* Reply to above request */
  int length=50;                    /* Length of local hostname  */
  
  int lmanager_id;                  /* Id of loadmanager returned from start_child() */
  int rmanager_id;                  /* Id of rexecmanager returned from start_child() */
  char path[MAX_PATH_LEN];
#ifdef WIN32
  time_t ltime;
   int on = TRUE;                   /* Flag used to set in_socket into SO_REUSEADDR-mode */
   WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
#endif


  /*
   * Install the function stop_children() with on_exit() so that it will be
   * called when the loaddaemon exits
   */

#ifdef UNIX
   on_exit(stop_children, 0);
#endif
  
  /*
   * Initialize system
   */
#ifdef WIN32
  fprintf(stderr,"Load-Daemon: starting up.\n");
	
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    	return;
	}
#endif
#ifdef UNIX
  OPENLOG(myname);
  syslog (LOG_WARNING, "Load-Daemon: starting up.");
#endif
  /*
   * Get host name and Internet-Address
   */
 

  if (gethostname(host_name,length) != 0)
    exit(1);
  #ifdef WIN32
	printf("Error in getting host=%d\n", WSAGetLastError());
#endif
  fprintf(stderr,"host_name=%s\n",host_name);  /*added on 3.9.99*/
  if (!(local_address = gethostbyname(host_name)))
    exit(1);

	/*
	* Read host specific data from config-file
	*/
  
  readhostdatabase();
  
  /*
   * Read kernel memory offsets for the kernel symbols to be read
   */ 
#ifdef LINUX
 kfd=open("/dev/kmem",O_RDONLY); 
if (kfd<0) { perror("open"); exit(1);}
#endif


#ifdef SUNOS
#ifndef USE_AVENRUN  
  symbole[0].n_name = "_total"; 
  symbole[1].n_name = "_anoninfo";
  symbole[2].n_name = "_cp_time";
  symbole[3].n_name = (char *)0;
#else  
  symbole[0].n_name = "_avenrun";
  symbole[1].n_name = (char *)0;
#endif /* !USE_AVENRUN */
  
  /*
   * Open kmem for reading 
   */

  mptr = kvm_open((char *)0 , (char *)0  , (char *)0 ,O_RDONLY, (char *)0 );
  
  if (!mptr) {
    syslog(LOG_ERR, "Load-Daemon: Could not open /dev/kmem  : %m");
  exit(1);
  }

  /*
   * Read memory offsets 
   */
  
  if(kvm_nlist (mptr, symbole) == -1){
    syslog(LOG_ERR, "Load-Daemon: Illegal Symbol in nlist-structure: %m");
    exit(1);
  }
#endif
  /*
   * Create shared memory for timestamps
   */
#ifdef WIN32
  if (CreateDirectory(YALB_PATH,NULL)==TRUE && GetLastError()!=ERROR_ALREADY_EXISTS){
	   fprintf(stderr,"Load-Daemon:Failure in Creating directory : %d \n", GetLastError());
		exit(-1);
  }
  	if (!SetCurrentDirectory(YALB_PATH) )
			exit(-1);
#endif

#ifdef UNIX  
  if (mkdir(YALB_PATH,0755) < 0 && errno != EEXIST) {
    syslog(LOG_ERR, "Load-Daemon: YALB-directory not creatable! : %m");
    exit(-1);
	}
  if (chdir(YALB_PATH) < 0) {
    syslog(LOG_ERR, "Load-Daemon: YALB-directory not accessable! : %m");
    exit(-1);
  }
#endif
  	
#ifdef WIN32
	hIn=CreateFile ("\\tmp\\yalb\\yalb.shared", GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	printf ("Error in creating File yalb.shared  %d\n", GetLastError());
	hInMap=CreateFileMapping(hIn,NULL,PAGE_READWRITE,0,sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float),NULL);
	printf ("Error in creating file mapping for yalb.shared  %d\n", GetLastError());

	addr_time=MapViewOfFile(hInMap,FILE_MAP_ALL_ACCESS,0,0,0);
	printf ("Error in  mapping file for yalb.shared  %d\n", GetLastError());
	*last_update = (struct tm *) addr_time;
#endif

#ifdef UNIX
	#ifdef ROOT_OWNER
		shared_mem = open(SHARED,O_RDWR | O_CREAT, 0600);
	#else
		shared_mem = open(SHARED,O_RDWR | O_CREAT, 0666);
	#endif
	if (shared_mem < 0){
		syslog(LOG_ERR, "Load-Daemon: Shared memory not available : %m");
		exit(1);
	}
 
  ftruncate (shared_mem, 4096);

  addr_time = mmap ((caddr_t)0, (size_t) (sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof (float) + sizeof(int)), PROT_WRITE | PROT_READ, MAP_SHARED, shared_mem, (off_t)0 );   
  
  if (addr_time == (caddr_t)-1)
    syslog(LOG_ERR, "Load-Daemon: getting shared segment (%m)");
  last_update = (struct timeval *) addr_time;
#endif


 

  
#ifdef UNIX
	local_load = (float *) (addr_time + sizeof(struct timeval));
	availability = (int *) (addr_time + sizeof(struct timeval) + sizeof(float));
	temp_imported = (int *) (addr_time + sizeof(struct timeval) + sizeof(float) + sizeof(int));
	terminated = (float *) (addr_time + sizeof(struct timeval) + sizeof(float) + 2*sizeof(int));
	long_jobs = (int *) (addr_time + sizeof(struct timeval) + sizeof(float) + 2*sizeof(int) + sizeof(float));
#endif

#ifdef WIN32
	local_load = (float *) (addr_time + sizeof(struct tm *));
	availability = (int *) (addr_time + sizeof(struct tm *) + sizeof(float));
	temp_imported = (int *) (addr_time + sizeof(struct tm *) + sizeof(float) + sizeof(int));
	terminated = (float *) (addr_time + sizeof(struct tm *) + sizeof(float) + 2*sizeof(int));
	long_jobs = (int *) (addr_time + sizeof(struct tm *) + sizeof(float) + 2*sizeof(int) + sizeof(float));
#endif

  /*
   * Get port number for services "ldaemon" and "lmanager"
   */
  
  get_ports = getservbyname(DAEMON_SERVICE, "udp");
  
  ldaemon = get_ports->s_port;
  
  get_ports = getservbyname(LOMA_SERVICE, "udp");
  
  lmanager = get_ports->s_port;
  
  /*
   * Open Internet-Domain-Socket for sending/receiving 
   */
  
  if (argc == 2 && ! strcmp (argv [1], "-i"))
    /* pray for a miracle... */
    sock = 0;
  else
    sock = socket(AF_INET, SOCK_DGRAM, 0);
  
  if (sock < 0) 
  {
#ifdef WIN32
	  fprintf(stderr,"Load-Daemon: opening datagram socket: %d \n", GetLastError());
#else 
		  syslog(LOG_ERR, "Load-Daemon: opening datagram socket (%m)");
#endif
		  exit(1);
  }
  
  /*
   * Bind name to local socket
   */
  
  local.sin_family = AF_INET;
  local.sin_port = ldaemon;
  local.sin_addr.s_addr = INADDR_ANY;
  #ifdef WIN32
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof (on));
#endif
	
  
  if( bind(sock, (struct sockaddr FAR *)&local, sizeof local) < 0)
  {
#ifdef WIN32
	  fprintf(stderr,"Load-Daemon: binding local socket: %d \n", GetLastError());
#else
	  syslog(LOG_ERR, "Load-Daemon: binding local socket (%m)");
#endif
	  exit(1);
  }  
  
  /*
   * Get broadcast address 
   */
  
#ifdef WIN32
  memcpy((char *)&remote.sin_addr,(char *)local_address->h_addr_list[0],  local_address->h_length);
#else
  bcopy((char *)local_address->h_addr_list[0], (char *)&remote.sin_addr, local_address->h_length);
#endif 
  /* Local hack !! */
  /*changed 7.9.99 remote.sin_addr.s_addr = (remote.sin_addr.s_addr & BROADCAST_MASK) | ~BROADCAST_MASK;*/
  
  remote.sin_family = AF_INET;
  remote.sin_port = lmanager;
  
  /*
   * Init load index
   */
  
#ifdef WIN32
  calculate(NULL,0,0,0); /*arguments are irrelevant here*/
#else
  calculate();
#endif
  /*
   * Init message header for load broadcast
   */
  
  info.kind = LOAD_BROADCAST;
  info.magic_number = MAGIC;
  
  /*
   * Init message header for authentication message
   */
  
  a_reply.kind = AUTH_REPLY;
  a_reply.magic_number = MAGIC;
  
  /*
   * Install signal driver for SIGALARM
   */
#ifdef WIN32
	 SetTimer(NULL,0,UPDATE,calculate);
#else
  signal(SIGALRM,calculate);
  alarm(UPDATE);
#endif
  /*
   * Schedule first SIGALRM
   */
  
    
  /*
   * Force first load broadcast 
   */
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#else
  gettimeofday(&incoming, (struct timezone *)0);
#endif
  broadcast_load();
  

  /*
   * Initialize the child process handling functions
   */

  init_children(close_all);

  /* 
   * Start the daemons
   */

#ifdef WIN32
  sprintf(path, "%s\\%s.exe", YALB_DAEMON, LMANAGER);
  lmanager_id = start_child("\\usr\\local\\etc\\lmanager" /*\usr\local\etc\lmanager.exe"*/);
 rmanager_id = start_child("\\usr\\local\\etc\\remote");
#endif
  
#ifdef UNIX
  sprintf(path, "%s/%s", YALB_DAEMON, LMANAGER);
  lmanager_id = start_child(path);
  sprintf(path, "%s/%s", YALB_DAEMON, RMANAGER);
  rmanager_id = start_child(path);
#endif
  
  


  /*
   * ... and now: Listen for incoming requests on socket 
   * and reply if necessary (main loop)
   */
  
  for(;;){
    
    /*
     * Listen to socket
     */
    
    if(recvfrom(sock, &request, sizeof request,0, &from, &fromlen) < 0){

      if(errno != EINTR) {
#ifdef WIN32 
		fprintf(stderr,"Load-Daemon: listening to socket: %d \n", GetLastError());
#else
	syslog(LOG_ERR, "Load-Daemon: listening to socket (%m)");
#endif
	  }
      else
	continue;
    }
   fprintf(stderr,"Passed revfrom in loaddaemon\n"); 
    /*
     * Check incoming packet for magic number (poor authentication !)
     */
    
    if ((request.kind == LOAD_POLL) && (request.magic_number == MAGIC)){
        fprintf(stderr,"Load-daemon: serving request LOAD_POLL\n");/*added 29.8.99*/
      
      /*
       * Magic number and message type ok, so get new timestamp
       */
      
      if (loadpolling){
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#else
	gettimeofday(&incoming, (struct timezone *)0);
#endif 
	/*
	 * If last request is older than UPDATE seconds and send is true
	 * broadcast new load-index and set new timestamp
	 */
#ifdef WIN32
	if (((incoming->tm_sec - (*last_update)->tm_sec) >= UPDATE) && transmit)
#else  
	if (((incoming.tv_sec - last_update->tv_sec) >= UPDATE) && transmit)
#endif
		broadcast_load();
      }
      continue;
    }
    
    if ((request.kind == LOAD_REQUEST) && (request.magic_number == MAGIC)){
        fprintf(stderr,"Load-daemon: serving request LOAD_REQUEST\n");/*added 29.8.99*/
      
      /*
       * Magic number and message type ok, so get new timestamp
       */
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#else
      gettimeofday(&incoming, (struct timezone *)0);
#endif
      /*
       * If last request is older than UPDATE seconds and send is true
       * broadcast new load-index and set new timestamp
       */
      
      send_load(&from);
      
      continue;
    }
    
    if ((request.kind == BROADCAST_FORCE) && (request.magic_number == MAGIC)){
        fprintf(stderr,"Load-daemon: serving request BROADCAST_FORCE\n");/*added 29.8.99*/
      
      /*
       * Magic number and message type ok, so get new timestamp
       */
#ifdef WIN32
		time(&ltime);
		incoming=gmtime(&ltime);
#else    
      gettimeofday(&incoming, (struct timezone *)0);
#endif
      /*
       * Broadcast new load-index and set new timestamp
       */
      
      broadcast_load();
      
      continue;
    }
    
    /*
     * Hey! We received an authentication request from a remote rexec
     * manager! We do our best to prevent him from fraud...
     */

    if( (request.kind == CONFIG_READ_SYS) && (request.magic_number == MAGIC) ) {
	    
        fprintf(stderr,"Load-daemon: serving request CONFIG_READ_SYS\n");/*added 29.8.99*/
	    readhostdatabase();

	    /*
	     * Send signal to children
	     */
	fprintf(stderr,"Killing loadmanger inside CONFIG_READ_SYS\n");/*added on 2.9.99*/
	    kill_child(lmanager_id, SIG_CONFIG_READ);
	    kill_child(rmanager_id, SIG_CONFIG_READ);
	
	    continue;
    }

    if( (request.kind == CONFIG_READ_HOST) && (request.magic_number == MAGIC) ) {
    
        fprintf(stderr,"Load-daemon: serving request CONFIG_READ_HOST\n");/*added 29.8.99*/
	    readhostdatabase();

	    /*
	     * Reply to the read request so that the caller doesn't try to start us
	     */
	    reply_to_config_read(sock, (struct sockaddr *)&from);

        fprintf(stderr,"Load-daemon: finished serving request CONFIG_READ_HOST\n");/*added 29.8.99*/
	    continue;
    }

    if( (request.kind == KILL_REQUEST) && (request.magic_number == MAGIC) ) {
	fprintf(stderr,"Loaddaemon exiting\n");/*added on 2.9.99*/
	    exit(0);
    }
    
    else {
      
      int mask;
      
      if ((request.kind == AUTH_REQUEST) && (request.magic_number == MAGIC)){
#ifdef UNIX 
	/*changed on 15.11	a_request = (auth_request *) &request;*/
	mask=sigblock(SIGALRM);
#endif
 /*a_reply.ok = authenticate(&request);*/
a_reply.ok = TRUE;	/*forcefully set for debugging*/
#ifdef UNIX
		sigsetmask(mask);
#endif
     /* fprintf(stderr,"reply.ok at loaddaemon after authentication =%d\n",a_reply.ok);*/
		if(sendto(sock, (char *) &a_reply, sizeof (auth_reply), 0, &from, fromlen) < 0 ) {
#ifdef WIN32 
		  fprintf(stderr,"Load-Daemon: sending authentication reply : %d \n", GetLastError());
#else
		syslog(LOG_ERR, "Load-Daemon: sending authentication reply (%m)");
#endif
	}
      }
      
      /*
       * If not 'authenticated', discard message and loop again
       */
      
    }
    
  }
  
  /* Never reached */
  
  exit(0);
  
}
#ifdef WIN32
HANDLE  hServerStopEvent = NULL; 

VOID ServiceStop() 
{ 
    if ( hServerStopEvent ) 
        SetEvent(hServerStopEvent); 
} 
#endif
