/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: match.c,v 1.2 1994/02/28 19:06:18 carlsson Exp $
 * $Log: match.c,v $
 * Revision 1.2  1994/02/28  19:06:18  carlsson
 * Use check_path (not nase_check_path).
 *
 * Revision 1.1  1994/02/12  14:45:29  carlsson
 * Added call to `stat()' in `patt_match()' to check for modificatiion of
 * the file yalb.match.
 *
 * Revision 1.0  1993/12/21  10:44:57  carlsson
 * Initial revision
 */

#include "system.h"
#ifdef LINUX
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
#endif
#ifdef WIN32
#define YALB_DATA "\\usr\\local\\lib\\yalb"
#include <string.h>
#include <sys/stat.h>
#endif

extern int fprintf(FILE *, const char *, ...);
extern int fgetc(FILE *);
extern int ungetc();
/*extern char *malloc(unsigned);*/
extern int fclose(FILE *);
#ifdef WIN32
extern int strncmp(char *, char *, int);
#endif

#define YALB_MATCH "yalb.match"
#define MAX_PATH_LEN 1024

#define ERR_UNDEF -8
#define ERR_COLON_EXP -7
#define ERR_MAX_COUNT -6
#define ERR_MAX_PATTERN -5
#define ERR_SLASH_EXP -4
#define ERR_VAR_OR_NAME_EXP -3
#define ERR_ALNUM_EXP -2
#define ERR_INIT -1
#define OK 0


#define NAME 0
#define VAR 1
#define DONE 2
#define SLASH 3
#define COLON 4
#define NEWLINE 5
#define TRUE 1
#define FALSE 0
#define MAX_PATTERN 10
#define MAX_COUNT 10
#define MAX_VAR_LEN 256
typedef struct {
	int type;
	char *sp;
} path_info;

typedef path_info *path_info_ptr;
static path_info left_tab[MAX_PATTERN][MAX_COUNT];
static path_info_ptr left_tab2[MAX_PATTERN][MAX_COUNT];
typedef char *char_ptr;
static char_ptr right_tab[MAX_PATTERN][MAX_COUNT];

static FILE *match_fp = NULL;
static int line = 0;
static int tok;
static int pattern = 0, count = 0, pos = 0, var_nr = 0;
static int buf_pos;
static char buf[1024];

static void get_path(char *path)
{
#ifdef WIN32
	sprintf(path, "%s\\%s", YALB_DATA, YALB_MATCH);
#endif
#ifdef UNIX
	sprintf(path, "%s/%s", YALB_DATA, YALB_MATCH);
#endif
}

static int get_def(char *name, path_info tab[])
{
	int i;

	for( i = 0; i < pos; i++ ) {
		if( strcmp(name, tab[i].sp) == 0 ) {
			return( i );
		}
	}

	return( -1 );
}

static void err( int err_code )
{
#ifdef WIN32
	fprintf(stderr,"Error in %s\\%s", YALB_DATA, YALB_MATCH);
#endif
#ifdef UNIX
    syslog(LOG_ERR, "Error in %s/%s", YALB_DATA, YALB_MATCH);
#endif
	_exit(-1);
}

#ifdef WIN32
static int scan(void)
{
	int c;

	while( TRUE ) {

		c = fgetc(match_fp);

		if( c == ' ' || c == '\t' ) {
			;
		}
		else if( c == '\n' ) {
			line++;
			return(NEWLINE);
		}
		else if( c == '\\'){	
			return( SLASH );
		}
		else if( c == ':' ) {
			return( COLON );
		}
		else if( c == '$' ) {
			c = fgetc(match_fp);
			if( !isalnum(c) ) {
				err( ERR_ALNUM_EXP );
			}
			buf_pos = 0;
			buf[buf_pos] = c;
			c = fgetc(match_fp);
			while( isalnum(c) || isdigit(c) || c == '_' ) {
				buf[++buf_pos] = c;
				c = fgetc(match_fp);
			}
			ungetc(c, match_fp);
			buf[++buf_pos] = '\0';
			return( VAR );
		}
		else if( c == EOF ) {
			return( DONE );
		}
		else {
			buf_pos = 0;
			buf[buf_pos] = c;
			c = fgetc(match_fp);
		while( c != '\\' && c != EOF && c != ' ' && c != '\t' && c != '\n' && c != ':' ) {
			buf[++buf_pos] = c;
				c = fgetc(match_fp);
			}
			ungetc(c, match_fp);
			buf[++buf_pos] = '\0';
			return( NAME );
		}
	}
}

#endif
#ifdef UNIX
static int scan(void)
{
	int c;

	while( TRUE ) {

		c = fgetc(match_fp);

		if( c == ' ' || c == '\t' ) {
			;
		}
		else if( c == '\n' ) {
			line++;
			return(NEWLINE);
		}
		else 
			if( c == '/' ) 
			{	return( SLASH );
		}
		else if( c == ':' ) {
			return( COLON );
		}
		else if( c == '$' ) {
			c = fgetc(match_fp);
			if( !isalnum(c) ) {
				err( ERR_ALNUM_EXP );
			}
			buf_pos = 0;
			buf[buf_pos] = c;
			c = fgetc(match_fp);
			while( isalnum(c) || isdigit(c) || c == '_' ) {
				buf[++buf_pos] = c;
				c = fgetc(match_fp);
			}
			ungetc(c, match_fp);
			buf[++buf_pos] = '\0';
			return( VAR );
		}
		else if( c == EOF ) {
			return( DONE );
		}
		else {
			buf_pos = 0;
			buf[buf_pos] = c;
			c = fgetc(match_fp);
			while( c != '/' && c != EOF && c != ' ' && c != '\t' && c != '\n' && c != ':' ) {
				buf[++buf_pos] = c;
				c = fgetc(match_fp);
			}
			ungetc(c, match_fp);
			buf[++buf_pos] = '\0';
			return( NAME );
		}
	}
}

#endif

static void left_path(void)
{
	int def_pos = 0;

	do {
		if( tok != SLASH ) {
			err( ERR_SLASH_EXP );
		}
		
		tok = scan();
		
		switch( tok ) {
		      case NAME:
			left_tab[pattern][pos].type = 0;
			left_tab[pattern][pos].sp = (char *)malloc(strlen(buf) + 1);
			strcpy(left_tab[pattern][pos].sp, buf);
			left_tab2[pattern][count] = &(left_tab[pattern][pos]);
			pos++;
			break;
		      case VAR:
			if( (def_pos = get_def(buf, left_tab[pattern])) >= 0 ){
				left_tab2[pattern][count] = &left_tab[pattern][def_pos];
			}
			else {
				left_tab[pattern][pos].type = var_nr;
				left_tab[pattern][pos].sp = (char *)malloc(MAX_VAR_LEN);
				strcpy(left_tab[pattern][pos].sp, buf);
				left_tab2[pattern][count] = &left_tab[pattern][pos];
				pos++;
				var_nr++;
			}
			break;
		      default:
			err( ERR_VAR_OR_NAME_EXP );
		}
		
		count++;
		if( count >= MAX_COUNT ) {
			err( ERR_MAX_COUNT );
		}

		tok = scan();
	} while( tok == SLASH );
}


static void right_path()
{
	int def_pos = 0;

	do {
		if( tok != SLASH ) {
			err( ERR_SLASH_EXP );
		}
		
		tok = scan();
		
		switch( tok ) {
		      case NAME:
			right_tab[pattern][count] = (char *)malloc(strlen(buf) + 1);
			strcpy(right_tab[pattern][count], buf);
			break;
		      case VAR:
			if( (def_pos = get_def(buf, left_tab[pattern])) >= 0 ){
				right_tab[pattern][count] = left_tab[pattern][def_pos].sp;
			}
			else {
				err( ERR_UNDEF );
			}
			break;
		      default:
			err( ERR_VAR_OR_NAME_EXP );
		}
		
		count++;
		if( count >= MAX_COUNT ) {
			err( ERR_MAX_COUNT );
		}

		tok = scan();
	} while( tok == SLASH );
}
					    



static void parse()
{
	tok = scan();

	pattern = 0;

	while( tok != DONE ) {
		count = 0;
		pos = 0;
		var_nr = 1;
		left_path();

		if( tok != COLON ) {
			err( ERR_COLON_EXP );
		}
		tok = scan();

		count = 0;
		right_path();

		while( tok == NEWLINE ) {
			tok = scan();
		}
		pattern++;
		if( pattern >= MAX_PATTERN ) {
			err( ERR_MAX_PATTERN );
		}
		  
	}
}

static int init(void)
{
	char path[MAX_PATH_LEN];
	int i, j;

	get_path(path);
	
	for( i = 0; i < MAX_PATTERN; i++ ) {
		for( j = 0; j < MAX_COUNT; j++ ) {
			left_tab2[i][j] = NULL;
		}
	}

	for( i = 0; i < MAX_PATTERN; i++ ) {
		for( j = 0; j < MAX_COUNT; j++ ) {
			right_tab[i][j] = NULL;
		}
	}

	if( (match_fp = fopen(path, "r")) == NULL ) {
		return( ERR_INIT );
	}

	parse();
/*	
	for( i = 0; i < pattern; i++ ) {
		printf("\nPattern number %d\n", i);
		for( j = 0; left_tab2[i][j]; j++ ) {
			printf("   Pos number %d, type %d, len %d, value %s\n", j, left_tab2[i][j]->type, left_tab2[i][j]->len, left_tab2[i][j]->sp);
		}
	}
	for( i = 0; i < pattern; i++ ) {
		printf("\nPattern number %d\n", i);
		for( j = 0; right_tab[i][j]; j++ ) {
			printf("   Pos number %d, value %s\n", j, right_tab[i][j]);
		}
	}
*/
	fclose(match_fp);
	return( OK );
}
			


/*changed 10.8.99 inline int patt_match(char *currdir, char *newdir)*/
int patt_match(char *currdir, char *newdir)
{
	static int first_run = TRUE;
	register char *sp;
	register int i;
	register int j;
	register char *cdir;
	register char *ndir;

	static char path[MAX_PATH_LEN];

	static int found;

	static time_t mtime = 0;
	
	if( first_run ) {
		get_path(path);
		first_run = FALSE;
	}

	{
		static struct stat buf;
		
		(void)stat(path, &buf);
		if( mtime != buf.st_mtime ) {
			init();
		}
	}
		  
	for( i = 0; i < pattern; i++ ) {
		cdir = currdir;
		ndir = newdir;
		found = TRUE;
		j = 0;
		while( left_tab2[i][j] ) {
			if( left_tab2[i][j]->type > 0 ) {
				*(left_tab2[i][j]->sp) = '\0';
			}
			j++;
		}
		j = 0;
		while( left_tab2[i][j] && found ) {
			sp = left_tab2[i][j]->sp;
			if( left_tab2[i][j]->type > 0 ) {
				if( *sp == '\0' ) {
					cdir++;
			#ifdef WIN32
					while( *cdir && *cdir != '\\' ) {
			#endif
			#ifdef UNIX
					while( *cdir && *cdir != '/' ) {
			#endif
						*sp++ = *cdir++;
					}
					*sp = '\0';
				}
				else {
					cdir++;
			#ifdef WIN32
					while( *cdir && *cdir != '\\' && found ) {
			#endif
			#ifdef UNIX
					while( *cdir && *cdir != '/' && found ) {
			#endif
						if( *sp++ != *cdir++ ) {
							found = FALSE;
						}
					}	
				}
			}
			else {
				cdir++;
			#ifdef WIN32
			while( *cdir && *cdir != '\\' && found ) {
			#endif
			#ifdef UNIX
			while( *cdir && *cdir != '/' && found ) {
			#endif
					if( *sp++ != *cdir++ ) {
						found = FALSE;
					}
				}	
			}
			j++;
		}
		if( found ) {
			j = 0;
			while( (sp = right_tab[i][j]) ) {
			#ifdef WIN32
			*ndir++ = '\\';
			#endif
			#ifdef UNIX
			*ndir++ = '/';
			#endif
				
				while( *sp ) {
					*ndir++ = *sp++;
				}
				j++;
			}
			while( *cdir ) {
				*ndir++ = *cdir++;
			}
			*ndir = '\0';
			return 1;
		}
	}
	return(0);
}



int
nase_check_path (cwd, newcwd)
char *cwd;
char *newcwd;
{
	/*
	 * change something like   /a/<host>/root  to  /usr/net/<host> 
	 * and  /a/<host>  to  /usr/net/<host>
	 */
	#ifdef WIN32
	if (! strncmp (cwd, "\\a\\", 3))
	#endif
	#ifdef UNIX
	if (! strncmp (cwd, "/a/", 3))
	#endif
			
	{
		char *host = cwd + 3;
		char *p = host;
		
	#ifdef WIN32
	for (; *p && *p != '\\'; p++) 
	#endif
	#ifdef UNIX
	for (; *p && *p != '/'; p++) 
	#endif
			continue;
	#ifdef WIN32
	if (*p == '\\' && ! strncmp (p, "\\root\\", 6))
	#endif
	#ifdef UNIX
	if (*p == '/' && ! strncmp (p, "/root/", 6))
	#endif
		{
			*p = '\0';
	#ifdef WIN32
	(void) sprintf (newcwd, "\\usr\\net\\%s\\%s", host, p+6);
			*p = '\\';
	#endif
	#ifdef UNIX
	(void) sprintf (newcwd, "/usr/net/%s/%s", host, p+6);
			*p = '/';
	#endif
		}
		else
	#ifdef WIN32
		(void) sprintf (newcwd, "\\usr\\net\\%s", host);
	#endif
	#ifdef UNIX
		(void) sprintf (newcwd, "/usr/net/%s", host);
	#endif
		
		return 1;
	}

	/*  
	 * change something like  /<path>/users to /usr/users
	 */		
	#ifdef WIN32
	if (*cwd == '\\')
	#endif
	#ifdef UNIX
	if (*cwd == '/')
	#endif
	{
		char *p = cwd + 1;
	#ifdef WIN32
	for ( ; *p && *p != '\\'; p++)
	#endif
	#ifdef UNIX
	for ( ; *p && *p != '/'; p++)
	#endif
	
			continue;
	#ifdef WIN32
	if (*p == '\\' && ! strncmp (p, "\\users", 6))
		#endif
	#ifdef UNIX
	if (*p == '/' && ! strncmp (p, "/users", 6))
		#endif
		{
		#ifdef WIN32
		(void) sprintf (newcwd, "\\usr%s", p);
			#endif
	#ifdef UNIX
		(void) sprintf (newcwd, "/usr%s", p);
			#endif
			return 1;
		}
	}

	return 0;
}



int check_path(char *cwd, char *newcwd)
{
	int ret1;
	static char newcwd1[1024];
/*
        int ret2;
	static char newcwd2[1024];
*/
	ret1 = patt_match(cwd, newcwd1);
	strcpy(newcwd, newcwd1);
	return( ret1 );

/*
	ret2 = nase_check_path(cwd, newcwd2);
	if( strcmp(newcwd1, newcwd2) == 0 ) {
		if( ret1 ) {
			strcpy(newcwd, newcwd1);
		}
	}
	else {
		fprintf(stderr, "\n\ncheck_path: %s, nase_check_path: %s\n\n", newcwd1, newcwd2);
		if( ret2 ) {
			strcpy(newcwd, newcwd2);
		}
		return( ret2 );
	}
*/
}

/*
void main(int argc, char *argv[])
{
	char newpath[256];
	
	struct timeval before, after;

	gettimeofday(&before, (struct timezone *)0);
	patt_match(argv[1], newpath);
	gettimeofday(&after, (struct timezone *)0);
	printf("new path = %s, time = %d \n", newpath, (after.tv_sec - before.tv_sec) * 1000000 + (after.tv_usec - before.tv_usec));

	gettimeofday(&before, (struct timezone *)0);
	patt_match(argv[1], newpath);
	gettimeofday(&after, (struct timezone *)0);
	printf("new path = %s, time = %d \n", newpath, (after.tv_sec - before.tv_sec) * 1000000 + (after.tv_usec - before.tv_usec));
	
	gettimeofday(&before, (struct timezone *)0);
	nase_check_path(argv[1], newpath);
	gettimeofday(&after, (struct timezone *)0);
	printf("new path = %s, time = %d \n", newpath, (after.tv_sec - before.tv_sec) * 1000000 + (after.tv_usec - before.tv_usec));

}


*/
