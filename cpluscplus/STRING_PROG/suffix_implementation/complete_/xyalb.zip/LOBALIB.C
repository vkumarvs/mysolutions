/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: lobalib.c,v 1.3 1994/02/04 13:15:55 carlsson Exp $
 * $Log: lobalib.c,v $
 * Revision 1.3  1994/02/04  13:15:55  carlsson
 * Changed:
 *      } while (!success && (count <= ATTEMPTS));
 * to:
 *      } while (!success && (timeout_info.count <= ATTEMPTS));
 * in function get_hosts.
 *
 * Revision 1.2  1993/12/16  09:48:47  carlsson
 * Use value in configuration database for timeout in calls to loadmanager
 * instead of constant TIMEOUT.
 * Added call to stats_write() when timeout in call to loadmanager occurs.
 *
 * Revision 1.1  1993/12/15  08:15:52  carlsson
 * Added a new kind of message to be sent from get_hosts(). 
 * The message is GET_FASTEST.
 *
 * Revision 1.0  1993/12/02  15:10:01  stille
 * Initial revision
 */

/*
 * Library-functions for use with load-balancing system
 */
#include "lobalib.h"
#include "yalb_stats_db.h"
#include "yalb_config_db.h"
#ifdef LINUX
#include <linux/socket.h>
#include <stdio.h>
#endif
#define MAXSYMBOL 10
#define MAXWIDTH 30
#define TRUE 1
#define FALSE 0


/* Socket for communication with load-manager: */
static int manager; 		

/* Address of (local) load-manager: */
#ifdef WIN32
struct sockaddr_in name_of_manager;
#endif
#ifdef UNIX
static struct sockaddr_un name_of_manager;
#endif


/* Address of our socket: */
#ifdef WIN32
	struct sockaddr_in our_name;
#endif
#ifdef UNIX
 static struct sockaddr_un  our_name;
#endif


/* Flag to indicate successful initialisation of system: */
static int successful_init = FALSE;

/* Timeout in milliseconds read from configuration database */
static long int global_timeout;


/*
 * Procedure to init Loadbalancing requests (open sockets etc)
 */

int 
request_init ( /* no params */ )
{
  
	static struct servent *get_ports = NULL;
	struct hostent *local_host_ent;/*added on 3.12*/
char host_name[MAXNAMELENGTH];  /*added on 3.12*/
 int length=50; /*added on 3.12*/
	rpc_message lookup;		/* Message sent to load-manager to see
				 * if it is up */
  fd_set readfds;		/* Read-file-descriptor-set for reading
				 * manager-socket */
  int count;			/* Count number of attempts to get reply
				 * from load-manager */
  struct timeval timeout;	/* Timeout for load-manager-connection */
  int success;			/* Flag for sucessful calling of
				 * load-manager */
		
int code;/* Pid of our process, used for socket-name... */
  system_config local_system_config;	
  /* Structure for storing system configuration information */

  successful_init = FALSE;

  /*
   * Read timeout value from cinfiguration database
   */

  if (open_config ((int *) NULL) != OK_CFDB)
    {
      global_timeout = DEFAULT_TIMEOUT;
      stats_off ();
    }
  else if (read_system_config (&local_system_config) != OK_CFDB)
    {
      global_timeout = DEFAULT_TIMEOUT;
      stats_off ();
      close_config ();
    }
  else
    {
      if (local_system_config.statistics == TRUE)
	  stats_on ();
      else
	  stats_off ();

      if (! is_missval (TYPE_TIMEOUT, (void *) &local_system_config.timeout))
	  global_timeout = local_system_config.timeout;
      else
	  global_timeout = DEFAULT_TIMEOUT;

      close_config ();
    }

  /*
   * Open request-socket
   */

#ifdef WIN32
  if (gethostname(host_name,length) != 0)
    exit(1);

  manager = socket (AF_INET, SOCK_DGRAM, 0);
  if (manager <0) fprintf(stderr,"Error =%d\n",WSAGetLastError());
#endif

#ifdef UNIX
 manager = socket (AF_UNIX, SOCK_DGRAM, 0);
#endif

  /*
   * If socket could not be opened, return 'FATAL' error-code
   */

  if (manager < 0)
    {
      perror ("error getting dgram socket; reason");
      return FATAL;
    }

  /*
   * Now let's find a nice name for our nice socket
   */

 	#ifdef WIN32
		code = _getpid ();
	#endif
 	#ifdef UNIX
		code = getpid ();
	#endif

#ifdef WIN32
	our_name.sin_port = 1026;
	our_name.sin_addr.s_addr =INADDR_ANY;
#endif
#ifdef UNIX
sprintf (our_name.sun_path, "/tmp/%d", code);
#endif


#ifdef WIN32
 	  our_name.sin_family = AF_INET;
#endif
#ifdef UNIX
	our_name.sun_family = AF_UNIX;
#endif

  
     
#ifdef WIN32
	if (bind (manager, (struct sockaddr *) &our_name,
	    sizeof (struct sockaddr) ) < 0)
#endif
#ifdef UNIX
if (bind (manager, (struct sockaddr *) &our_name,
	    strlen (our_name.sun_path) + 3) < 0)
#endif

  {
      perror ("error binding name to UNIX-socket; reason");
#ifdef WIN32
	  fprintf(stderr,"Error %d\n",WSAGetLastError());
#endif
      return FATAL;
    }


  /*
   * Socket is OK, now try to send a call to the loadmanager to see if
   * he is up
   */

  lookup.kind = PING;
  lookup.magic_number = MAGIC;

#ifdef UNIX
  name_of_manager.sun_family = AF_UNIX;
  strcpy (name_of_manager.sun_path, YALB_PATH);
  strcat (name_of_manager.sun_path, "/");
  strcat (name_of_manager.sun_path, UNIX_SOCKET);
#endif


#ifdef WIN32
  get_ports = getservbyname("application", "udp");
  name_of_manager.sin_family = AF_INET;
 name_of_manager.sin_port = get_ports->s_port;
 local_host_ent = gethostbyname(host_name);
 memcpy((char *)&name_of_manager.sin_addr, local_host_ent->h_addr_list[0], local_host_ent->h_length);
 memcpy((char *)&lookup.data.addr,local_host_ent->h_addr_list[0],  local_host_ent->h_length);
#endif
/*fprintf(stderr,"LOBALIB: before sendto in init_request\n"); /*added on 2.9.99*/
 if (sendto (manager, &lookup, sizeof (rpc_message), 0, (struct sockaddr *) &name_of_manager, sizeof name_of_manager) < 0){
	/*fprintf(stderr,"LOBALIB: after sendto in init_request\n"); /*added on 2.9.99*/
      return MANAGERNOTPRESENT;
	}

  /*
   * Set timeout-value to global_timeout micro-seconds
   */

  timeout.tv_sec = (int) global_timeout / 1000000;
  timeout.tv_usec = global_timeout - timeout.tv_sec * 1000000;


  /*
   * Try ATTEMPTS time to get a reply of load-manager. 
   */

  count = 0;
  success = FALSE;

  do
    {

fprintf(stderr,"LOBALIB: trying to get reply from loadamanager\n"); /*added on 2.9.99*/
      FD_ZERO (&readfds);
      FD_SET (manager, &readfds);


  timeout.tv_sec = (global_timeout / 1000000) + OFFSET;
  timeout.tv_usec = 0;

      if (select (MAXWIDTH, &readfds, (fd_set *) 0, (fd_set *) 0, NULL /*4.12 &timeout*/) <= 0)
  
      {
	success = FALSE;
fprintf(stderr,"LOBALIB: failure in request_init\n"); /*added on 2.9.99*/
      }
      else
	{

	  /*
	   * Reply is arrived, check correctness (poor authentication, 
	   * revcfrom *could* be used!)
	   */

	  if (FD_ISSET (manager, &readfds))
	    {
	      recv (manager, (char *) &lookup, sizeof (rpc_message), 0);

	      if ((lookup.magic_number == MAGIC) 
		  && (lookup.kind == PING_REPLY))
	      {
/*fprintf(stderr,"LOBALIB: success in request_init\n"); /*added on 2.9.99*/
		success = TRUE;
	      }
	    }
	}

      count++;

    } while (!success && (count <= ATTEMPTS));

  if (! success)
    return MANAGERNOTPRESENT;

  /*
   * Our initialisation was successful
   */
  successful_init = TRUE;

  return 0;
}



/*
 * Procedure to get requested hosts from local load-manager
 */

int 
get_hosts (what, available_hosts)
     request *what;
#if 0
/** XXX (schoenfr): looks completely wrong: **/
     reply available_hosts;
#else
     reply *available_hosts;
#endif
{
int tmp; /*added on 2.9.99*/
  rpc_message message;		/* Message to be sent to load-manager */
  struct timeval timeout;	/* Timeout-interval for requests 
				   (we use UDP :-(! ) */
  int success;			/* Flag to indicate successful 
				   communication with load-manager */
  fd_set readfds;		/* Read ... */
  int count;			/* Count ... */
  rpc_message answer;		/* Reply from load-manager */

  stats_timeout timeout_info;	/* Information of timeouts to be
				   written to statistic database */
  /*
   * Check whether there was a previous (successful) 
   * call to the init-routine
   */

  if (! successful_init)
    return NOINIT;

  /*
   * Socket is open, so prepare message to be sent to load-manager. Set header
   */
/*GET_OPT added on 18.11.99*/
  if (what->kind == GET_OPT)
    {
      message.kind = GET_OPT_HOST;
      message.magic_number = MAGIC;
      message.data_number = what->number;
    }
  else if (what->kind == GET_TOP)
    {
      message.kind = APPLICATION_REQUEST;
      message.magic_number = MAGIC;
      message.data_number = what->number;
    }
  else if (what->kind == GET_FASTEST)
    {
      message.kind = GET_FASTEST_HOST;
      message.magic_number = MAGIC;
      message.data_number = what->number;
    }
  else if (what->kind == GET_ALL)
    {
      message.kind = GET_ALL_HOSTS;
      message.magic_number = MAGIC;
    }
  else
    {
      return ILLEGAL_REQUEST;
    }

  /*
   * Now copy the hostlist given (if any) to message body
   */


  /* XXX (schoenfr): better don't copy the whole array, cuz its optional */
  /* XXX (schoenfr): only copy MAX - 1 elems, due to overflow possib. */

  for (count = 0;
       what->kind != GET_ALL && what->hostlist[count] != NULL
       && count < MAXHOSTS - 1;
       count++)
    message.data_hostlist[count] = *what->hostlist[count];

  message.data_hostlist[count].sin_addr.s_addr = ENDOFHOSTLIST;


  /*
   * Set timeout-value to global_timeout micro-seconds plus OFFSET seconds
   */

  timeout.tv_sec = (global_timeout / 1000000) + OFFSET;
  timeout.tv_usec = 0;

  /*
   * Try ATTEMPTS time to send message to load-manager and get a reply.
   */

  timeout_info.count = 0;
  success = FALSE;

  /*
   * Now send request to local load-manager
   */

  do
    { 
/*fprintf(stderr,"LOBALIB: before sendto in get_hosts\n"); /*added on 2.9.99*/
#ifdef UNIX
	 if (sendto (manager, (const void *)&message, sizeof (rpc_message), 0,
		  (struct sockaddr *) &name_of_manager,
		  sizeof (struct sockaddr_un)) < 0)
#endif
#ifdef WIN32
		  if (sendto (manager, (const void *)&message, sizeof (rpc_message), 0,
		  (struct sockaddr *) &name_of_manager,
		  sizeof (struct sockaddr)) < 0)
#endif
		  {
/*fprintf(stderr,"LOBALIB: after sendto in get_hosts\n"); /*added on 2.9.99*/
	  return MANAGERNOTPRESENT;
	}

      FD_ZERO (&readfds);
      FD_SET (manager, &readfds);


      tmp=select (MAXWIDTH, &readfds, (fd_set *) 0, (fd_set *) 0,NULL/*11.12&timeout*/);
      if (tmp<= 0)
	{
	  success = FALSE;
if (tmp==0) fprintf(stderr,"LOBALIB: failure in get_hosts due to timeout\n"); /*added on 2.9.99*/
else fprintf(stderr,"LOBALIB: failure in get_hosts due to caught signal\n"); /*added on 2.9.99*/
	}
      else
	{
	  /*
	   * Reply has arrived, check correctness 
	   * (poor authentication, revcfrom *could* be used!)
	   */

	  if (FD_ISSET (manager, &readfds))
	    {

	      recv (manager, (char *) &answer, sizeof (rpc_message), 0);

	      if (answer.magic_number == MAGIC)
		{
		  if (answer.kind == APPLICATION_ERROR)
		    return answer.data_error;
		  if (answer.kind == APPLICATION_REPLY)
		    {
		      success = TRUE;
fprintf(stderr,"LOBALIB: success in get_hosts\n"); /*added on 2.9.99*/
		      break;
		    }
		}
	    }
	}

      timeout_info.count++;

    }
  while (!success && (timeout_info.count <= ATTEMPTS));

  if (--timeout_info.count > 0)
      stats_write (STATS_TYPE_TIMEOUT, (stats_info) & timeout_info);

  if (! success)
    return MANAGERNOTPRESENT;

fprintf(stderr,"LOBALIB: not failure but time out in get_hosts\n"); /*added on 2.9.99*/
  /*
   * Calling was successful. No error was returned, so return list of hosts 
   * etc to application
   */

  *available_hosts = *(reply *) & answer.data.message;

  return 0;
}


/*
 * Procedure to reset the load-balancing system
 */

void 
reset_system ()
{
  /*
   * Close socket and reset internal variable
   */

  close (manager);

#ifdef UNIX
	if (unlink (our_name.sun_path) < 0)
  	  perror ("unable to discard socket; reason");
#endif
  successful_init = FALSE;
}
