/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_stats_db.c,v 1.1 1994/03/01 08:53:17 carlsson Exp $
 * $Log: yalb_stats_db.c,v $
 * Revision 1.1  1994/03/01  08:53:17  carlsson
 * VERBOSE-mode introduced.
 *
 * Revision 1.0  1993/12/21  10:56:49  carlsson
 * Initial revision
 */

#include "yalb_stats_db.h"
#ifdef LINUX
#include <sys/time.h>
#include <stdio.h>
#endif

#ifndef YALB_DATA
#ifdef UNIX
#define YALB_DATA "/usr/local/lib/yalb"
#endif
#ifdef WIN32
#define YALB_DATA "\\usr\\local\\lib\\yalb"
#endif
#endif

extern char *strcat(char *, const char *);
extern int fseek(FILE *, long, int);
extern size_t fread(void *, size_t, size_t, FILE *);
extern size_t fwrite(const void *, size_t, size_t, FILE *);
extern int fclose(FILE *);
extern int unlink(char *);
#ifdef UNIX
extern int gettimeofday(struct timeval *, struct timezone *);
extern int gethostname(char *, int);
#endif

static int stats_on_off = STATS_OFF;


static void stats_path(char *path)
{
	strcpy(path, YALB_DATA);
#ifdef UNIX
	strcat(path, "/");
#endif
#ifdef WIN32
	strcat(path, "\\");
#endif
	strcat(path, YALB_STATS);
}

int stats_on(void)
{
	int ret = stats_on_off;
	
	stats_on_off = STATS_ON;

	return( ret );
}

int stats_off(void)
{
	int ret = stats_on_off;
	
	stats_on_off = STATS_OFF;

	return( ret );
}

int stats_is_on(void)
{
	return( stats_on_off == STATS_ON );
}

#ifdef WIN32
int stats_read(int *out_type, struct tm *out_timestamp, char *out_hostname, stats_info *out_stats)
#endif
#ifdef UNIX
int stats_read(int *out_type, struct timeval *out_timestamp, char *out_hostname, stats_info *out_stats)
#endif
{
	static long position = 0;
	static stats_head head;
	/* XXX (schoenfr) open only once: */
	static FILE *stats_fp = 0;
	static char path[MAX_PATH_LEN];
	int size;

	stats_path(path);
	if(! stats_fp && (stats_fp = fopen(path, "r")) == NULL ) {
		return( ERR_STDB_OPEN );
	}
	(void)fseek(stats_fp, position, 0);
	
	if( fread((char *)&head, sizeof(stats_head), 1, stats_fp) == 0 ) {
		fclose(stats_fp);
		position = 0;
		return( ERR_STDB_READ );
	}
	
	*out_type = head.type;
#ifdef WIN32
	out_timestamp = head.timestamp;
#endif
#ifdef UNIX
		*out_timestamp = head.timestamp;
#endif
	strcpy(out_hostname, head.hostname);

	switch( head.type ) {
	      case STATS_TYPE_JOB_BEGIN:
		size = sizeof( stats_job_begin );
		break;
	      case STATS_TYPE_JOB_END:
		size = sizeof( stats_job_end );
		break;
	      case STATS_TYPE_TIMEOUT:
		size = sizeof( stats_timeout );
		break;
	      case STATS_TYPE_AUTH_TIMEOUT:
		size = sizeof( stats_timeout );
		break;
	      case STATS_TYPE_REXEC_TIMEOUT:
		size = sizeof( stats_timeout );
		break;
	      case STATS_TYPE_NOT_AVAIL:
		size = sizeof( stats_not_avail );
		break;
	      case STATS_TYPE_POLL_TIMEOUT:
		size = sizeof( stats_poll_timeout );
		break;
	}
	if( *out_stats ) {
		*out_stats = (stats_info)realloc(*out_stats, size);
	}
	else {
		*out_stats = (stats_info)malloc(size);
	}

	if( fread((char *)(*out_stats), size, 1, stats_fp) == 0 ) {
	    /* XXX (schoenfr): leave open */
	    /** fclose(stats_fp); **/
	    position = 0;
	    return( ERR_STDB_READ );
	}
	
	position = ftell(stats_fp);
	/* XXX (schoenfr): leave open */
	/** fclose(stats_fp); **/

	return( OK_STDB );
}
		
int stats_clear()
{
	static char path[MAX_PATH_LEN];

	stats_path(path);
	if( unlink(path) ) {
		return( ERR_STDB_CLEAR );
	}
	else {
		return( OK_STDB );
	}
}
	
	  

	
int stats_write(int in_type, stats_info in_stats)
{
	static stats_head head;
	static FILE *stats_fp;
	static char path[MAX_PATH_LEN];
	int size;
#ifdef WIN32
	time_t ltime;
	WORD wVersionRequested;WSADATA wsaData;int werr;  //added on 22.9.99
	
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif
	
	if( stats_is_on() ) {
		head.type = in_type;
#ifdef WIN32
		time(&ltime);
		head.timestamp=gmtime(&ltime);
	if (ltime <0 ) 
#endif
#ifdef UNIX
		if( gettimeofday(&head.timestamp, (struct timezone *)0) == -1 )
#endif
		{
			return( ERR_STDB_TIMESTAMP );
		}
		if( gethostname(head.hostname, MAX_NAME_LEN) == -1 ) {
			return( ERR_STDB_HOSTNAME );
		}

		stats_path(path);
		if( (stats_fp = fopen(path, "a")) == NULL ) {
			return( ERR_STDB_OPEN );
		}
		
		if( fwrite((char *)&head, sizeof(stats_head), 1, stats_fp) == 0 ) {
			fclose(stats_fp);
			return( ERR_STDB_WRITE );
		}
		switch( head.type ) {
		      case STATS_TYPE_JOB_BEGIN:
			size = sizeof( stats_job_begin );
			break;
		      case STATS_TYPE_JOB_END:
			size = sizeof( stats_job_end );
			break;
		      case STATS_TYPE_TIMEOUT:
			size = sizeof( stats_timeout );
			break;
		      case STATS_TYPE_AUTH_TIMEOUT:
			size = sizeof( stats_timeout );
			break;
		      case STATS_TYPE_REXEC_TIMEOUT:
			size = sizeof( stats_timeout );
			break;
		      case STATS_TYPE_NOT_AVAIL:
			size = sizeof( stats_not_avail );
			break;
		      case STATS_TYPE_POLL_TIMEOUT:
			size = sizeof( stats_poll_timeout );
			break;
		      default:
			return( ERR_STDB_TYPE );
			break;
		}
#ifdef VERBOSE
		printf("stats_write: type: %d\n", head.type);		
#endif
		if( fwrite((char *)in_stats, size, 1, stats_fp) == 0 ) {
			fclose(stats_fp);
			return( ERR_STDB_WRITE );
		}
		fclose(stats_fp);
	}
	return( OK_STDB );
}
		
			
			
