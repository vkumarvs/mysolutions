/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: get_swap_server.c,v 1.0 1993/12/21 10:44:11 carlsson Exp $
 * $Log: get_swap_server.c,v $
 * Revision 1.0  1993/12/21  10:44:11  carlsson
 * Initial revision
 */

#include <stdio.h>
#include <string.h>
#ifdef WIN32
#include "winsock.h" 
#endif /*added on 20.9.99*/



#ifndef WIN32
extern int pclose(FILE *);
extern struct hostent *gethostbyname(char *);
#endif

char *get_swap_server(char *host)
{
	FILE *pp;
	static char line[256];
	char *swap_srv;
	char *sp;

	if( !host ) {
		return( (char *)NULL );
	}

	sprintf(line, "rsh -n %s cat /var/adm/messages\\*", host); 
#ifdef WIN32
	if( (pp = _popen(line, "r")) == NULL ) {
#else
if( (pp = popen(line, "r")) == NULL ) {
#endif
		return( (char *)NULL );
	}

	while( fgets(line, 256, pp) != NULL ) {
		if( (swap_srv = strstr(line, "swap on ")) != NULL ) {
			swap_srv += strlen("swap on ");
			if( (sp = strchr(swap_srv, ':')) != NULL ) {
				*sp = '\0';
#ifdef WIN32
				_pclose(pp);
#else
				pclose(pp);
#endif
				if( gethostbyname(swap_srv) ) {
					return( swap_srv );
				}
				else {
					return( (char *)NULL );
				}
			}
		}
	}

#ifdef WIN32
	_pclose(pp);
#else
	pclose(pp);
#endif

	return( (char *)NULL );
}

				
