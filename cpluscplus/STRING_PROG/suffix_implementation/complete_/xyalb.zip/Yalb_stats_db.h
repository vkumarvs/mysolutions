/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_stats_db.h,v 1.0 1993/12/21 10:57:33 carlsson Exp $
 * $Log: yalb_stats_db.h,v $
 * Revision 1.0  1993/12/21  10:57:33  carlsson
 * Initial revision
 *
 */

#ifndef _YALB_STATS_DB_H
#define _YALB_STATS_DB_H
#include "system.h"
#ifdef UNIX
#include <sys/resource.h>
#endif
#endif

/*
  The possible statistic types that the system can handle
  Theese are also the only allowed values for the `type'
  field in the structure `stats_head' (se below)
*/

#define STATS_TYPE_UNKNOWN -1
#define STATS_TYPE_JOB_BEGIN 0
#define STATS_TYPE_JOB_END 1
#define STATS_TYPE_TIMEOUT 2
#define STATS_TYPE_AUTH_TIMEOUT 3
#define STATS_TYPE_REXEC_TIMEOUT 4
#define STATS_TYPE_NOT_AVAIL 5
#define STATS_TYPE_POLL_TIMEOUT 6

#define STATS_ON 1
#define STATS_OFF 0

#define MAX_NAME_LEN 128
#define MAX_COMMAND_LEN 128

#define TRUE 1
#define FALSE 0

#define YALB_STATS "yalb.stats"
/*
  This constant must be greater than or equal to the
  size of the largest statist
*/

#define OK_STDB 0
#define ERR_STDB_OPEN -1
#define ERR_STDB_WRITE -2
#define ERR_STDB_TIMESTAMP -3
#define ERR_STDB_TYPE -4
#define ERR_STDB_CLEAR -5
#define ERR_STDB_READ -6
#define ERR_STDB_HOSTNAME -7

#ifdef WIN32
typedef struct {
	int type;
	struct tm *timestamp;
	char hostname[MAX_NAME_LEN];
} stats_head;
#endif	
#ifdef UNIX
typedef struct {
	int type;
	struct timeval timestamp;
	char hostname[MAX_NAME_LEN];
} stats_head;
#endif	

typedef struct {
	char from[MAX_NAME_LEN];
	int proc_nr;
	char command[MAX_COMMAND_LEN];
} stats_job_begin;


#ifdef WIN32
typedef struct {
	int proc_nr;
	SYSTEMTIME resources;
} stats_job_end;
#endif
#ifdef UNIX
typedef struct {
	int proc_nr;
	struct rusage resources ;
} stats_job_end;
#endif

typedef struct {
	int count;
} stats_timeout;

typedef struct {
	int reason;
} stats_not_avail;

typedef struct {
	int answers;
	long int poll_timeout;
} stats_poll_timeout;

/*
typedef struct {
	union {
		stats_job_begin job_begin;
		stats_job_end job_end;
		stats_timeout timeout;
		stats_not_avail not_avail;
		stats_poll_timeout poll_timeout;
	} stats;
} stats_info;
*/
typedef void *stats_info;

extern int stats_write(int in_type, stats_info in_stats);
extern int stats_read(int *out_type, struct timeval *out_timestamp, char *out_hostname, stats_info *out_stats);
extern int stats_on(void);
extern int stats_off(void);
extern int stats_clear(void);
extern int stats_is_on(void);



