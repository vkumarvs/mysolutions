/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_host_config.c,v 1.7 1994/03/09 15:41:13 carlsson Exp $
 * $Log: yalb_host_config.c,v $
 * Revision 1.7  1994/03/09  15:41:13  carlsson
 * Added call to `permission()'.
 * Introduced `#ifdef CALCALPHA'.
 *
 * Revision 1.6  1994/03/07  12:51:37  carlsson
 * Changed path to log.
 *
 * Revision 1.5  1994/03/07  10:35:54  carlsson
 * Added the possibility to log the sampling in VERBOSE-mode.
 *
 * Revision 1.4  1994/03/01  08:35:14  carlsson
 * Introduced VERBOSE-mode.
 *
 * Revision 1.3  1994/02/25  15:36:25  carlsson
 * Changed call to rsh so that it doesn't hang.
 *
 * Revision 1.2  1994/02/25  09:51:35  carlsson
 * Added parameters.
 *
 * Revision 1.1  1994/02/02  10:41:14  carlsson
 * Added errormessages.
 *
 * Revision 1.0  1993/12/21  10:55:12  carlsson
 * Initial revision
 */

#include <stdio.h>
#include "yalb_config_db.h"

#define TRUE 1
#define FALSE 0

#define OK 0
#define ERR_ARGS -1
#define ERR_GET_HOST -2
#ifndef YALB_BIN 
#define YALB_BIN "/usr/local/bin"
#endif

#ifndef YALB_DATA 
#define YALB_DATA "/usr/local/lib/yalb"
#endif


/*changed 9.8.99 extern double strtod(char *, char **);
extern long strtol(char *, char **, int);*/
extern double strtod (const char *, char **);
extern long int strtol (const char *, char **, int );
extern void reconfig(char *);
#ifdef WIN32
extern int _stricmp();
#define strcasecmp _stricmp
#endif
#ifdef UNIX
extern int gethostname(char *, int);
extern int strcasecmp(char *, char *);
#endif
/*changed 9.8.99 extern int fprintf();*/
extern int fprintf(FILE *, const char *, ...);
extern char *get_swap_server(char *);

char program[] = "yalb_host_config";

static host_config global_host_config;
static int global_calc_alpha = FALSE;
static int global_calc_sys1 = FALSE;
static int global_calc_sys2 = FALSE;
static int global_calc_swapsrv = FALSE;
	
	  
static int get_opts(int argc, char *argv[])
{
	int argp = 1;
	char *sp;

	#ifdef WIN32
	WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/
#endif
	clear_host_config(&global_host_config);

	global_host_config.choose = TRUE;

#ifdef WIN32	
wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
		return;
	}
#endif

	

	if( gethostname(global_host_config.name, MAXNAMELENGTH) ) {
#ifdef WIN32
		printf("Error in gethostname %d\n", WSAGetLastError());
#endif
		return( ERR_GET_HOST );
	}
	while( argv[argp] ) {
#ifdef CALCALPHA
		
if( strcasecmp("-alpha", argv[argp]) == 0 && argv[argp + 1] ) {
			argp++;
		
if( strcasecmp("CALCULATE", argv[argp]) == 0 ) {
			global_calc_alpha = TRUE;
			}
			else {
				global_host_config.alpha = (float)strtod(argv[argp], &sp);
				if( sp == argv[argp] || global_host_config.alpha <= 0.0 ) {
					return( ERR_ARGS );
				}
			}
		}
#else

	if( strcasecmp("-alpha", argv[argp]) == 0 && argv[argp + 1] ) {
			argp++;
			global_host_config.alpha = (float)strtod(argv[argp], &sp);
			if( sp == argv[argp] || global_host_config.alpha <= 0.0 ) {
				return( ERR_ARGS );
			}
		}
#endif
		else 

if( strcasecmp("-swapsrv", argv[argp]) == 0 && argv[argp + 1] ) {
				argp++;
			
if( strcasecmp("CALCULATE", argv[argp]) == 0 ) {
	global_calc_swapsrv = TRUE;
			}
			else {
				strcpy(global_host_config.swap_server, argv[argp]);
			}
		}
		else
		
if( (strcasecmp("-host", argv[argp]) == 0 || strcasecmp("-h", argv[argp]) == 0) &&
   argv[argp + 1] ) {
			argp++;
			strcpy(global_host_config.name, argv[argp]);
		}
		else 
			
	if( strcasecmp("-machine", argv[argp]) == 0 && argv[argp + 1] ) {
		argp++;
			strcpy(global_host_config.machine, argv[argp]);
		}
		else 

if( strcasecmp("-choose", argv[argp]) == 0 && argv[argp + 1] ) {
				argp++;

if( strcasecmp(YES_NAME, argv[argp]) == 0 ) {
	global_host_config.choose = TRUE;
			}
			else 
if( strcasecmp(NO_NAME, argv[argp]) == 0 ) {
					global_host_config.choose = FALSE;
			}
			else {
				return( ERR_ARGS );
			}
		}
		else 
if( strcasecmp("-os_name", argv[argp]) == 0 && argv[argp + 1] ) {
			strcpy(global_host_config.os_name, argv[argp]);
		}
		else 
if( strcasecmp("-sys1", argv[argp]) == 0 && argv[argp + 1] ) {
				argp++;
			global_host_config.sys1 = (float)strtod(argv[argp], &sp);
			if( sp == argv[argp] || global_host_config.sys1 < 0.0 ) {
				return( ERR_ARGS );
			}
		}
		else 
if( strcasecmp("-sys2", argv[argp]) == 0 && argv[argp + 1] ) {
				argp++;
			global_host_config.sys2 = (int)strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || global_host_config.sys2 < 0.0) {
				return( ERR_ARGS );
			}
		}
		else 
	if( strcasecmp("-os_name", argv[argp]) == 0 && argv[argp + 1] ) {
		argp++;
			strcpy(global_host_config.os_name, argv[argp]);
		}
		else 
if( strcasecmp("-max_long", argv[argp]) == 0 && argv[argp + 1] ) {
				argp++;
			global_host_config.max_long = (float)strtod(argv[argp], &sp);
			if( sp == argv[argp] || global_host_config.max_long < 0 ) {
				return( ERR_ARGS );
			}
		}
		else {
			return( ERR_ARGS );
		}

		argp++;
	}

        return( OK );
}

static void err(int ret){
	switch( ret ) {
	      case ERR_CFDB_OPEN:
		fprintf(stderr, "%s: Can't open configuration file.\n", program);
		break;
	      case ERR_ARGS:
#ifdef CALCALPHA
		fprintf(stderr, "usage: %s [-host <hostname>]\n\t\t\t[-h <hostname>]\n\t\t\t[-machine <architecture>]\n\t\t\t[-os_name <operative system>]\n\t\t\t[-alpha <speed> | CALCULATE]\n\t\t\t[-swapsrv <server> | CALCULATE]\n\t\t\t[-sys1 <offset1>]\n\t\t\t[-sys2 <offset2>]\n\t\t\t[-max_long <jobs>]\n", program);
#else
		fprintf(stderr, "usage: %s [-host <hostname>]\n\t\t\t[-h <hostname>]\n\t\t\t[-machine <architecture>]\n\t\t\t[-os_name <operative system>]\n\t\t\t[-alpha <speed>]\n\t\t\t[-swapsrv <server> | CALCULATE]\n\t\t\t[-sys1 <offset1>]\n\t\t\t[-sys2 <offset2>]\n\t\t\t[-max_long <jobs>]\n", program);
#endif
	}
	exit(-1);
}

void main(int argc, char *argv[])
{
	int ret;
	char *swap_server;
	char command[256];

	permission();

	if( (ret = get_opts(argc, argv)) != OK ) {
                err(ret);
        }

	if( global_calc_sys1 ) {
#ifdef VERBOSE
		fprintf(stderr, "%s: Calculating sys1\n", program);
#endif
		global_host_config.sys1 = 0.0;
	}
	if( global_calc_sys2 ) {
#ifdef VERBOSE
		fprintf(stderr, "%s: Calculating sys2\n", program);
#endif
		global_host_config.sys2 = 0.0;
	}
	if( global_calc_swapsrv ) {
#ifdef VERBOSE
		fprintf(stderr, "%s: Calculating swap server\n", program);
#endif
		if( (swap_server = get_swap_server(global_host_config.name)) != NULL ) {
			strcpy(global_host_config.swap_server, swap_server);
		}
	}
	if( (ret = open_config((int *)NULL)) != OK_CFDB ) {
		err(ret);
	}
	if( (ret = write_host_config(&global_host_config)) != OK_CFDB ) {
		err(ret);
	}
	close_config();

	if( global_calc_alpha ) {
#ifdef VERBOSE
		fprintf(stderr, "%s: Calculating alpha\n", program);
		sprintf(command, "rsh -n %s %s/sample.csh \\>\\& %s/logfile.%s \\< /dev/null\\& >/dev/null &", global_host_config.name, YALB_BIN, YALB_DATA, global_host_config.name);
		printf("-%s-\n", command);
#else
		sprintf(command, "rsh -n %s %s/sample.csh \\< /dev/null \\>\\& /dev/null \\& >/dev/null &", global_host_config.name, YALB_BIN);
#endif
		system(command);
	}
	(void)reconfig_host(global_host_config.name);
}


