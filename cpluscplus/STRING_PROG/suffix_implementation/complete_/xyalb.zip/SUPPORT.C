/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *c
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*However, this file is created for XYALB--and it is not a part of YALB*/

#include "system.h"
#define TSPACE ' '
#define TAB '\t'


BOOL getuid (PSID pSid){
		HANDLE               hToken;
      TOKEN_OWNER          ptuOwner[256];
      TOKEN_PRIMARY_GROUP  ptuGroup[256];
      DWORD                cbBuffer=256;
      PSID                 pUserSid;
      OpenProcessToken(GetCurrentProcess(),TOKEN_READ,&hToken);

      GetTokenInformation(hToken,TokenOwner,ptuOwner,cbBuffer,&cbBuffer);

     pSid = ptuOwner->Owner;
	CloseHandle(hToken);
	  return 1;
}

BOOL getgid (PSID pSid){
	HANDLE hndProc=GetCurrentProcess();
	HANDLE               hToken;
      TOKEN_OWNER          ptuOwner[256];
      TOKEN_PRIMARY_GROUP  ptuGroup[256];
      DWORD                cbBuffer=256;
      PSID                 pUserSid;
      OpenProcessToken(GetCurrentProcess(),TOKEN_READ,&hToken);

     		
	  GetTokenInformation(hToken,TokenGroups,ptuGroup,cbBuffer,&cbBuffer);

        pSid = ptuGroup->PrimaryGroup;

      CloseHandle(hToken);
	return 1;
}


