/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: yalb_system_config.c,v 1.3 1994/03/11 14:35:56 carlsson Exp $
 * $Log: yalb_system_config.c,v $
 * Revision 1.3  1994/03/11  14:35:56  carlsson
 * Added call to `permission()'.
 *
 * Revision 1.2  1994/03/07  10:33:49  carlsson
 * *** empty log message ***
 *
 * Revision 1.1  1994/02/02  10:31:37  carlsson
 * Added errormessages.
 *
 * Revision 1.0  1993/12/21  11:00:19  carlsson
 * Initial revision
 */

#include <stdio.h>
#include "yalb_config_db.h"

#define TRUE 1
#define FALSE 0

#define OK 0
#define ERR_ARGS -1


extern double strtod (const char *, char **);
extern long int strtol(const char *, char **, int);

extern void reconfig(char *);
#ifndef WIN32
extern int strcasecmp(char *, char *);
#endif
extern int fprintf(FILE *, const char *, ...);

char program[] = "yalb_system_config";

static system_config global_system_config;

static int get_opts(int argc, char *argv[])
{
	int argp = 1;
	char *sp;

	clear_system_config(&global_system_config);
	

	while( argv[argp] ) {
#ifdef WIN32
                if( strcmp("-timeout", argv[argp]) == 0 && argv[argp + 1] ) {
            
#else
	 if( strcasecmp("-timeout", argv[argp]) == 0 && argv[argp + 1] ) {
            				
#endif
					argp++;
			global_system_config.timeout = strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || global_system_config.timeout < 0 ) {
				return( ERR_ARGS );
			}
                }
                else 
					#ifdef WIN32
  if( strcmp("-polltimeout", argv[argp]) == 0 && argv[argp + 1] ) {
#else
	  if( strcasecmp("-polltimeout", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
		  argp++;
			global_system_config.poll_timeout = strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || global_system_config.poll_timeout < 0 ) {
				return( ERR_ARGS );
			}
                }
                else 
					#ifdef WIN32
					if( strcmp("-mintop", argv[argp]) == 0 && argv[argp + 1] ) {
#else
if( strcasecmp("-mintop", argv[argp]) == 0 && argv[argp + 1] ) {

#endif
						argp++;
			global_system_config.minimum_top = (int)strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || global_system_config.minimum_top < 0 ) {
				return( ERR_ARGS );
			}
                }
		else 
			#ifdef WIN32
			if( strcmp("-idlehost", argv[argp]) == 0 && argv[argp + 1] ) {
#else
	if( strcasecmp("-idlehost", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
				argp++;
			global_system_config.idle_host = (float)strtod(argv[argp], &sp);
			if( sp == argv[argp] || global_system_config.idle_host <= 0.0 ) {
				return( ERR_ARGS );
			}
                }
		else 
			#ifdef WIN32
			if( strcmp("-swapval", argv[argp]) == 0 && argv[argp + 1] ) {
#else
		if( strcasecmp("-swapval", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
			argp++;
			global_system_config.swap_validity = (int)strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || 
			    global_system_config.swap_validity < 0 ||
			    global_system_config.swap_validity > 100 ) {
				return( ERR_ARGS );
			}
                }
		else 
			#ifdef WIN32
			if( strcmp("-improvment", argv[argp]) == 0 && argv[argp + 1] ) {
#else
	if( strcasecmp("-improvment", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
				argp++;
			global_system_config.improvment = (int)strtol(argv[argp], &sp, 10);
			if( sp == argv[argp] || 
			    global_system_config.improvment < 0 ||
			    global_system_config.improvment > 100 ) {
				return( ERR_ARGS );
			}
                }
		else 
			#ifdef WIN32
			if( strcmp("-strategy", argv[argp]) == 0 && argv[argp + 1] ) {
#else
if( strcasecmp("-strategy", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
				argp++;
			#ifdef WIN32
				if( strcmp(TOPLIST_NAME, argv[argp]) == 0 ) {
#else
if( strcasecmp(TOPLIST_NAME, argv[argp]) == 0 ) {
#endif
					global_system_config.strategy = TOPLIST;
			}
			else 
				#ifdef WIN32
				if( strcmp(TOPHOST_NAME, argv[argp]) == 0 ) {
#else
if( strcasecmp(TOPHOST_NAME, argv[argp]) == 0 ) {
					
#endif
					global_system_config.strategy = TOPHOST;
			}
			else {
				return( ERR_ARGS );
			}
		}
		else 
			#ifdef WIN32
			if( strcmp("-loadpolling", argv[argp]) == 0 && argv[argp + 1] ) {
#else
if( strcasecmp("-loadpolling", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
				argp++;
			#ifdef WIN32
				if( strcmp(YES_NAME, argv[argp]) == 0 ) {
#else
if( strcasecmp(YES_NAME, argv[argp]) == 0 ) {
#endif
					global_system_config.loadpolling = TRUE;
			}
			else 
				#ifdef WIN32
				if( strcmp(NO_NAME, argv[argp]) == 0 ) {
#else
	if( strcasecmp(NO_NAME, argv[argp]) == 0 ) {
#endif
					global_system_config.loadpolling = FALSE;
			}
			else {
				return( ERR_ARGS );
			}
		}
		else 
			#ifdef WIN32
			if( strcmp("-statistics", argv[argp]) == 0 && argv[argp + 1] ) {
#else
	if( strcasecmp("-statistics", argv[argp]) == 0 && argv[argp + 1] ) {
#endif
				argp++;
		#ifdef WIN32
				if( strcmp(YES_NAME, argv[argp]) == 0 ) {
#else
if( strcasecmp(YES_NAME, argv[argp]) == 0 ) {
#endif
					global_system_config.statistics = TRUE;
			}
			else
				#ifdef WIN32
				if( strcmp(NO_NAME, argv[argp]) == 0 ) {
#else
if( strcasecmp(NO_NAME, argv[argp]) == 0 ) {
#endif					global_system_config.statistics = FALSE;

				}
			else {
				return( ERR_ARGS );
			}
		}
		else {
			return( ERR_ARGS );
		}
		argp++;
	}

        return( OK );
}

static void err(int ret)
{
	switch( ret ) {
	      case ERR_CFDB_OPEN:
		fprintf(stderr, "%s: Can't open configuration file.\n", program);
		break;
	      case ERR_ARGS:
		fprintf(stderr, "usage: %s [-strategy TOPLIST | TOPHOST]\n\t\t\t  [-timeout <timeout>]\n\t\t\t  [-polltimeout <polltimeout>]\n\t\t\t  [-mintop <hosts>]\n\t\t\t  [-idlehost <load>]\n\t\t\t  [-swapval <validity>]\n\t\t\t  [-improvment <level>]\n\t\t\t  [-loadpolling YES | NO]\n\t\t\t  [-statistics YES | NO]\n", program);
	}
	exit(-1);
}

void main(int argc, char *argv[])
{
	int ret;

	permission(); 

	if( (ret = get_opts(argc, argv)) != OK ) {
                err(ret);
        }
	if( (ret = open_config((int *)NULL)) != OK_CFDB ) {
		err(ret);
	}
	if( (ret = write_system_config(&global_system_config)) != OK_CFDB ) {
		err(ret);
	}
	close_config();

	(void)reconfig_sys();

}
