/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: rexec.c,v 1.2 1994/02/24 15:19:52 carlsson Exp $
 * $Log: rexec.c,v $
 * Revision 1.2  1994/02/24  15:19:52  carlsson
 * Searching for bugs.
 *
 * Revision 1.1  1993/12/15  08:19:46  carlsson
 * Added the flags -f for getting the fastest host, and -l for executing
 * long jobs.
 *
 * Revision 1.0  1993/12/02  14:57:37  stille
 * Initial revision
 */
#define  _SVID_SOURCE /*Added on 13.8.99*/

#include <stdio.h>
#include "lobalib.h"  
#include "rexecbib.h"

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif
#ifdef WIN32
extern struct hostent FAR * PASCAL FAR gethostbyaddr(const char FAR * addr,int len, int type);
#endif
#ifdef LINUX
#include <linux/time.h>
#include <linux/socket.h>
#endif

static struct timeval vorher, nachher;
static float tdiff;
static FILE *stats;


static be_quiet = 0;
static be_verbose = 0;


void exit_routine()
     
{
	exit_state state;
	
	while  (get_exit_status (&state)) {
		
		if (state.kind == INTERNAL){
			fprintf(stderr, 
	"Internal error: %d\nPlease report this to stille@ibr.cs.tu-bs.de", 
				state.data.errorcode);
			rexec_close(); 
			exit(-1);
		}
		else {
			rexec_close(); 
			/* chnaged 13.8.99 exit(state.data.state.__w_retcode);*/
			exit(state.data.state);
		}
		
	}
}

int main (argc, argv)
     int argc;
     char *argv[];
     
{
	
	request want;       /* Contains the wanted hosts */
	reply   get;        /* Contains the reply from load-manager */
	int ret; 
	struct hostent *name;
	char *addr;
	int i;
	struct timeval *last_update;
	float *local_load;
	int *availability;
	char hostname[50];
	int length = 50;
#ifdef UNIX
	caddr_t addr_time;
#endif

	char path[30];
	int fastest_host;
	int specified_host;
	int jobkind;
	int c;
	int lbstrat=0;

	
#ifdef WIN32
	extern char optarg[][MAX_PATH];
#endif
#ifdef UNIX
		extern char *optarg;
#endif
	extern int optind;
#ifdef WIN32
	WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/

	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
    	return;
	}
#endif
		
	fastest_host = FALSE;
	specified_host = FALSE;
	jobkind = NORMAL_JOB;
#ifdef WIN32
	optind=0;
	while ((optind<argc) && (c = argv[optind++][0])  )
		if (c=='-') { c=argv[optind-1][1];
#endif
#ifdef UNIX
		while ((c = getopt (argc, argv, "vqnh:flx")) != -1){
#endif
			
			switch( c ) {
		case 'q':
		    be_verbose = ! (be_quiet = 1);
		    break;
		case 'v':
		    be_quiet = ! (be_verbose = 1);
		    break;
		case 'h':
#ifdef WIN32
			strcpy(hostname, argv[optind++]);
#endif
#ifdef UNIX
			strcpy(hostname,optarg );
#endif
			specified_host = TRUE;
		    break;
		case 'f':
		    fastest_host = TRUE;
		    break;
			/*following case added for more options on LB strategy*/
		case 'x':
		    lbstrat = TRUE;
		    break;
		case 'l':
		    jobkind = LONG_JOB;
		    break;
		case 'n':
		    /* XXX (schoenfr) fix me: no input: */
		    (void) freopen ("/dev/null", "r", stdin);
		    break;
		case '?':
		    fprintf(stderr, 
    "usage: rexec [-v | -q] [-n] [-h <hostname> | -f] [-l] <command>\n");
		    exit(-1);
		}
		#ifdef WIN32 
			if ((c=='v')||(c=='q')||(c=='n')||(c=='h')||(c=='f')||(c=='x')||(c=='l'))
			i=optind;
	#endif
	}
#ifndef WIN32
	i = optind;
#endif
	if( (fastest_host && specified_host) || (argc - i < 1) ) {
		    fprintf(stderr, 
	  "usage: rexec [-v | -q] [-n] [-h <hostname> | -f] [-l] <command>\n");
		exit(-1);
	}


	if( specified_host ) {
		name = gethostbyname(hostname);
	/*	printf("Error in gethostbyname %d\n",WSAGetLastError());*/
		if (!name) {
		    fprintf(stderr, "You specified an unknown host!\n");
			exit(-1);
		}
		
		/*bcopy((char *) name->h_addr , &get.hostlist[0].sin_addr, sizeof get.hostlist[0].sin_addr);*/
#ifdef WIN32
	memcpy(  &(get.hostlist[0].sin_addr), (char *) name->h_addr_list[0] , name->h_length);
#endif
#ifdef UNIX
	bcopy((char *) name->h_addr_list[0] , &get.hostlist[0].sin_addr, sizeof get.hostlist[0].sin_addr);
 
#endif

		
	}
	else {

		gethostname(hostname,length);
		
		/******This is the place where you choose from different possible load-balancing strategies*****/
		if( fastest_host ) {
			want.kind = GET_FASTEST;
		}
		else if (lbstrat){
			want.kind=GET_OPT;
		}
		else{
			want.kind = GET_TOP; 
		}
		want.number = 1; 
		want.hostlist[0] = (struct sockaddr_in *)0;
		
		ret = request_init();
		
		if(ret != 0) {
		    fprintf(stderr, "System seems to be down !\n");
		    exit(1);
		}
    
		ret = get_hosts(&want,&get); 
    
		if(ret != 0) {
		    fprintf(stderr, "Error getting host: %d\n", ret);
		    exit(1);
		}
		
		name = gethostbyaddr((char *) &get.hostlist[0].sin_addr,
				   sizeof(get.hostlist[0].sin_addr), AF_INET);
		
		reset_system();
	}

	if (be_verbose)
	    fprintf(stderr, 
		    "Please report any errors to stille@ibr.cs.tu-bs.de !\n" );
	if (! be_quiet)
	    fprintf(stderr, "[Your job is exported to: %s]\n",name->h_name);
  
	if (rexec_init(INTERACTIVE) <0) {
	    fprintf(stderr, "Initialisation of rexec functions failed! \n\n");
		exit(1);
	}
	
	ret = rexecv (argv[i], &argv[i+1], &(get.hostlist[0]), jobkind);

	if (ret < 0) {
	    if (ret == COULD_NOT_CONNECT) {
			fprintf(stderr, "%s is unreachable.\n", name->h_name);
		}
		if (ret == CONNECTION_CLOSED) {
		    fprintf(stderr, "%s refuses execution.\n",
			    name->h_name);
		}
		if (ret == NO_RESOURCES)
		  fprintf(stderr, "Local Resources exhausted.\n");
		rexec_close(); 
		exit(-1);
	}

	exit_routine();
}  

