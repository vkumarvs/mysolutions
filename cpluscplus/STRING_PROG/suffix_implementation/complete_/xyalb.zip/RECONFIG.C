/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
/*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: reconfig.c,v 1.1 1994/02/28 19:18:47 carlsson Exp $
 * $Log: reconfig.c,v $
 * Revision 1.1  1994/02/28  19:18:47  carlsson
 * Redirect the Load-Daemons stdin, stdout, stderr to /dev/null.
 * Introduced #ifdef VERBOSE.
 *
 * Revision 1.0  1993/12/21  10:45:52  carlsson
 * Initial revision
 */
#include "yalb_config_db.h"
#ifdef UNIX
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#endif

#include "reconfig.h"

#define TRUE 1
#define FALSE 0

#ifndef WIN32
extern void bcopy(char *, char *, int);
extern void bzero(char *, int);
#endif

/*#ifdef WIN32
#define LMANAGER "loadmanager"
#define RMANAGER "rexecmanager"
#define YALB_DAEMON "\\usr\\local\\etc"
#define LDAEMON_BASE "loaddaemon"
#endif*/
#ifdef LINUX
#define fd_set __fd_set
#include <linux/time.h>
#endif
#ifdef UNIX
extern int sendto (int , __const __ptr_t, size_t , int , __CONST_SOCKADDR_ARG , socklen_t );
extern int socket(int, int, int);
extern int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
extern long ulimit(int, long);
extern int close(int);
extern int system(const char *);
extern int gethostname(char *, int);

extern int fprintf(FILE *, const char *, ...);

#endif

static int yalb_start(char *in_host)
{
	char command[MAX_PATH_LEN + 128];

	sprintf(command, "rsh -n %s '%s/%s-`uname -m` >&/dev/null </dev/null &'", in_host, YALB_DAEMON, LDAEMON_BASE);
#ifdef VERBOSE
	printf("executing command -%s-\n", command);
#endif

	if( system(command) != -1 ) {
		return OK_REC;
	}
	else {
		return( ERR_REC_START );
	}
}
void reply_to_config_read(int in_sock, struct sockaddr *in_from)
{
	rpc_message reply;
	
	reply.kind = CONFIG_READ_REPLY;
	reply.magic_number = MAGIC;

	(void)sendto(in_sock, (char *)&reply, sizeof( reply ), 0, in_from, sizeof( struct sockaddr_in ));
}



static int force_config_read_sys(void)
{

	static struct servent *get_ports = NULL;
	static struct sockaddr_in ldaemon;
	static rpc_message request;
	static int ldaemon_sock;
	struct hostent *local_host_ent;
	char local_host_name[MAXNAMELENGTH];

#ifdef WIN32
	WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif
	
	get_ports = getservbyname(DAEMON_SERVICE, "udp");

	
	ldaemon.sin_family = AF_INET;
	ldaemon.sin_port = get_ports->s_port;

	(void)gethostname(local_host_name, MAXNAMELENGTH);

	local_host_ent = gethostbyname(local_host_name);

#ifdef WIN32
	memcpy((char *)&ldaemon.sin_addr, local_host_ent->h_addr_list[0],  local_host_ent->h_length);
#endif
#ifdef UNIX
	bcopy(local_host_ent->h_addr_list[0], (char *)&ldaemon.sin_addr, local_host_ent->h_length);
#endif
	
	ldaemon_sock = socket(AF_INET, SOCK_DGRAM, 0);
	
	request.kind = CONFIG_READ_SYS;
	request.magic_number = MAGIC;
	
	
	if( sendto(ldaemon_sock, (char *)&request, sizeof request, 0, (struct sockaddr *)&ldaemon, sizeof ldaemon) < 0 ) {
#ifdef VERBOSE
		fprintf(stderr,"can't send read_config_request to ldaemon\n");
#endif
		close(ldaemon_sock);
		return( ERR_REC_SEND );
	}
		
	close(ldaemon_sock);
	return( OK_REC );
}





static int force_config_read_host2(char *in_host_name)
{
	static struct servent *get_ports = NULL;
	static struct sockaddr_in lmanager;
	static rpc_message request;
	static int lmanager_sock;
	struct hostent *local_host_ent;
#ifdef WIN32
	WORD wVersionRequested;WSADATA wsaData;int werr;  /*added on 22.9.99*/
	wVersionRequested = MAKEWORD( 2, 0 ); 
    werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
   		return;
	}
#endif

	get_ports = getservbyname(LOMA_SERVICE, "udp");

	lmanager.sin_family = AF_INET;
	lmanager.sin_port = get_ports->s_port;

	local_host_ent = gethostbyname(in_host_name);


#ifdef WIN32
memcpy((char *)&lmanager.sin_addr, local_host_ent->h_addr_list[0], local_host_ent->h_length);
   memcpy((char *)&request.data.addr,local_host_ent->h_addr_list[0],  local_host_ent->h_length);

#endif
#ifdef UNIX
bcopy(local_host_ent->h_addr_list[0], (char *)&lmanager.sin_addr, local_host_ent->h_length);
bcopy(local_host_ent->h_addr_list[0], (char *)&request.data.addr, local_host_ent->h_length);
	
#endif
	/*changed 5.9.99 bcopy(local_host_ent->h_addr, (char *)&request.data.addr, local_host_ent->h_length);*/
	
	/*changed 11.9.99 lmanager.sin_addr.s_addr = (lmanager.sin_addr.s_addr & BROADCAST_MASK) | ~BROADCAST_MASK;*/
	
	lmanager_sock = socket(AF_INET, SOCK_DGRAM, 0);
	
	request.kind = CONFIG_READ_HOST;
	request.magic_number = MAGIC;
	
	
	if( sendto(lmanager_sock, (char *)&request, sizeof request, 0, (struct sockaddr *)&lmanager, sizeof lmanager) < 0 ) {
#ifdef VERBOSE
		fprintf(stderr,"%s: can't send read_config_request to lmanager\n");
#endif
		close(lmanager_sock);
		return( ERR_REC_SEND );
	}
		
	close(lmanager_sock);
	return( OK_REC );
}





static int force_config_read_host1(char *in_host_name)
{
	static struct servent *get_ports = NULL;
	static struct sockaddr_in daemon;
	static rpc_message request;
	static int daemon_sock;
	struct hostent *local_host_ent;
	fd_set reply_fd;
	struct timeval reply_timeout;
	
	int ret;
	int count = 0;

#ifdef WIN32
/*	WORD wVersionRequested;WSADATA wsaData;int werr;
	wVersionRequested = MAKEWORD( 2, 0 ); 
   werr = WSAStartup( wVersionRequested, &wsaData );
	if ( werr != 0 ) {
 		return;
	}*/
#endif	
	get_ports = getservbyname(DAEMON_SERVICE, "udp");
 	local_host_ent = gethostbyname(in_host_name);

	reply_timeout.tv_sec = 5;
	reply_timeout.tv_usec = 0;


	daemon.sin_family = AF_INET;
	daemon.sin_port = get_ports->s_port;
#ifdef WIN32
	memcpy((char *)&daemon.sin_addr, local_host_ent->h_addr_list[0], local_host_ent->h_length);
#endif
#ifdef UNIX
	bcopy(local_host_ent->h_addr_list[0], (char *)&daemon.sin_addr, local_host_ent->h_length);
#endif
	daemon_sock = socket(AF_INET, SOCK_DGRAM, 0);
	
	request.kind = CONFIG_READ_HOST;
	request.magic_number = MAGIC;
	
	
	while( count < MAX_FORCE_TRIES ) {
		if( sendto(daemon_sock, (char *)&request, sizeof request, 0, (struct sockaddr *)&daemon, sizeof daemon) < 0 ) {
#ifdef VERBOSE
			fprintf(stderr,"%s: can't send read_config_request to daemon\n");
#endif
			close(daemon_sock);
			return( ERR_REC_SEND );
		}
		
		FD_ZERO(&reply_fd);
		FD_SET(daemon_sock, &reply_fd);
		
#ifdef WIN32
		while( (ret = select(1, &reply_fd, (fd_set *)0, (fd_set *)0, &reply_timeout)) < 0 && errno == EINTR ) 
#endif
#ifdef UNIX
	while( (ret = select((int)ulimit(1, 0), &reply_fd, (fd_set *)0, (fd_set *)0, &reply_timeout)) < 0 && errno == EINTR ) 
#endif
		{;
		}
		
		count++;

		if( ret == -1 ) {
#ifdef VERBOSE
			fprintf(stderr, "cant get reply\n");
#endif
			close(daemon_sock);
			return( ERR_REC_REPLY );
		}
		
		if( FD_ISSET(daemon_sock, &reply_fd) ) {
			close(daemon_sock);

			return( OK_REC );
		}
	}
	close(daemon_sock);
	return( ERR_REC_TIMEOUT );
}
	

	
/*
  meddelandets id: READ_CONFIG

  tvinga `host' att laesa yalb.config
  `host' maaste svara paa begaeran
  om `host' inte svarar innom viss tid antas att `host' 
  aer nere eller att YALB inte koer paa maskinen
  foersoek daa starta YALB paa `host'

  (om `host' har choose = NO, ska daemonerna daer avslutas)
*/

void reconfig_host(char *in_host)
{
	if( in_host ) {
		fprintf(stderr, "Sending request to `%s'\n", in_host);
		if( force_config_read_host1(in_host) == OK_REC ) {
			fprintf(stderr, "Receiving answer from `%s'\n", in_host);
		}
		else {
			fprintf(stderr, "`%s' not reachable, starting...\n", in_host);
			if( yalb_start(in_host) != OK_REC ) {
#ifdef VERBOSE
				fprintf(stderr, "\nCant start\n");
#endif
			}
		}
		(void)force_config_read_host2(in_host);
	}
}

void reconfig_sys(void)
{
#ifdef VERBOSE
     fprintf(stderr, "Broadcasting system reconfiguration request\n");
#endif
     (void)force_config_read_sys();

}

	
			
			
