/* Copyright (c) 1999
 * XYALB (eXtended Yet Another Load Balancing code)
 * Author:  Abdul Sakib Mondal
 * Infosys Technologies Limited
 * 27 Bannerghatta Road, JP Nagar 3rd Phase
 * Bangalore, India 560076
 *
 * This is extended version of the YALB code. (see copy right below)
 * The program has been modified to run on number of platforms 
 * (LINUX, SUNOS and Winfows 95 and NT).
 * However, Infosys does not makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 * This program is free software; you can redistribute it and/or modify
 *  it under the terms of the copyrights as mentioned here.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 */
 /*
 * Copyright (c) 1994
 *
 * Bettina Schnor,  Stefan Stille,  Henrik Carlsson
 *
 * TU Braunschweig, Germany
 * Institute for Operating Systems and Computer Networks
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that this copyright
 * notice appears in all copies.  The University of Braunschweig
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

/*
 * $Id: children.c,v 1.4 1994/03/11 14:34:52 carlsson Exp $
 * $Log: children.c,v $
 * Revision 1.4  1994/03/11  14:34:52  carlsson
 * Changed the signal that is sent to the children from `stop_children()'
 * from SIGQUIT to SIGKILL.
 *
 * Revision 1.3  1994/02/28  18:54:51  carlsson
 * #ifdef VERBOSE introduced.
 *
 * Revision 1.2  1993/12/21  10:41:42  carlsson
 * Initial revision
 */
#include <stdio.h>
#include <signal.h>
/*#include <sys/wait.h>
#include <sys/time.h>  */

#include "children.h"
#include "system.h"
#ifdef LINUX
#include <sys/resource.h>
#define  pid_t __pid_t
#endif
#ifndef WIN32
#include <sys/wait.h>
#include <sys/time.h>
#endif


#define ERR_CHILD_MAX -2
#define ERR_CHILD_NO_INIT -1
#define CHILD_LOAD_MANAGER 0
#define CHILD_REXEC_MANAGER 1
#define CHILD_MAX 2

#define TIMELIMIT 5

typedef struct {
#ifdef WIN32
	HANDLE pid;
	struct tm  *timestamp;
#endif
#ifdef UNIX
	int pid;
		struct timeval timestamp;
#endif
	char name[MAX_PATH_LEN];
	int startable;
} child;

static int global_child_count = 0;
static int global_is_init = FALSE;
static child global_child_tab[CHILD_MAX];

static void (*global_callback_fn)(void) = NULL;

#ifdef UNIX
extern int wait3(int *, int, struct rusage *);
extern int fork();
extern int execlp();
extern int setpgrp(int, int);
extern pid_t setsid();
extern int sigblock(int);
extern int sigsetmask(int);
extern int gettimeofday(struct timeval *, struct timezone *);
extern int fprintf(FILE *, const char *, ...);
extern char * strncpy(char *, const char *, size_t);
#define YALB_DAEMON "/usr/local/etc";
#endif

#ifdef WIN32
#include <string.h>
#define YALB_DAEMON "\\usr\\local\\etc";
#endif
#define LDAEMON_BASE "loaddaemon";



static void restart_child(int pid)
{
	int i;
#ifdef WIN32
	struct tm *timestamp;
HANDLE hProc;
PROCESS_INFORMATION ProcessInfo;
#endif
#ifdef UNIX
	struct timeval timestamp;
#endif



	for( i = 0; i < global_child_count; i++ ) {
		if( global_child_tab[i].pid == pid ) {
#ifdef WIN32
	time_t ltime;
		time(&ltime);
		timestamp=gmtime(&ltime);
		if( timestamp->tm_sec - global_child_tab[i].timestamp->tm_sec < TIMELIMIT )
#endif
#ifdef UNIX

			gettimeofday(&timestamp, (struct timezone *)NULL);
			if( timestamp.tv_sec - global_child_tab[i].timestamp.tv_sec < TIMELIMIT ) 
#endif
					{
#ifdef VERBOSE
				fprintf(stderr,"Can't start %s\n", global_child_tab[i].name);
#endif
#ifdef WIN32
			fprintf(stderr,"Load-Daemon: cannot start %s \n",global_child_tab[i].name);
#endif
#ifdef UNIX
	syslog(LOG_WARNING, 
                            "Load-Daemon: cannot start `%s'.",
				       global_child_tab[i].name);

#endif

				global_child_tab[i].startable = FALSE;
			}
			else {
				global_child_tab[i].timestamp = timestamp;
#ifdef WIN32
		
		CreateProcess(NULL,global_child_tab[i].name,NULL,NULL,TRUE,NORMAL_PRIORITY_CLASS,NULL,NULL,NULL,&ProcessInfo);
		hProc=ProcessInfo.hProcess;
				
		if (hProc!=NULL) {
			global_child_tab[i].pid =ProcessInfo.dwProcessId;
				exit(-1);
		}
#endif
#ifdef UNIX
				if( (global_child_tab[i].pid = fork()) == 0 ) {
					if( global_callback_fn ) {
						(*global_callback_fn)();
					}
					sigsetmask(0);
					signal(SIGCHLD, SIG_DFL);

#ifdef VERBOSE
					fprintf(stderr, "Restarting %s\n", global_child_tab[i].name);
#endif
				
syslog(LOG_INFO, 
                            "Load-Daemon: restarting `%s'...",
					       global_child_tab[i].name);
				
					execlp(global_child_tab[i].name, global_child_tab[i].name, (char *)NULL);
					syslog(LOG_ERR, 
		       "Load-Daemon: cannot execute `%s'; reason: %m",
					       global_child_tab[i].name);
					exit(-1);
				}
#endif
			}
		}
	}
}

#ifdef UNIX
static void handle_SIGCHLD (void)
{
	/*changed on 13.8.99 union wait status;               /* Status of the child process */
	int status;               /* Status of the child process */
	int pid;                         /* Process-id of child process */
	struct rusage resources;
#if 1
	/* XXX (schoenfr): don't block, boy: */
	while((pid = wait3((int *) &status, WNOHANG | WUNTRACED, 
			   (struct rusage *) &resources)) < 0
	      && errno == EINTR)
	    continue;
#else
	while( ((pid = wait3((int *)&status, 0, (struct rusage *) &resources)) < 0) && (errno == EINTR) ) {
		;
	}
#endif
  
	if( (!WIFEXITED(status) && !WIFSIGNALED(status)) || pid == 0 ) {
		return;
	}

	restart_child(pid);
}
			
#endif


void init_children(void (*in_callback_fn)(void))
{
	global_callback_fn = in_callback_fn;
#ifdef UNIX
	signal(SIGCHLD, handle_SIGCHLD);
#endif
	global_is_init = TRUE;
}



void kill_child(int in_child, int in_sig)
{
	if( in_child < global_child_count && in_child >= 0 ) {
#ifdef WIN32
		GenerateConsoleCtrlEvent(in_sig,global_child_tab[in_child].pid);
#endif
#ifdef UNIX
		kill(global_child_tab[in_child].pid, in_sig);
#endif
	}
}

void stop_children(void)
{
	int i;

#ifdef WIN32
	signal(SIGTERM, SIG_DFL);
#endif
#ifdef UNIX
	signal(SIGCHLD, SIG_DFL);
#endif

	for( i = 0; i < global_child_count; i++ ) {
		if( global_child_tab[i].startable ) {
#ifdef WIN32
		GenerateConsoleCtrlEvent(SIGTERM,global_child_tab[i].pid);
#endif
#ifdef UNIX
			kill(global_child_tab[i].pid, SIGKILL);
#endif
		}
	}

	global_is_init = FALSE;
	global_child_count = 0;
	global_callback_fn = NULL;
}

void restart_children(void)
{
	int i;
	
	for( i = 0; i < global_child_count; i++ ) {
		if( !global_child_tab[i].startable ) {
			global_child_tab[i].startable = TRUE;
			restart_child(global_child_tab[i].pid);
		}
	}
}


int start_child(char *in_name)
{
	int mask;
	char testcmd[50];
#ifdef WIN32
HANDLE hProc;
STARTUPINFO si;  /* for CreateProcess call */ 
PROCESS_INFORMATION pi;  /* for CreateProcess call */ 
SECURITY_ATTRIBUTES sa;
SECURITY_ATTRIBUTES tsa;
   time_t ltime;
  char *args[4];  
  args[0]=malloc(50);
  strcpy(args[0],in_name);
   args[1] ="-debug";
   	   args[2]=NULL;
 #endif
	if( !global_is_init ) {
		return( ERR_CHILD_NO_INIT );
	}
		
	if( global_child_count >= CHILD_MAX ) {
		return( ERR_CHILD_MAX );
	}


	strncpy(global_child_tab[global_child_count].name, in_name, MAX_PATH_LEN);
#ifdef WIN32
	    time(&ltime);
		global_child_tab[global_child_count].timestamp=gmtime(&ltime);
#endif
#ifdef UNIX
		gettimeofday(&global_child_tab[global_child_count].timestamp, (struct timezone *)NULL);
		/*mask = sigblock(sigmask(SIGCHLD));*/
#endif
		global_child_tab[global_child_count].startable = TRUE;
	
#ifdef WIN32
	global_child_count++;
	/* if (CreateProcess(in_name,args,NULL, NULL,TRUE, 0, NULL, NULL, &si,&pi) ==0) printf("Error %d\n",GetLastError()); */
	


	global_child_tab[global_child_count - 1].pid=_spawnv(_P_NOWAIT,in_name,args);
#endif
#ifdef UNIX
	mask = sigblock(SIGCHLD);
	
	if( (global_child_tab[global_child_count - 1].pid = fork()) == 0 ) {
		if( global_callback_fn ) {
			(*global_callback_fn)();
		}
		sigsetmask(mask);
		signal(SIGCHLD, SIG_DFL);

/*#ifdef VERBOSE*/
		fprintf(stderr, "Starting %s\n", in_name);
/*#endif*/
		
		execlp(in_name, in_name, (char *)NULL);
/*#ifdef VERBOSE*/
		fprintf(stderr, "Execlp error\n");
/*#endif*/
		exit(-1);
	}

	sigsetmask(mask);
#endif
	return( global_child_count - 1 );
}

